# دليل البناء والنشر والتشغيل — MISHWAR – مشوار

## 1. ما تم بناؤه وتشغيله فعلياً في بيئة العمل
تم بناء نظام **MISHWAR – مشوار** بالكامل كنظام متكامل يعمل بقاعدة بيانات حقيقية وخادم خلفي واتصال مباشر:
- **تطبيق الزبون**: واجهة عربية RTL متوافقة مع الهواتف (PWA قابلة للتثبيت على Android وiOS)، تحديد موقع تلقائي ويدوي، البحث في العراق، 4 فئات خدمة فقط (`Economy`, `Super`, `Plus`, `Family`) مع تعيين السيارة تلقائياً، تسعير مسبق بالدينار العراقي، تتبع مباشر للسيارة والسرعة (`كم/س`)، التقييم، السجل، المزايا، والشكاوى.
- **تطبيق السائق**: تسجيل كامل بالصورة الشخصية ومعلومات السيارة والمستمسكات (إجازة السوق، السنوية، البطاقة الوطنية)، بوابة موافقة الإدارة، **زر مشوار** (أزرق عند التشغيل `مشوار يعمل` ورمادي عند الإطفاء `مشوار متوقف` مع القفل أثناء الرحلة النشطة)، استقبال الطلبات بمهلة زمنية، تتبع GPS والسرعة الحقيقية، الأرباح اليومية والشهرية، والتقييمات.
- **لوحة تحكم الإدارة**: محمية بصلاحيات مشددة، إحصائيات فورية، خريطة متابعة حية، اعتماد/رفض السائقين مع عرض المستمسكات المحمية، إدارة الأسعار والعروض، إدارة اشتراكات **MISHWAR PLUS**، إدارة الشكاوى، التقارير المالية (CSV)، التنبيهات الأمنية، والنسخ الاحتياطية الدورية.
- **قاعدة البيانات والخادم**: `SQLite` (`better-sqlite3` بوضع `WAL` ومعاملات `BEGIN IMMEDIATE` لمنع تعارض قبول الرحلات) + `Express` + `WebSockets (ws)` للتحديث الفوري.

---

## 2. خدمة الخرائط والتكاليف وحدود الاستخدام
تم اعتماد **OpenStreetMap + Leaflet + OSRM + Nominatim** في هذه النسخة للأسباب التالية:
- **التكلفة**: **مجانية 100%** ولا تتطلب بطاقة ائتمان أو اشتراكاً مدفوعاً.
- **حدود الاستخدام**:
  - خوادم التوجيه العامة (`router.project-osrm.org`) والبحث (`nominatim.openstreetmap.org`) تخضع لسياسة الاستخدام العادل (حوالي 1 طلب/ثانية للبحث) — وفي حال ازدياد الضغط التجاري مستقبلاً يمكن استضافة OSRM الخاص بك مجاناً على خادمك، أو الترقية إلى Google Maps Platform.
- **في حال رغبتك بالانتقال إلى Google Maps Platform مستقبلاً**:
  - تمنح Google رصيداً مجانياً شهرياً ($200/شهر تقريباً أو حسب الخطة الحالية) وبعد تجاوزه تُحتسب تكلفة لكل 1,000 طلب خريطة أو توجيه، وتتطلب تفعيل حساب فوترة في Google Cloud.

---

## 3. خطوات تصدير ملفات Android (APK / AAB) و iOS (Xcode)
> ملاحظة مهمة: بيئة الخادم السحابية الحالية هي بيئة Linux وNode.js ولا تحتوي على Android SDK / Gradle أو نظام macOS / Xcode، لذا يتم تنفيذ التجميع الثنائي النهائي (`.apk`, `.aab`, `.ipa`) محلياً عبر **Capacitor** المجهز في `capacitor.config.ts`:

### أ. تجهيز المشروع للتصدير
```bash
npm install
npm run build
npm install @capacitor/core @capacitor/cli @capacitor/android @capacitor/ios @capacitor/geolocation @capacitor/push-notifications
npx cap add android
npx cap add ios
npx cap sync
```

### ب. بناء Android APK (للتثبيت المباشر) و AAB (للنشر على Google Play)
1. افتح المشروع في Android Studio:
   ```bash
   npx cap open android
   ```
2. أضف أذونات الموقع في الخلفية في `android/app/src/main/AndroidManifest.xml`:
   - `ACCESS_FINE_LOCATION`
   - `ACCESS_COARSE_LOCATION`
   - `ACCESS_BACKGROUND_LOCATION`
   - `FOREGROUND_SERVICE_LOCATION`
3. من Android Studio أو عبر سطر الأوامر داخل مجلد `android/`:
   - لبناء **APK**: `./gradlew assembleRelease` (الناتج في `app/build/outputs/apk/release/`)
   - لبناء **AAB** لـ Google Play: `./gradlew bundleRelease` (الناتج في `app/build/outputs/bundle/release/`)

### ج. بناء مشروع iOS للنشر على App Store (يتطلب Mac + Xcode)
1. افتح مشروع Xcode:
   ```bash
   npx cap open ios
   ```
2. فعّل في `Info.plist`:
   - `NSLocationWhenInUseUsageDescription`
   - `NSLocationAlwaysAndWhenInUseUsageDescription`
   - `UIBackgroundModes`: `location`, `remote-notification`
3. اختر `Product -> Archive` في Xcode ثم ارفع النسخة إلى **App Store Connect**.
