# MISHWAR – إدارة مشوار (لوحة الإدارة المستقلة)

مشروع مستقل كامل للوحة تحكم الإدارة مع البحث برقم الحساب (MSH-C / MSH-D / MSH-A / MSH-TR)، إدارة المحافظ وبوابات الدفع، التظلّمات، والنسخ الاحتياطية المشفرة.

## التشغيل المحلي
```bash
npm install
cp .env.example .env
npm run dev
```

## البناء والإنتاج
```bash
npm run build
npm start
```
