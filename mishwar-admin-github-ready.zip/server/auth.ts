import crypto from 'crypto';
import type { NextFunction, Request, Response } from 'express';
import { db } from './db.ts';
import type { UserRole } from '../src/types/mishwar.ts';

const RUNTIME_SECRET = process.env.SESSION_SECRET?.trim() || crypto.randomBytes(32).toString('hex');

export interface AuthTokenPayload {
  sub: string;
  role: UserRole;
  jti: string;
  ver: number;
  iat: number;
  exp: number;
}

export interface AuthedRequest extends Request {
  auth?: {
    userId: string;
    role: UserRole;
    name: string;
    phone: string;
    jti: string;
    exp: number;
  };
}

export function normalizeIraqiPhone(raw: string): string | null {
  if (typeof raw !== 'string') return null;
  const arabicDigits = '٠١٢٣٤٥٦٧٨٩';
  const ascii = raw
    .trim()
    .replace(/[٠-٩]/g, (d) => String(arabicDigits.indexOf(d)))
    .replace(/[\s\-()]/g, '');

  let digits = ascii;
  if (digits.startsWith('+964')) digits = digits.slice(4);
  else if (digits.startsWith('00964')) digits = digits.slice(5);
  else if (digits.startsWith('964')) digits = digits.slice(3);
  if (digits.startsWith('0')) digits = digits.slice(1);

  if (!/^7[3-9]\d{8}$/.test(digits)) {
    return null;
  }
  return `+964${digits}`;
}

export function hashPassword(password: string): string {
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.scryptSync(password, salt, 64).toString('hex');
  return `${salt}:${hash}`;
}

export function verifyPassword(password: string, stored: string): boolean {
  const parts = stored.split(':');
  if (parts.length !== 2) return false;
  const [salt, keyHex] = parts;
  const keyBuf = Buffer.from(keyHex, 'hex');
  const derived = crypto.scryptSync(password, salt, 64);
  if (keyBuf.length !== derived.length) return false;
  return crypto.timingSafeEqual(keyBuf, derived);
}

export function signToken(userId: string, role: UserRole, tokenVersion = 1): string {
  const now = Math.floor(Date.now() / 1000);
  const payload: AuthTokenPayload = {
    sub: userId,
    role,
    jti: crypto.randomUUID(),
    ver: tokenVersion,
    iat: now,
    exp: now + 60 * 60 * 24 * 7,
  };
  const encoded = Buffer.from(JSON.stringify(payload)).toString('base64url');
  const sig = crypto.createHmac('sha256', RUNTIME_SECRET).update(encoded).digest('base64url');
  return `${encoded}.${sig}`;
}

export function verifyToken(token: string): AuthTokenPayload | null {
  if (!token || typeof token !== 'string') return null;
  const parts = token.split('.');
  if (parts.length !== 2) return null;
  const [encoded, sig] = parts;
  const expectedSig = crypto.createHmac('sha256', RUNTIME_SECRET).update(encoded).digest('base64url');
  const sigBuf = Buffer.from(sig);
  const expBuf = Buffer.from(expectedSig);
  if (sigBuf.length !== expBuf.length || !crypto.timingSafeEqual(sigBuf, expBuf)) {
    return null;
  }
  try {
    const payload = JSON.parse(Buffer.from(encoded, 'base64url').toString('utf8')) as AuthTokenPayload;
    if (!payload.sub || !payload.role || !payload.jti || payload.exp < Math.floor(Date.now() / 1000)) {
      return null;
    }
    return payload;
  } catch {
    return null;
  }
}

export function revokeTokenJti(jti: string, exp: number) {
  db.prepare('INSERT OR IGNORE INTO revoked_tokens (jti, expires_at, revoked_at) VALUES (?, ?, ?)').run(
    jti,
    exp,
    new Date().toISOString(),
  );
}

export function authenticateToken(token: string | null) {
  if (!token) return null;
  const payload = verifyToken(token);
  if (!payload) return null;

  const revoked = db.prepare('SELECT jti FROM revoked_tokens WHERE jti = ?').get(payload.jti);
  if (revoked) return null;

  const user = db
    .prepare('SELECT id, role, name, phone, status, token_version FROM users WHERE id = ?')
    .get(payload.sub) as
    | { id: string; role: UserRole; name: string; phone: string; status: string; token_version: number }
    | undefined;
  if (!user || user.status !== 'active' || user.role !== payload.role || user.token_version !== payload.ver) {
    return null;
  }
  return {
    userId: user.id,
    role: user.role,
    name: user.name,
    phone: user.phone,
    jti: payload.jti,
    exp: payload.exp,
  };
}

export function requireAuth(req: AuthedRequest, res: Response, next: NextFunction) {
  const header = req.headers.authorization;
  const token = header?.startsWith('Bearer ') ? header.slice(7).trim() : null;
  const auth = authenticateToken(token);
  if (!auth) {
    res.status(401).json({ error: 'يرجى تسجيل الدخول للمتابعة' });
    return;
  }
  req.auth = auth;
  next();
}

export function requireRole(...roles: UserRole[]) {
  return (req: AuthedRequest, res: Response, next: NextFunction) => {
    if (!req.auth) {
      res.status(401).json({ error: 'يرجى تسجيل الدخول للمتابعة' });
      return;
    }
    if (!roles.includes(req.auth.role)) {
      // Log unauthorized cross-role access attempt
      db.prepare(
        `INSERT INTO security_events (id, severity, event_type, actor_user_id, ip_address, summary, details, created_at)
         VALUES (?, 'high', 'forbidden_role_access', ?, ?, ?, ?, ?)`,
      ).run(
        crypto.randomUUID(),
        req.auth.userId,
        req.ip || 'unknown',
        `محاولة وصول غير مصرح به من دور ${req.auth.role} إلى ${req.originalUrl}`,
        JSON.stringify({ requiredRoles: roles, actualRole: req.auth.role, path: req.originalUrl }),
        new Date().toISOString(),
      );
      res.status(403).json({ error: 'ليس لديك صلاحية للوصول إلى هذا القسم' });
      return;
    }
    next();
  };
}

export function isEnvPasscodeConfigured(): boolean {
  return Boolean(process.env.ADMIN_PASSCODE && process.env.ADMIN_PASSCODE.trim().length > 0);
}

export function verifyEnvAdminPasscode(input: string): boolean {
  const envPass = process.env.ADMIN_PASSCODE?.trim();
  if (!envPass) return false;
  const a = Buffer.from(input);
  const b = Buffer.from(envPass);
  if (a.length !== b.length) return false;
  return crypto.timingSafeEqual(a, b);
}
