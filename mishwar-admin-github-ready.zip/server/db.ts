import crypto from 'crypto';
import Database from 'better-sqlite3';
import fs from 'fs';
import path from 'path';

const dataDir = path.resolve(process.cwd(), 'data');
fs.mkdirSync(dataDir, { recursive: true });

const dbPath = process.env.MISHWAR_DB_PATH
  ? path.resolve(process.env.MISHWAR_DB_PATH)
  : path.join(dataDir, 'mishwar.db');

fs.mkdirSync(path.dirname(dbPath), { recursive: true });

export const db = new Database(dbPath);

db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');
db.pragma('busy_timeout = 5000');

export function initDatabase() {
  db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY,
      account_number TEXT,
      role TEXT NOT NULL CHECK(role IN ('customer', 'driver', 'admin')),
      name TEXT NOT NULL,
      phone TEXT NOT NULL UNIQUE,
      password_hash TEXT NOT NULL,
      avatar_url TEXT,
      status TEXT NOT NULL DEFAULT 'active' CHECK(status IN ('active', 'suspended')),
      token_version INTEGER NOT NULL DEFAULT 1,
      rating_avg REAL NOT NULL DEFAULT 5.0,
      rating_count INTEGER NOT NULL DEFAULT 0,
      terms_accepted_version TEXT,
      terms_accepted_at TEXT,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS account_sequences (
      prefix TEXT PRIMARY KEY,
      next_seq INTEGER NOT NULL DEFAULT 1
    );

    CREATE TABLE IF NOT EXISTS legal_acceptances (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL,
      account_number TEXT NOT NULL,
      role TEXT NOT NULL CHECK(role IN ('customer', 'driver', 'admin')),
      doc_type TEXT NOT NULL CHECK(doc_type IN ('customer_terms', 'driver_terms', 'commission_change')),
      version TEXT NOT NULL,
      commission_percent REAL,
      accepted_at TEXT NOT NULL,
      ip_address TEXT,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS driver_profiles (
      user_id TEXT PRIMARY KEY,
      approval_status TEXT NOT NULL DEFAULT 'pending' CHECK(approval_status IN ('pending', 'approved', 'rejected')),
      rejection_reason TEXT,
      photo_status TEXT NOT NULL DEFAULT 'pending' CHECK(photo_status IN ('pending', 'approved', 'rejected')),
      photo_rejection_reason TEXT,
      pending_avatar_url TEXT,
      car_make TEXT NOT NULL,
      car_model TEXT NOT NULL,
      car_year INTEGER NOT NULL,
      car_color TEXT NOT NULL,
      plate_number TEXT NOT NULL,
      category TEXT NOT NULL CHECK(category IN ('Economy', 'Super', 'Plus', 'Family')),
      license_doc_url TEXT,
      registration_doc_url TEXT,
      national_id_doc_url TEXT,
      is_online INTEGER NOT NULL DEFAULT 0,
      current_lat REAL,
      current_lng REAL,
      current_speed_kmh REAL,
      heading REAL,
      last_location_at TEXT,
      rating_avg REAL NOT NULL DEFAULT 5.0,
      rating_count INTEGER NOT NULL DEFAULT 0,
      agreed_commission_percent REAL,
      commission_agreed_at TEXT,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS pricing_rules (
      id INTEGER PRIMARY KEY CHECK(id = 1),
      base_fare_iqd INTEGER NOT NULL,
      per_km_iqd INTEGER NOT NULL,
      min_fare_iqd INTEGER NOT NULL,
      waiting_fee_per_min_iqd INTEGER NOT NULL,
      cancellation_fee_iqd INTEGER NOT NULL,
      economy_multiplier REAL NOT NULL,
      super_multiplier REAL NOT NULL,
      plus_multiplier REAL NOT NULL,
      family_multiplier REAL NOT NULL,
      commission_percent REAL NOT NULL DEFAULT 10,
      updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS promo_codes (
      id TEXT PRIMARY KEY,
      code TEXT NOT NULL UNIQUE,
      discount_percent INTEGER NOT NULL,
      max_discount_iqd INTEGER NOT NULL,
      is_active INTEGER NOT NULL DEFAULT 1,
      expires_at TEXT,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS plus_settings (
      id INTEGER PRIMARY KEY CHECK(id = 1),
      monthly_price_iqd INTEGER NOT NULL,
      discount_percent INTEGER NOT NULL,
      waive_cancellation_fee INTEGER NOT NULL DEFAULT 1,
      priority_matching_enabled INTEGER NOT NULL DEFAULT 0,
      is_enabled INTEGER NOT NULL DEFAULT 1,
      updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS plus_subscriptions (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL,
      status TEXT NOT NULL CHECK(status IN ('active', 'inactive', 'expired')),
      price_iqd INTEGER NOT NULL,
      starts_at TEXT NOT NULL,
      ends_at TEXT NOT NULL,
      created_at TEXT NOT NULL,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS app_settings (
      id INTEGER PRIMARY KEY CHECK(id = 1),
      dispatch_timeout_sec INTEGER NOT NULL,
      search_radius_km INTEGER NOT NULL,
      allow_driver_registration INTEGER NOT NULL DEFAULT 1,
      emergency_phone TEXT NOT NULL DEFAULT '104',
      updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS rides (
      id TEXT PRIMARY KEY,
      ride_number TEXT,
      customer_id TEXT NOT NULL,
      driver_id TEXT,
      category TEXT NOT NULL CHECK(category IN ('Economy', 'Super', 'Plus', 'Family')),
      status TEXT NOT NULL CHECK(status IN ('searching', 'found', 'on_the_way', 'arrived', 'in_progress', 'completed', 'cancelled')),
      pickup_lat REAL NOT NULL,
      pickup_lng REAL NOT NULL,
      pickup_address TEXT NOT NULL,
      dropoff_lat REAL NOT NULL,
      dropoff_lng REAL NOT NULL,
      dropoff_address TEXT NOT NULL,
      distance_km REAL NOT NULL,
      duration_min INTEGER NOT NULL,
      base_fare_iqd INTEGER NOT NULL,
      distance_fare_iqd INTEGER NOT NULL,
      waiting_minutes INTEGER NOT NULL DEFAULT 0,
      waiting_fee_iqd INTEGER NOT NULL DEFAULT 0,
      discount_iqd INTEGER NOT NULL DEFAULT 0,
      cancellation_fee_iqd INTEGER NOT NULL DEFAULT 0,
      final_fare_iqd INTEGER NOT NULL,
      promo_code TEXT,
      payment_method TEXT NOT NULL DEFAULT 'cash',
      payment_status TEXT NOT NULL DEFAULT 'pending',
      payment_id TEXT,
      commission_percent REAL NOT NULL DEFAULT 10,
      commission_iqd INTEGER NOT NULL DEFAULT 0,
      driver_net_iqd INTEGER NOT NULL DEFAULT 0,
      cancelled_by TEXT,
      cancel_reason TEXT,
      driver_rating INTEGER,
      driver_review TEXT,
      customer_rating INTEGER,
      customer_review TEXT,
      rating_moderated INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL,
      accepted_at TEXT,
      arrived_at TEXT,
      started_at TEXT,
      completed_at TEXT,
      cancelled_at TEXT,
      FOREIGN KEY (customer_id) REFERENCES users(id),
      FOREIGN KEY (driver_id) REFERENCES users(id)
    );

    CREATE TABLE IF NOT EXISTS ride_dispatch_attempts (
      id TEXT PRIMARY KEY,
      ride_id TEXT NOT NULL,
      driver_id TEXT NOT NULL,
      status TEXT NOT NULL CHECK(status IN ('offered', 'accepted', 'rejected', 'timeout')),
      offered_at TEXT NOT NULL,
      expires_at TEXT NOT NULL,
      responded_at TEXT,
      FOREIGN KEY (ride_id) REFERENCES rides(id) ON DELETE CASCADE,
      FOREIGN KEY (driver_id) REFERENCES users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS ride_messages (
      id TEXT PRIMARY KEY,
      ride_id TEXT NOT NULL,
      sender_id TEXT NOT NULL,
      sender_role TEXT NOT NULL CHECK(sender_role IN ('customer', 'driver')),
      body TEXT NOT NULL,
      is_reported INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL,
      FOREIGN KEY (ride_id) REFERENCES rides(id) ON DELETE CASCADE,
      FOREIGN KEY (sender_id) REFERENCES users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS message_reports (
      id TEXT PRIMARY KEY,
      ride_id TEXT NOT NULL,
      message_id TEXT NOT NULL,
      reporter_id TEXT NOT NULL,
      reported_user_id TEXT NOT NULL,
      message_body TEXT NOT NULL,
      reason TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'open' CHECK(status IN ('open', 'reviewed', 'action_taken')),
      admin_note TEXT,
      created_at TEXT NOT NULL,
      FOREIGN KEY (ride_id) REFERENCES rides(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS call_sessions (
      id TEXT PRIMARY KEY,
      ride_id TEXT NOT NULL,
      caller_id TEXT NOT NULL,
      callee_id TEXT NOT NULL,
      mode TEXT NOT NULL CHECK(mode IN ('webrtc_masked', 'pstn_bridge')),
      status TEXT NOT NULL CHECK(status IN ('ringing', 'connected', 'ended', 'missed')),
      started_at TEXT NOT NULL,
      ended_at TEXT,
      FOREIGN KEY (ride_id) REFERENCES rides(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS ride_notification_milestones (
      ride_id TEXT NOT NULL,
      milestone TEXT NOT NULL,
      created_at TEXT NOT NULL,
      PRIMARY KEY (ride_id, milestone),
      FOREIGN KEY (ride_id) REFERENCES rides(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS notifications (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL,
      title TEXT NOT NULL,
      body TEXT NOT NULL,
      type TEXT NOT NULL,
      ride_id TEXT,
      is_read INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS complaints (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL,
      ride_id TEXT,
      category TEXT NOT NULL DEFAULT 'أسباب أخرى',
      subject TEXT NOT NULL,
      message TEXT NOT NULL,
      attachment_url TEXT,
      appeal_context TEXT,
      status TEXT NOT NULL DEFAULT 'open' CHECK(status IN ('open', 'in_review', 'resolved')),
      admin_reply TEXT,
      created_at TEXT NOT NULL,
      resolved_at TEXT,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS sos_alerts (
      id TEXT PRIMARY KEY,
      ride_id TEXT,
      user_id TEXT NOT NULL,
      user_role TEXT NOT NULL CHECK(user_role IN ('customer', 'driver')),
      lat REAL,
      lng REAL,
      incident_type TEXT NOT NULL DEFAULT 'طوارئ عاجلة',
      notes TEXT,
      status TEXT NOT NULL DEFAULT 'active' CHECK(status IN ('active', 'acknowledged', 'resolved', 'cancelled_false_alarm')),
      admin_note TEXT,
      created_at TEXT NOT NULL,
      resolved_at TEXT,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS ride_shares (
      id TEXT PRIMARY KEY,
      ride_id TEXT NOT NULL,
      created_by_user_id TEXT NOT NULL,
      token_hash TEXT NOT NULL UNIQUE,
      is_active INTEGER NOT NULL DEFAULT 1,
      expires_at TEXT NOT NULL,
      created_at TEXT NOT NULL,
      revoked_at TEXT,
      FOREIGN KEY (ride_id) REFERENCES rides(id) ON DELETE CASCADE,
      FOREIGN KEY (created_by_user_id) REFERENCES users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS audit_logs (
      id TEXT PRIMARY KEY,
      actor_user_id TEXT,
      actor_role TEXT NOT NULL,
      action TEXT NOT NULL,
      target_type TEXT NOT NULL,
      target_id TEXT,
      details TEXT,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS revoked_tokens (
      jti TEXT PRIMARY KEY,
      expires_at INTEGER NOT NULL,
      revoked_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS upload_records (
      filename TEXT PRIMARY KEY,
      purpose TEXT NOT NULL CHECK(purpose IN ('avatar', 'driver_doc', 'driver_avatar', 'complaint_attachment')),
      owner_user_id TEXT,
      mime_type TEXT,
      image_blob BLOB,
      sha256 TEXT NOT NULL,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS security_events (
      id TEXT PRIMARY KEY,
      severity TEXT NOT NULL CHECK(severity IN ('low', 'medium', 'high', 'critical')),
      event_type TEXT NOT NULL,
      actor_user_id TEXT,
      ip_address TEXT,
      summary TEXT NOT NULL,
      details TEXT,
      is_resolved INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS backup_records (
      id TEXT PRIMARY KEY,
      filename TEXT NOT NULL,
      size_bytes INTEGER NOT NULL,
      sha256 TEXT NOT NULL,
      encrypted INTEGER NOT NULL DEFAULT 0,
      trigger_type TEXT NOT NULL,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS payment_gateway_configs (
      provider TEXT PRIMARY KEY CHECK(provider IN ('cash', 'superqi', 'zaincash')),
      display_name_ar TEXT NOT NULL,
      is_enabled INTEGER NOT NULL DEFAULT 0,
      merchant_approved INTEGER NOT NULL DEFAULT 0,
      environment TEXT NOT NULL DEFAULT 'pending_approval' CHECK(environment IN ('pending_approval', 'sandbox', 'production')),
      merchant_id TEXT,
      api_base_url TEXT,
      min_topup_iqd INTEGER NOT NULL DEFAULT 5000,
      updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS driver_wallets (
      driver_id TEXT PRIMARY KEY,
      opening_bonus_iqd INTEGER NOT NULL DEFAULT 0,
      opening_bonus_granted_at TEXT,
      bonus_balance_iqd INTEGER NOT NULL DEFAULT 0 CHECK(bonus_balance_iqd >= 0),
      real_balance_iqd INTEGER NOT NULL DEFAULT 0 CHECK(real_balance_iqd >= 0),
      total_topped_up_iqd INTEGER NOT NULL DEFAULT 0,
      total_electronic_earnings_iqd INTEGER NOT NULL DEFAULT 0,
      total_commission_iqd INTEGER NOT NULL DEFAULT 0,
      total_commission_from_bonus_iqd INTEGER NOT NULL DEFAULT 0,
      total_commission_from_real_iqd INTEGER NOT NULL DEFAULT 0,
      uncollected_commission_iqd INTEGER NOT NULL DEFAULT 0,
      auto_paused_zero_balance INTEGER NOT NULL DEFAULT 0,
      updated_at TEXT NOT NULL,
      FOREIGN KEY (driver_id) REFERENCES users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS payment_transactions (
      id TEXT PRIMARY KEY,
      reference_id TEXT NOT NULL UNIQUE,
      purpose TEXT NOT NULL CHECK(purpose IN ('ride_payment', 'driver_wallet_topup')),
      ride_id TEXT,
      user_id TEXT NOT NULL,
      driver_id TEXT,
      provider TEXT NOT NULL CHECK(provider IN ('cash', 'superqi', 'zaincash')),
      amount_iqd INTEGER NOT NULL CHECK(amount_iqd >= 0),
      commission_percent REAL NOT NULL DEFAULT 10,
      commission_iqd INTEGER NOT NULL DEFAULT 0,
      driver_net_iqd INTEGER NOT NULL DEFAULT 0,
      status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending', 'awaiting_gateway', 'confirmed', 'failed', 'cancelled')),
      gateway_transaction_id TEXT,
      checkout_url TEXT,
      verified_source TEXT,
      raw_status TEXT,
      failure_reason TEXT,
      confirmed_at TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS wallet_transactions (
      id TEXT PRIMARY KEY,
      driver_id TEXT NOT NULL,
      ride_id TEXT,
      payment_id TEXT,
      entry_type TEXT NOT NULL CHECK(entry_type IN ('opening_bonus', 'commission_deduction', 'wallet_topup', 'electronic_ride_credit', 'admin_adjustment_real', 'admin_adjustment_bonus')),
      bonus_delta_iqd INTEGER NOT NULL DEFAULT 0,
      real_delta_iqd INTEGER NOT NULL DEFAULT 0,
      bonus_after_iqd INTEGER NOT NULL,
      real_after_iqd INTEGER NOT NULL,
      gross_amount_iqd INTEGER NOT NULL DEFAULT 0,
      commission_iqd INTEGER NOT NULL DEFAULT 0,
      is_real_money INTEGER NOT NULL DEFAULT 0,
      note TEXT NOT NULL,
      created_by_user_id TEXT,
      created_at TEXT NOT NULL,
      FOREIGN KEY (driver_id) REFERENCES users(id) ON DELETE CASCADE
    );

    CREATE INDEX IF NOT EXISTS idx_rides_customer ON rides(customer_id, created_at);
    CREATE INDEX IF NOT EXISTS idx_rides_driver ON rides(driver_id, status);
    CREATE INDEX IF NOT EXISTS idx_rides_status ON rides(status);
    CREATE INDEX IF NOT EXISTS idx_driver_online ON driver_profiles(is_online, approval_status, category);
    CREATE INDEX IF NOT EXISTS idx_dispatch_expires ON ride_dispatch_attempts(status, expires_at);
    CREATE INDEX IF NOT EXISTS idx_notifications_user ON notifications(user_id, created_at);
    CREATE INDEX IF NOT EXISTS idx_security_events_created ON security_events(created_at DESC);
    CREATE INDEX IF NOT EXISTS idx_ride_messages_ride ON ride_messages(ride_id, created_at);
    CREATE INDEX IF NOT EXISTS idx_sos_created ON sos_alerts(created_at DESC);
    CREATE INDEX IF NOT EXISTS idx_ride_shares_ride ON ride_shares(ride_id, is_active);
    CREATE INDEX IF NOT EXISTS idx_payments_user ON payment_transactions(user_id, created_at DESC);
    CREATE INDEX IF NOT EXISTS idx_payments_ride ON payment_transactions(ride_id);
    CREATE INDEX IF NOT EXISTS idx_wallet_tx_driver ON wallet_transactions(driver_id, created_at DESC);
    CREATE UNIQUE INDEX IF NOT EXISTS idx_wallet_tx_opening_bonus ON wallet_transactions(driver_id, entry_type) WHERE entry_type = 'opening_bonus';
    CREATE UNIQUE INDEX IF NOT EXISTS idx_wallet_tx_ride_commission ON wallet_transactions(ride_id, entry_type) WHERE ride_id IS NOT NULL AND entry_type IN ('commission_deduction', 'electronic_ride_credit');
    CREATE UNIQUE INDEX IF NOT EXISTS idx_wallet_tx_payment ON wallet_transactions(payment_id) WHERE payment_id IS NOT NULL;
  `);

  const cols = db.prepare('PRAGMA table_info(users)').all() as Array<{ name: string }>;
  if (!cols.some((c) => c.name === 'token_version')) {
    db.exec('ALTER TABLE users ADD COLUMN token_version INTEGER NOT NULL DEFAULT 1');
  }
  if (!cols.some((c) => c.name === 'rating_avg')) {
    db.exec('ALTER TABLE users ADD COLUMN rating_avg REAL NOT NULL DEFAULT 5.0');
  }
  if (!cols.some((c) => c.name === 'rating_count')) {
    db.exec('ALTER TABLE users ADD COLUMN rating_count INTEGER NOT NULL DEFAULT 0');
  }
  if (!cols.some((c) => c.name === 'account_number')) {
    db.exec('ALTER TABLE users ADD COLUMN account_number TEXT');
  }
  if (!cols.some((c) => c.name === 'terms_accepted_version')) {
    db.exec('ALTER TABLE users ADD COLUMN terms_accepted_version TEXT');
  }
  if (!cols.some((c) => c.name === 'terms_accepted_at')) {
    db.exec('ALTER TABLE users ADD COLUMN terms_accepted_at TEXT');
  }

  const rideCols = db.prepare('PRAGMA table_info(rides)').all() as Array<{ name: string }>;
  if (!rideCols.some((c) => c.name === 'ride_number')) {
    db.exec('ALTER TABLE rides ADD COLUMN ride_number TEXT');
  }
  if (!rideCols.some((c) => c.name === 'customer_rating')) {
    db.exec('ALTER TABLE rides ADD COLUMN customer_rating INTEGER');
  }
  if (!rideCols.some((c) => c.name === 'customer_review')) {
    db.exec('ALTER TABLE rides ADD COLUMN customer_review TEXT');
  }
  if (!rideCols.some((c) => c.name === 'rating_moderated')) {
    db.exec('ALTER TABLE rides ADD COLUMN rating_moderated INTEGER NOT NULL DEFAULT 0');
  }
  if (!rideCols.some((c) => c.name === 'payment_status')) {
    db.exec("ALTER TABLE rides ADD COLUMN payment_status TEXT NOT NULL DEFAULT 'pending'");
  }
  if (!rideCols.some((c) => c.name === 'payment_id')) {
    db.exec('ALTER TABLE rides ADD COLUMN payment_id TEXT');
  }
  if (!rideCols.some((c) => c.name === 'commission_percent')) {
    db.exec('ALTER TABLE rides ADD COLUMN commission_percent REAL NOT NULL DEFAULT 10');
  }
  if (!rideCols.some((c) => c.name === 'commission_iqd')) {
    db.exec('ALTER TABLE rides ADD COLUMN commission_iqd INTEGER NOT NULL DEFAULT 0');
  }
  if (!rideCols.some((c) => c.name === 'driver_net_iqd')) {
    db.exec('ALTER TABLE rides ADD COLUMN driver_net_iqd INTEGER NOT NULL DEFAULT 0');
  }

  const priceCols = db.prepare('PRAGMA table_info(pricing_rules)').all() as Array<{ name: string }>;
  if (!priceCols.some((c) => c.name === 'commission_percent')) {
    db.exec('ALTER TABLE pricing_rules ADD COLUMN commission_percent REAL NOT NULL DEFAULT 10');
  }

  const compCols = db.prepare('PRAGMA table_info(complaints)').all() as Array<{ name: string }>;
  if (!compCols.some((c) => c.name === 'category')) {
    db.exec("ALTER TABLE complaints ADD COLUMN category TEXT NOT NULL DEFAULT 'أسباب أخرى'");
  }
  if (!compCols.some((c) => c.name === 'attachment_url')) {
    db.exec('ALTER TABLE complaints ADD COLUMN attachment_url TEXT');
  }
  if (!compCols.some((c) => c.name === 'appeal_context')) {
    db.exec('ALTER TABLE complaints ADD COLUMN appeal_context TEXT');
  }

  const setCols = db.prepare('PRAGMA table_info(app_settings)').all() as Array<{ name: string }>;
  if (!setCols.some((c) => c.name === 'emergency_phone')) {
    db.exec("ALTER TABLE app_settings ADD COLUMN emergency_phone TEXT NOT NULL DEFAULT '104'");
  }

  const dpCols = db.prepare('PRAGMA table_info(driver_profiles)').all() as Array<{ name: string }>;
  if (!dpCols.some((c) => c.name === 'photo_status')) {
    db.exec("ALTER TABLE driver_profiles ADD COLUMN photo_status TEXT NOT NULL DEFAULT 'pending'");
  }
  if (!dpCols.some((c) => c.name === 'photo_rejection_reason')) {
    db.exec('ALTER TABLE driver_profiles ADD COLUMN photo_rejection_reason TEXT');
  }
  if (!dpCols.some((c) => c.name === 'pending_avatar_url')) {
    db.exec('ALTER TABLE driver_profiles ADD COLUMN pending_avatar_url TEXT');
  }
  if (!dpCols.some((c) => c.name === 'agreed_commission_percent')) {
    db.exec('ALTER TABLE driver_profiles ADD COLUMN agreed_commission_percent REAL');
  }
  if (!dpCols.some((c) => c.name === 'commission_agreed_at')) {
    db.exec('ALTER TABLE driver_profiles ADD COLUMN commission_agreed_at TEXT');
  }

  const uploadTableMeta = db
    .prepare("SELECT sql FROM sqlite_master WHERE type = 'table' AND name = 'upload_records'")
    .get() as { sql?: string } | undefined;
  const uploadCols = db.prepare('PRAGMA table_info(upload_records)').all() as Array<{ name: string }>;
  const hasUploadOwner = uploadCols.some((c) => c.name === 'owner_user_id');
  const hasUploadMime = uploadCols.some((c) => c.name === 'mime_type');
  const hasUploadBlob = uploadCols.some((c) => c.name === 'image_blob');

  if (uploadTableMeta?.sql && !uploadTableMeta.sql.includes('complaint_attachment')) {
    const ownerExpr = hasUploadOwner ? 'owner_user_id' : 'NULL AS owner_user_id';
    const mimeExpr = hasUploadMime ? 'mime_type' : 'NULL AS mime_type';
    const blobExpr = hasUploadBlob ? 'image_blob' : 'NULL AS image_blob';
    db.exec(`
      BEGIN TRANSACTION;
      DROP TABLE IF EXISTS upload_records_new;
      CREATE TABLE upload_records_new (
        filename TEXT PRIMARY KEY,
        purpose TEXT NOT NULL CHECK(purpose IN ('avatar', 'driver_doc', 'driver_avatar', 'complaint_attachment')),
        owner_user_id TEXT,
        mime_type TEXT,
        image_blob BLOB,
        sha256 TEXT NOT NULL,
        created_at TEXT NOT NULL
      );
      INSERT INTO upload_records_new (filename, purpose, owner_user_id, mime_type, image_blob, sha256, created_at)
      SELECT filename, purpose, ${ownerExpr}, ${mimeExpr}, ${blobExpr}, sha256, created_at FROM upload_records;
      DROP TABLE upload_records;
      ALTER TABLE upload_records_new RENAME TO upload_records;
      COMMIT;
    `);
  } else {
    if (!hasUploadOwner) {
      db.exec('ALTER TABLE upload_records ADD COLUMN owner_user_id TEXT');
    }
    if (!hasUploadMime) {
      db.exec('ALTER TABLE upload_records ADD COLUMN mime_type TEXT');
    }
    if (!hasUploadBlob) {
      db.exec('ALTER TABLE upload_records ADD COLUMN image_blob BLOB');
    }
  }

  const now = new Date().toISOString();

  db.prepare(`
    INSERT OR IGNORE INTO pricing_rules (
      id, base_fare_iqd, per_km_iqd, min_fare_iqd, waiting_fee_per_min_iqd,
      cancellation_fee_iqd, economy_multiplier, super_multiplier, plus_multiplier,
      family_multiplier, commission_percent, updated_at
    ) VALUES (1, 2000, 650, 3000, 250, 1500, 1.0, 1.35, 1.75, 1.5, 10, ?)
  `).run(now);

  db.prepare(`
    INSERT OR IGNORE INTO plus_settings (
      id, monthly_price_iqd, discount_percent, waive_cancellation_fee,
      priority_matching_enabled, is_enabled, updated_at
    ) VALUES (1, 15000, 15, 1, 0, 1, ?)
  `).run(now);

  db.prepare(`
    INSERT OR IGNORE INTO app_settings (
      id, dispatch_timeout_sec, search_radius_km, allow_driver_registration, updated_at
    ) VALUES (1, 20, 15, 1, ?)
  `).run(now);

  db.prepare(`
    INSERT OR IGNORE INTO payment_gateway_configs (
      provider, display_name_ar, is_enabled, merchant_approved, environment,
      merchant_id, api_base_url, min_topup_iqd, updated_at
    ) VALUES
      ('cash', 'الدفع النقدي', 1, 1, 'production', 'MISHWAR-CASH', NULL, 0, ?),
      ('superqi', 'سوبر كي (بوابة كي كارد الرسمية)', 0, 0, 'pending_approval', NULL, 'https://gate.qi.iq', 5000, ?),
      ('zaincash', 'زين كاش (بوابة الدفع الرسمية)', 0, 0, 'pending_approval', NULL, 'https://api.zaincash.iq', 5000, ?)
  `).run(now, now, now);

  db.prepare(`
    INSERT OR IGNORE INTO account_sequences (prefix, next_seq) VALUES
      ('MSH-C', 1),
      ('MSH-D', 1),
      ('MSH-A', 1),
      ('MSH-TR', 1)
  `).run();

  // Safe idempotent backfill of sequential account_number and ride_number for legacy rows
  const backfillTx = db.transaction(() => {
    const syncPrefixFloor = (prefix: AccountPrefix, table: 'users' | 'rides', col: 'account_number' | 'ride_number') => {
      const existingRows = db
        .prepare(`SELECT ${col} AS val FROM ${table} WHERE ${col} LIKE ?`)
        .all(`${prefix}-%`) as Array<{ val: string }>;
      let maxNum = 0;
      for (const r of existingRows) {
        const m = r.val.match(/-(\d+)$/);
        if (m) {
          const n = Number(m[1]);
          if (Number.isFinite(n) && n > maxNum) maxNum = n;
        }
      }
      if (maxNum > 0) {
        db.prepare(`UPDATE account_sequences SET next_seq = MAX(next_seq, ?) WHERE prefix = ?`).run(
          maxNum + 1,
          prefix,
        );
      }
    };

    syncPrefixFloor('MSH-C', 'users', 'account_number');
    syncPrefixFloor('MSH-D', 'users', 'account_number');
    syncPrefixFloor('MSH-A', 'users', 'account_number');
    syncPrefixFloor('MSH-TR', 'rides', 'ride_number');

    const missingUsers = db
      .prepare('SELECT id, role FROM users WHERE account_number IS NULL ORDER BY created_at ASC, rowid ASC')
      .all() as Array<{ id: string; role: 'customer' | 'driver' | 'admin' }>;
    for (const u of missingUsers) {
      const prefix: AccountPrefix = u.role === 'driver' ? 'MSH-D' : u.role === 'admin' ? 'MSH-A' : 'MSH-C';
      const accNum = allocateSequenceNumberInTx(prefix);
      db.prepare('UPDATE users SET account_number = ? WHERE id = ?').run(accNum, u.id);
    }

    const missingRides = db
      .prepare('SELECT id FROM rides WHERE ride_number IS NULL ORDER BY created_at ASC, rowid ASC')
      .all() as Array<{ id: string }>;
    for (const r of missingRides) {
      const rideNum = allocateSequenceNumberInTx('MSH-TR');
      db.prepare('UPDATE rides SET ride_number = ? WHERE id = ?').run(rideNum, r.id);
    }

    // Ensure pre-existing drivers have agreed_commission_percent seeded to current active rate
    const activeComm = (
      db.prepare('SELECT commission_percent FROM pricing_rules WHERE id = 1').get() as { commission_percent: number }
    ).commission_percent;
    db.prepare(
      `UPDATE driver_profiles
       SET agreed_commission_percent = ?, commission_agreed_at = COALESCE(commission_agreed_at, ?)
       WHERE agreed_commission_percent IS NULL`,
    ).run(activeComm, now);
  });
  backfillTx.immediate();

  db.exec(`
    CREATE UNIQUE INDEX IF NOT EXISTS idx_users_account_number ON users(account_number);
    CREATE UNIQUE INDEX IF NOT EXISTS idx_rides_ride_number ON rides(ride_number);
    CREATE INDEX IF NOT EXISTS idx_legal_acceptances_user ON legal_acceptances(user_id, doc_type, version);
  `);
}

export type AccountPrefix = 'MSH-C' | 'MSH-D' | 'MSH-A' | 'MSH-TR';

/**
 * Allocates the next strictly sequential immutable code inside an already-active SQLite IMMEDIATE transaction.
 * Deleted rows never decrement `next_seq`, guaranteeing zero reuse or collisions.
 */
export function allocateSequenceNumberInTx(prefix: AccountPrefix): string {
  db.prepare(`INSERT OR IGNORE INTO account_sequences (prefix, next_seq) VALUES (?, 1)`).run(prefix);
  db.prepare(`UPDATE account_sequences SET next_seq = next_seq + 1 WHERE prefix = ?`).run(prefix);
  const row = db.prepare(`SELECT next_seq - 1 AS seq FROM account_sequences WHERE prefix = ?`).get(prefix) as {
    seq: number;
  };
  return `${prefix}-${String(row.seq).padStart(6, '0')}`;
}

export function allocateSequenceNumber(prefix: AccountPrefix): string {
  const tx = db.transaction(() => allocateSequenceNumberInTx(prefix));
  return tx.immediate();
}

export function writeAuditLog(params: {
  actorUserId: string | null;
  actorRole: string;
  action: string;
  targetType: string;
  targetId?: string | null;
  details?: Record<string, unknown> | string | null;
}) {
  const detailsStr =
    typeof params.details === 'string'
      ? params.details
      : params.details
        ? JSON.stringify(params.details)
        : null;
  db.prepare(`
    INSERT INTO audit_logs (id, actor_user_id, actor_role, action, target_type, target_id, details, created_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
  `).run(
    crypto.randomUUID(),
    params.actorUserId,
    params.actorRole,
    params.action,
    params.targetType,
    params.targetId ?? null,
    detailsStr,
    new Date().toISOString(),
  );
}
