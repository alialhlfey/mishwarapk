import crypto from 'crypto';
import { db, writeAuditLog } from './db.ts';
import { recordSecurityEvent } from './security.ts';
import type {
  DriverWallet,
  FinancialAccountingReport,
  PaymentGatewayConfig,
  PaymentMethod,
  PaymentTransaction,
  Ride,
  WalletTransaction,
} from '../src/types/mishwar.ts';

export const OPENING_BONUS_IQD = 10000;

export function getCommissionPercent(): number {
  const row = db.prepare('SELECT commission_percent FROM pricing_rules WHERE id = 1').get() as
    | { commission_percent?: number }
    | undefined;
  const pct = Number(row?.commission_percent ?? 10);
  if (!Number.isFinite(pct) || pct < 0 || pct > 50) return 10;
  return pct;
}

export function computeCommissionSplit(grossIqd: number, pctOverride?: number) {
  const pct = typeof pctOverride === 'number' && Number.isFinite(pctOverride) ? pctOverride : getCommissionPercent();
  const safeGross = Math.max(0, Math.round(grossIqd));
  const commission_iqd = Math.round((safeGross * pct) / 100);
  const driver_net_iqd = Math.max(0, safeGross - commission_iqd);
  return { commission_percent: pct, commission_iqd, driver_net_iqd };
}

export function hasSuperQiEnvCredentials(): boolean {
  return Boolean(
    process.env.SUPERQI_MERCHANT_ID?.trim() &&
      process.env.SUPERQI_API_KEY?.trim() &&
      process.env.SUPERQI_PUBLIC_KEY_PEM?.trim(),
  );
}

export function hasZainCashEnvCredentials(): boolean {
  return Boolean(
    process.env.ZAINCASH_CLIENT_ID?.trim() &&
      process.env.ZAINCASH_CLIENT_SECRET?.trim() &&
      process.env.ZAINCASH_MERCHANT_SECRET?.trim(),
  );
}

const ALLOWED_GATEWAY_HOST_SUFFIXES: Record<'superqi' | 'zaincash', string[]> = {
  superqi: ['.qi.iq', 'qi.iq'],
  zaincash: ['.zaincash.iq', 'zaincash.iq'],
};

export function validateGatewayBaseUrl(rawUrl: string | null | undefined, provider: 'superqi' | 'zaincash'): string {
  if (!rawUrl || !rawUrl.trim()) {
    throw new Error('رابط بوابة الدفع غير مضبوط');
  }
  let parsed: URL;
  try {
    parsed = new URL(rawUrl.trim());
  } catch {
    throw new Error('صيغة رابط بوابة الدفع غير صالحة');
  }
  if (parsed.protocol !== 'https:') {
    throw new Error('يجب أن يستخدم رابط بوابة الدفع بروتوكول HTTPS المشفر فقط');
  }
  const host = parsed.hostname.toLowerCase();
  if (
    host === 'localhost' ||
    host === '127.0.0.1' ||
    host === '::1' ||
    host.startsWith('10.') ||
    host.startsWith('192.168.') ||
    host.startsWith('169.254.') ||
    /^172\.(1[6-9]|2\d|3[0-1])\./.test(host)
  ) {
    throw new Error('رابط بوابة الدفع مرفوض لأسباب أمنية');
  }
  const allowed = ALLOWED_GATEWAY_HOST_SUFFIXES[provider];
  const hostOk = allowed.some((suffix) =>
    suffix.startsWith('.') ? host.endsWith(suffix) : host === suffix,
  );
  if (!hostOk) {
    throw new Error(`يجب أن ينتمي رابط البوابة إلى النطاق الرسمي (${allowed.join(' / ')})`);
  }
  return parsed.origin + parsed.pathname.replace(/\/+$/, '');
}

export function listPaymentGatewayConfigs(): PaymentGatewayConfig[] {
  const rows = db.prepare('SELECT * FROM payment_gateway_configs ORDER BY provider ASC').all() as PaymentGatewayConfig[];
  const order: Record<PaymentMethod, number> = { cash: 0, superqi: 1, zaincash: 2 };
  rows.sort((a, b) => (order[a.provider] ?? 9) - (order[b.provider] ?? 9));

  return rows.map((cfg) => {
    if (cfg.provider === 'cash') {
      const available = cfg.is_enabled === 1;
      return {
        ...cfg,
        credentials_configured: true,
        available,
        unavailable_reason_ar: available ? null : 'الدفع النقدي متوقف حالياً من الإدارة',
      };
    }

    const credsOk = cfg.provider === 'superqi' ? hasSuperQiEnvCredentials() : hasZainCashEnvCredentials();
    const merchantOk = cfg.merchant_approved === 1;
    const enabledOk = cfg.is_enabled === 1;
    const available = credsOk && merchantOk && enabledOk;

    let reason: string | null = null;
    if (!merchantOk) {
      reason = 'بانتظار موافقة حساب التاجر والربط الرسمي';
    } else if (!credsOk) {
      reason = 'بانتظار إدخال مفاتيح الربط الرسمية في إعدادات الخادم';
    } else if (!enabledOk) {
      reason = 'معطل مؤقتاً من لوحة الإدارة';
    }

    return {
      ...cfg,
      credentials_configured: credsOk,
      available,
      unavailable_reason_ar: reason,
    };
  });
}

export function assertGatewayAvailable(provider: PaymentMethod): PaymentGatewayConfig {
  const all = listPaymentGatewayConfigs();
  const found = all.find((c) => c.provider === provider);
  if (!found) {
    throw new Error('طريقة الدفع غير مدعومة');
  }
  if (!found.available) {
    throw new Error(found.unavailable_reason_ar || 'طريقة الدفع غير متاحة حالياً');
  }
  return found;
}

export function getOrCreateDriverWallet(driverId: string): DriverWallet {
  let row = db.prepare('SELECT * FROM driver_wallets WHERE driver_id = ?').get(driverId) as DriverWallet | undefined;
  if (!row) {
    const now = new Date().toISOString();
    db.prepare(
      `INSERT OR IGNORE INTO driver_wallets (driver_id, bonus_balance_iqd, real_balance_iqd, updated_at)
       VALUES (?, 0, 0, ?)`,
    ).run(driverId, now);
    row = db.prepare('SELECT * FROM driver_wallets WHERE driver_id = ?').get(driverId) as DriverWallet;
  }
  return {
    ...row,
    total_available_iqd: row.bonus_balance_iqd + row.real_balance_iqd,
  };
}

export function grantDriverOpeningBonusAtomic(
  driverId: string,
  adminUserId: string | null = null,
): { granted: boolean; wallet: DriverWallet } {
  const now = new Date().toISOString();
  let granted = false;

  const tx = db.transaction(() => {
    db.prepare(
      `INSERT OR IGNORE INTO driver_wallets (driver_id, bonus_balance_iqd, real_balance_iqd, updated_at)
       VALUES (?, 0, 0, ?)`,
    ).run(driverId, now);

    const wallet = db.prepare('SELECT * FROM driver_wallets WHERE driver_id = ?').get(driverId) as DriverWallet;
    const txId = crypto.randomUUID();
    const res = db
      .prepare(
        `INSERT OR IGNORE INTO wallet_transactions (
          id, driver_id, ride_id, payment_id, entry_type,
          bonus_delta_iqd, real_delta_iqd, bonus_after_iqd, real_after_iqd,
          gross_amount_iqd, commission_iqd, is_real_money, note, created_by_user_id, created_at
        ) VALUES (?, ?, NULL, NULL, 'opening_bonus', ?, 0, ?, ?, 0, 0, 0, ?, ?, ?)`,
      )
      .run(
        txId,
        driverId,
        OPENING_BONUS_IQD,
        wallet.bonus_balance_iqd + OPENING_BONUS_IQD,
        wallet.real_balance_iqd,
        'رصيد افتتاحي مجاني عند اعتماد حساب السائق (رصيد سماح افتراضي للعمل غير قابل للسحب)',
        adminUserId,
        now,
      );

    if (res.changes > 0) {
      granted = true;
      db.prepare(
        `UPDATE driver_wallets
         SET opening_bonus_iqd = ?,
             opening_bonus_granted_at = ?,
             bonus_balance_iqd = bonus_balance_iqd + ?,
             updated_at = ?
         WHERE driver_id = ?`,
      ).run(OPENING_BONUS_IQD, now, OPENING_BONUS_IQD, now, driverId);
    }
  });

  tx.immediate();
  return { granted, wallet: getOrCreateDriverWallet(driverId) };
}

export function ensureExistingApprovedDriversHaveOpeningBonus() {
  const approved = db
    .prepare(
      `SELECT dp.user_id FROM driver_profiles dp
       LEFT JOIN driver_wallets dw ON dw.driver_id = dp.user_id
       WHERE dp.approval_status = 'approved' AND dw.driver_id IS NULL`,
    )
    .all() as Array<{ user_id: string }>;
  for (const row of approved) {
    grantDriverOpeningBonusAtomic(row.user_id, null);
  }
}

export function completeRideSettlementAtomic(params: {
  rideId: string;
  rideNumber?: string | null;
  driverId: string;
  customerId: string;
  fareIqd: number;
  paymentMethod: PaymentMethod;
}): {
  commission_percent: number;
  commission_iqd: number;
  driver_net_iqd: number;
  wallet: DriverWallet;
  autoPausedZeroBalance: boolean;
  payment: PaymentTransaction;
} {
  const now = new Date().toISOString();
  const { commission_percent, commission_iqd, driver_net_iqd } = computeCommissionSplit(params.fareIqd);
  let autoPausedZeroBalance = false;
  let createdOrExistingPayment!: PaymentTransaction;

  const tx = db.transaction(() => {
    db.prepare(
      `INSERT OR IGNORE INTO driver_wallets (driver_id, bonus_balance_iqd, real_balance_iqd, updated_at)
       VALUES (?, 0, 0, ?)`,
    ).run(params.driverId, now);

    db.prepare(
      `UPDATE rides
       SET commission_percent = ?, commission_iqd = ?, driver_net_iqd = ?
       WHERE id = ?`,
    ).run(commission_percent, commission_iqd, driver_net_iqd, params.rideId);

    const existingPay = db
      .prepare("SELECT * FROM payment_transactions WHERE ride_id = ? AND purpose = 'ride_payment' LIMIT 1")
      .get(params.rideId) as PaymentTransaction | undefined;

    if (params.paymentMethod === 'cash') {
      if (existingPay) {
        createdOrExistingPayment = existingPay;
      } else {
        const payId = crypto.randomUUID();
        const ref = `MSH-CASH-${params.rideId.slice(0, 8).toUpperCase()}`;
        db.prepare(
          `INSERT INTO payment_transactions (
            id, reference_id, purpose, ride_id, user_id, driver_id, provider,
            amount_iqd, commission_percent, commission_iqd, driver_net_iqd,
            status, verified_source, raw_status, confirmed_at, created_at, updated_at
          ) VALUES (?, ?, 'ride_payment', ?, ?, ?, 'cash', ?, ?, ?, ?, 'confirmed', 'cash_driver_confirm', 'CASH_COLLECTED', ?, ?, ?)`,
        ).run(
          payId,
          ref,
          params.rideId,
          params.customerId,
          params.driverId,
          params.fareIqd,
          commission_percent,
          commission_iqd,
          driver_net_iqd,
          now,
          now,
          now,
        );
        createdOrExistingPayment = db
          .prepare('SELECT * FROM payment_transactions WHERE id = ?')
          .get(payId) as PaymentTransaction;
      }

      db.prepare(`UPDATE rides SET payment_status = 'paid', payment_id = ? WHERE id = ?`).run(
        createdOrExistingPayment.id,
        params.rideId,
      );

      // Idempotent commission deduction (guarded by idx_wallet_tx_ride_commission)
      const alreadyDeducted = db
        .prepare("SELECT id FROM wallet_transactions WHERE ride_id = ? AND entry_type = 'commission_deduction'")
        .get(params.rideId);

      if (!alreadyDeducted) {
        const w = db
          .prepare('SELECT * FROM driver_wallets WHERE driver_id = ?')
          .get(params.driverId) as DriverWallet;

        const fromBonus = Math.min(Math.max(0, w.bonus_balance_iqd), commission_iqd);
        const remainingNeed = Math.max(0, commission_iqd - fromBonus);
        const fromReal = Math.min(Math.max(0, w.real_balance_iqd), remainingNeed);
        const chargedTotal = fromBonus + fromReal;
        const shortfall = Math.max(0, commission_iqd - chargedTotal);

        const nextBonus = Math.max(0, w.bonus_balance_iqd - fromBonus);
        const nextReal = Math.max(0, w.real_balance_iqd - fromReal);
        const nextAvailable = nextBonus + nextReal;
        const reachedZero = nextAvailable <= 0 ? 1 : 0;

        if (reachedZero === 1) {
          autoPausedZeroBalance = true;
          db.prepare('UPDATE driver_profiles SET is_online = 0 WHERE user_id = ?').run(params.driverId);
        }

        db.prepare(
          `UPDATE driver_wallets
           SET bonus_balance_iqd = ?,
               real_balance_iqd = ?,
               total_commission_iqd = total_commission_iqd + ?,
               total_commission_from_bonus_iqd = total_commission_from_bonus_iqd + ?,
               total_commission_from_real_iqd = total_commission_from_real_iqd + ?,
               uncollected_commission_iqd = uncollected_commission_iqd + ?,
               auto_paused_zero_balance = CASE WHEN ? = 1 THEN 1 ELSE auto_paused_zero_balance END,
               updated_at = ?
           WHERE driver_id = ?`,
        ).run(
          nextBonus,
          nextReal,
          chargedTotal,
          fromBonus,
          fromReal,
          shortfall,
          reachedZero,
          now,
          params.driverId,
        );

        const rideRow = db.prepare('SELECT ride_number FROM rides WHERE id = ?').get(params.rideId) as
          | { ride_number?: string | null }
          | undefined;
        const rideRefLabel = params.rideNumber || rideRow?.ride_number || params.rideId.slice(0, 8);
        db.prepare(
          `INSERT INTO wallet_transactions (
            id, driver_id, ride_id, payment_id, entry_type,
            bonus_delta_iqd, real_delta_iqd, bonus_after_iqd, real_after_iqd,
            gross_amount_iqd, commission_iqd, is_real_money, note, created_by_user_id, created_at
          ) VALUES (?, ?, ?, ?, 'commission_deduction', ?, ?, ?, ?, ?, ?, ?, ?, NULL, ?)`,
        ).run(
          crypto.randomUUID(),
          params.driverId,
          params.rideId,
          createdOrExistingPayment.id,
          -fromBonus,
          -fromReal,
          nextBonus,
          nextReal,
          params.fareIqd,
          chargedTotal,
          fromReal > 0 ? 1 : 0,
          `خصم عمولة مشوار (${commission_percent}%) للرحلة ${rideRefLabel}`,
          now,
        );
      }
    } else {
      // Electronic payment: prepare payment transaction if not yet created; driver credit waits for verified gateway confirmation!
      if (existingPay) {
        createdOrExistingPayment = existingPay;
        if (existingPay.amount_iqd !== params.fareIqd && existingPay.status !== 'confirmed') {
          db.prepare(
            `UPDATE payment_transactions
             SET amount_iqd = ?, commission_percent = ?, commission_iqd = ?, driver_net_iqd = ?, updated_at = ?
             WHERE id = ?`,
          ).run(params.fareIqd, commission_percent, commission_iqd, driver_net_iqd, now, existingPay.id);
          createdOrExistingPayment = db
            .prepare('SELECT * FROM payment_transactions WHERE id = ?')
            .get(existingPay.id) as PaymentTransaction;
        }
      } else {
        const payId = crypto.randomUUID();
        const ref = `MSH-RIDE-${Date.now()}-${crypto.randomUUID().slice(0, 6).toUpperCase()}`;
        db.prepare(
          `INSERT INTO payment_transactions (
            id, reference_id, purpose, ride_id, user_id, driver_id, provider,
            amount_iqd, commission_percent, commission_iqd, driver_net_iqd,
            status, created_at, updated_at
          ) VALUES (?, ?, 'ride_payment', ?, ?, ?, ?, ?, ?, ?, ?, 'pending', ?, ?)`,
        ).run(
          payId,
          ref,
          params.rideId,
          params.customerId,
          params.driverId,
          params.paymentMethod,
          params.fareIqd,
          commission_percent,
          commission_iqd,
          driver_net_iqd,
          now,
          now,
        );
        createdOrExistingPayment = db
          .prepare('SELECT * FROM payment_transactions WHERE id = ?')
          .get(payId) as PaymentTransaction;
      }
      db.prepare(`UPDATE rides SET payment_id = ? WHERE id = ?`).run(createdOrExistingPayment.id, params.rideId);
    }
  });

  tx.immediate();

  return {
    commission_percent,
    commission_iqd,
    driver_net_iqd,
    wallet: getOrCreateDriverWallet(params.driverId),
    autoPausedZeroBalance,
    payment: createdOrExistingPayment,
  };
}

export async function initiateOfficialGatewayCheckout(params: {
  payment: PaymentTransaction;
  appBaseUrl: string;
  description: string;
}): Promise<{ checkoutUrl: string; gatewayTransactionId: string }> {
  if (params.payment.provider !== 'superqi' && params.payment.provider !== 'zaincash') {
    throw new Error('طريقة الدفع لا تدعم بوابة الدفع الإلكتروني');
  }

  const cfg = assertGatewayAvailable(params.payment.provider);
  const envUrl =
    params.payment.provider === 'superqi'
      ? process.env.SUPERQI_API_BASE_URL
      : process.env.ZAINCASH_API_BASE_URL;
  const baseUrl = validateGatewayBaseUrl(envUrl || cfg.api_base_url, params.payment.provider);

  const safeCallbackBase = params.appBaseUrl.replace(/\/+$/, '');

  if (params.payment.provider === 'superqi') {
    const merchantId = process.env.SUPERQI_MERCHANT_ID!.trim();
    const apiKey = process.env.SUPERQI_API_KEY!.trim();
    const authHeader = apiKey.includes(':')
      ? `Basic ${Buffer.from(apiKey).toString('base64')}`
      : `Bearer ${apiKey}`;

    const resp = await fetch(`${baseUrl}/api/v1/payment`, {
      method: 'POST',
      headers: {
        Authorization: authHeader,
        'Content-Type': 'application/json',
        'X-Terminal-Id': merchantId,
      },
      body: JSON.stringify({
        requestId: params.payment.reference_id,
        amount: params.payment.amount_iqd,
        currency: 'IQD',
        description: params.description,
        finishPaymentUrl: `${safeCallbackBase}/?payment_ref=${encodeURIComponent(params.payment.reference_id)}`,
        notificationUrl: `${safeCallbackBase}/api/payments/superqi/webhook`,
      }),
    });

    const data = (await resp.json().catch(() => ({}))) as {
      paymentId?: string;
      formUrl?: string;
      redirectUrl?: string;
      message?: string;
    };
    const checkoutUrl = data.formUrl || data.redirectUrl;
    if (!resp.ok || !checkoutUrl) {
      throw new Error(data.message || 'تعذر إنشاء جلسة الدفع عبر بوابة كي كارد / سوبر كي');
    }
    return {
      checkoutUrl,
      gatewayTransactionId: data.paymentId || params.payment.reference_id,
    };
  }

  // ZainCash Official Merchant API v2 (OAuth2 Client Credentials + /api/v2/payment-gateway/transaction/init)
  const clientId = process.env.ZAINCASH_CLIENT_ID!.trim();
  const clientSecret = process.env.ZAINCASH_CLIENT_SECRET!.trim();

  const tokenResp = await fetch(`${baseUrl}/oauth2/token`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({
      grant_type: 'client_credentials',
      client_id: clientId,
      client_secret: clientSecret,
    }),
  });
  const tokenJson = (await tokenResp.json().catch(() => ({}))) as { access_token?: string; error?: string };
  if (!tokenResp.ok || !tokenJson.access_token) {
    throw new Error(tokenJson.error || 'فشل المصادقة مع بوابة زين كاش الرسمية');
  }

  const initResp = await fetch(`${baseUrl}/api/v2/payment-gateway/transaction/init`, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${tokenJson.access_token}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      amount: params.payment.amount_iqd,
      currency: 'IQD',
      externalReferenceId: params.payment.reference_id,
      orderId: params.payment.reference_id,
      redirectLang: 'ar',
      successUrl: `${safeCallbackBase}/api/payments/zaincash/callback`,
      failureUrl: `${safeCallbackBase}/api/payments/zaincash/callback`,
      description: params.description,
    }),
  });
  const initJson = (await initResp.json().catch(() => ({}))) as {
    transactionId?: string;
    redirectUrl?: string;
    message?: string;
  };
  if (!initResp.ok || !initJson.redirectUrl) {
    throw new Error(initJson.message || 'تعذر بدء عملية الدفع عبر بوابة زين كاش الرسمية');
  }
  return {
    checkoutUrl: initJson.redirectUrl,
    gatewayTransactionId: initJson.transactionId || params.payment.reference_id,
  };
}

export function verifySuperQiRsaSignature(rawPayload: Buffer | string, signatureBase64: string): boolean {
  const pubPem = process.env.SUPERQI_PUBLIC_KEY_PEM?.trim();
  if (!pubPem || !signatureBase64) return false;
  try {
    const data = typeof rawPayload === 'string' ? Buffer.from(rawPayload, 'utf8') : rawPayload;
    const sig = Buffer.from(signatureBase64.trim(), 'base64');
    return crypto.verify('RSA-SHA256', data, pubPem, sig);
  } catch {
    return false;
  }
}

export interface VerifiedZainCashJwt {
  id?: string;
  transactionId?: string;
  orderId?: string;
  externalReferenceId?: string;
  status?: string;
  amount?: number;
  currency?: string;
  msg?: string;
  exp?: number;
}

export function verifyZainCashJwtToken(token: string): VerifiedZainCashJwt | null {
  const secret = process.env.ZAINCASH_MERCHANT_SECRET?.trim();
  if (!secret || !token) return null;
  const parts = token.split('.');
  if (parts.length !== 3) return null;
  const [headerB64, payloadB64, sigB64] = parts;
  try {
    const header = JSON.parse(Buffer.from(headerB64, 'base64url').toString('utf8')) as { alg?: string };
    if (header.alg !== 'HS256') return null;

    const expectedSig = crypto
      .createHmac('sha256', secret)
      .update(`${headerB64}.${payloadB64}`)
      .digest();
    const actualSig = Buffer.from(sigB64, 'base64url');
    if (expectedSig.length !== actualSig.length || !crypto.timingSafeEqual(expectedSig, actualSig)) {
      return null;
    }

    const payload = JSON.parse(Buffer.from(payloadB64, 'base64url').toString('utf8')) as VerifiedZainCashJwt;
    if (payload.exp && Date.now() / 1000 > payload.exp) {
      return null;
    }
    return payload;
  } catch {
    return null;
  }
}

export function confirmPaymentTransactionAtomic(params: {
  referenceId: string;
  provider: 'superqi' | 'zaincash';
  gatewayTransactionId: string;
  verifiedAmountIqd: number;
  verifiedCurrency: string;
  verifiedSource: string;
  rawStatus: string;
}): {
  alreadyConfirmed: boolean;
  payment: PaymentTransaction;
  driverIdReactivated: string | null;
  rideUpdatedId: string | null;
} {
  const now = new Date().toISOString();
  let alreadyConfirmed = false;
  let driverIdReactivated: string | null = null;
  let rideUpdatedId: string | null = null;
  let finalPayment!: PaymentTransaction;
  let tamperingEvent: Parameters<typeof recordSecurityEvent>[0] | null = null;

  const tx = db.transaction(() => {
    const payment = db
      .prepare('SELECT * FROM payment_transactions WHERE reference_id = ? AND provider = ?')
      .get(params.referenceId, params.provider) as PaymentTransaction | undefined;
    if (!payment) {
      throw new Error('معاملة الدفع غير موجودة');
    }

    if (
      params.verifiedCurrency.toUpperCase() !== 'IQD' ||
      Math.round(params.verifiedAmountIqd) !== payment.amount_iqd
    ) {
      tamperingEvent = {
        severity: 'critical',
        eventType: 'payment_tampering_detected',
        actorUserId: payment.user_id,
        summary: `تعارض في مبلغ أو عملة الدفع المؤكد (${payment.reference_id}) — المتوقع ${payment.amount_iqd} IQD والمستلم ${params.verifiedAmountIqd} ${params.verifiedCurrency}`,
        details: { paymentId: payment.id, referenceId: payment.reference_id, params },
      };
      return;
    }

    if (payment.status === 'confirmed') {
      alreadyConfirmed = true;
      finalPayment = payment;
      return;
    }

    db.prepare(
      `UPDATE payment_transactions
       SET status = 'confirmed',
           gateway_transaction_id = COALESCE(?, gateway_transaction_id),
           verified_source = ?,
           raw_status = ?,
           confirmed_at = ?,
           updated_at = ?
       WHERE id = ?`,
    ).run(params.gatewayTransactionId, params.verifiedSource, params.rawStatus, now, now, payment.id);

    finalPayment = db
      .prepare('SELECT * FROM payment_transactions WHERE id = ?')
      .get(payment.id) as PaymentTransaction;

    if (payment.purpose === 'driver_wallet_topup' && payment.driver_id) {
      db.prepare(
        `INSERT OR IGNORE INTO driver_wallets (driver_id, bonus_balance_iqd, real_balance_iqd, updated_at)
         VALUES (?, 0, 0, ?)`,
      ).run(payment.driver_id, now);

      const wallet = db
        .prepare('SELECT * FROM driver_wallets WHERE driver_id = ?')
        .get(payment.driver_id) as DriverWallet;

      const ledgerRes = db
        .prepare(
          `INSERT OR IGNORE INTO wallet_transactions (
            id, driver_id, ride_id, payment_id, entry_type,
            bonus_delta_iqd, real_delta_iqd, bonus_after_iqd, real_after_iqd,
            gross_amount_iqd, commission_iqd, is_real_money, note, created_by_user_id, created_at
          ) VALUES (?, ?, NULL, ?, 'wallet_topup', 0, ?, ?, ?, ?, 0, 1, ?, ?, ?)`,
        )
        .run(
          crypto.randomUUID(),
          payment.driver_id,
          payment.id,
          payment.amount_iqd,
          wallet.bonus_balance_iqd,
          wallet.real_balance_iqd + payment.amount_iqd,
          payment.amount_iqd,
          `شحن محفظة السائق عبر ${params.provider === 'superqi' ? 'سوبر كي' : 'زين كاش'} (${payment.reference_id})`,
          payment.user_id,
          now,
        );

      if (ledgerRes.changes > 0) {
        const nextReal = wallet.real_balance_iqd + payment.amount_iqd;
        const canReactivate = wallet.auto_paused_zero_balance === 1 && wallet.bonus_balance_iqd + nextReal > 0;
        db.prepare(
          `UPDATE driver_wallets
           SET real_balance_iqd = ?,
               total_topped_up_iqd = total_topped_up_iqd + ?,
               auto_paused_zero_balance = CASE WHEN ? THEN 0 ELSE auto_paused_zero_balance END,
               updated_at = ?
           WHERE driver_id = ?`,
        ).run(nextReal, payment.amount_iqd, canReactivate ? 1 : 0, now, payment.driver_id);

        if (canReactivate) {
          const dp = db
            .prepare(
              `SELECT dp.approval_status, u.status
               FROM driver_profiles dp JOIN users u ON u.id = dp.user_id
               WHERE dp.user_id = ?`,
            )
            .get(payment.driver_id) as { approval_status: string; status: string } | undefined;
          if (dp && dp.approval_status === 'approved' && dp.status === 'active') {
            db.prepare('UPDATE driver_profiles SET is_online = 1 WHERE user_id = ?').run(payment.driver_id);
            driverIdReactivated = payment.driver_id;
          }
        }
      }
    } else if (payment.purpose === 'ride_payment' && payment.ride_id) {
      rideUpdatedId = payment.ride_id;
      const { commission_percent, commission_iqd, driver_net_iqd } = computeCommissionSplit(
        payment.amount_iqd,
        payment.commission_percent,
      );
      db.prepare(
        `UPDATE rides
         SET payment_status = 'paid',
             payment_id = ?,
             payment_method = ?,
             commission_percent = ?,
             commission_iqd = ?,
             driver_net_iqd = ?
         WHERE id = ?`,
      ).run(payment.id, params.provider, commission_percent, commission_iqd, driver_net_iqd, payment.ride_id);

      const ride = db.prepare('SELECT driver_id, ride_number FROM rides WHERE id = ?').get(payment.ride_id) as
        | { driver_id: string | null; ride_number?: string | null }
        | undefined;
      const targetDriverId = payment.driver_id || ride?.driver_id;

      if (targetDriverId) {
        db.prepare(
          `INSERT OR IGNORE INTO driver_wallets (driver_id, bonus_balance_iqd, real_balance_iqd, updated_at)
           VALUES (?, 0, 0, ?)`,
        ).run(targetDriverId, now);

        const wallet = db
          .prepare('SELECT * FROM driver_wallets WHERE driver_id = ?')
          .get(targetDriverId) as DriverWallet;

        const rideRefLabel = ride?.ride_number || payment.ride_id.slice(0, 8);
        const ledgerRes = db
          .prepare(
            `INSERT OR IGNORE INTO wallet_transactions (
              id, driver_id, ride_id, payment_id, entry_type,
              bonus_delta_iqd, real_delta_iqd, bonus_after_iqd, real_after_iqd,
              gross_amount_iqd, commission_iqd, is_real_money, note, created_by_user_id, created_at
            ) VALUES (?, ?, ?, ?, 'electronic_ride_credit', 0, ?, ?, ?, ?, ?, 1, ?, ?, ?)`,
          )
          .run(
            crypto.randomUUID(),
            targetDriverId,
            payment.ride_id,
            payment.id,
            driver_net_iqd,
            wallet.bonus_balance_iqd,
            wallet.real_balance_iqd + driver_net_iqd,
            payment.amount_iqd,
            commission_iqd,
            `صافي مستحقات الرحلة ${rideRefLabel} عبر ${params.provider === 'superqi' ? 'سوبر كي' : 'زين كاش'} بعد خصم ${commission_percent}% عمولة`,
            payment.user_id,
            now,
          );

        if (ledgerRes.changes > 0) {
          const nextReal = wallet.real_balance_iqd + driver_net_iqd;
          const canReactivate = wallet.auto_paused_zero_balance === 1 && wallet.bonus_balance_iqd + nextReal > 0;
          db.prepare(
            `UPDATE driver_wallets
             SET real_balance_iqd = ?,
                 total_electronic_earnings_iqd = total_electronic_earnings_iqd + ?,
                 total_commission_iqd = total_commission_iqd + ?,
                 total_commission_from_real_iqd = total_commission_from_real_iqd + ?,
                 auto_paused_zero_balance = CASE WHEN ? THEN 0 ELSE auto_paused_zero_balance END,
                 updated_at = ?
             WHERE driver_id = ?`,
          ).run(nextReal, driver_net_iqd, commission_iqd, commission_iqd, canReactivate ? 1 : 0, now, targetDriverId);

          if (canReactivate) {
            const dp = db
              .prepare(
                `SELECT dp.approval_status, u.status
                 FROM driver_profiles dp JOIN users u ON u.id = dp.user_id
                 WHERE dp.user_id = ?`,
              )
              .get(targetDriverId) as { approval_status: string; status: string } | undefined;
            if (dp && dp.approval_status === 'approved' && dp.status === 'active') {
              db.prepare('UPDATE driver_profiles SET is_online = 1 WHERE user_id = ?').run(targetDriverId);
              driverIdReactivated = targetDriverId;
            }
          }
        }
      }
    }
  });

  tx.immediate();
  if (tamperingEvent) {
    recordSecurityEvent(tamperingEvent);
    throw new Error('عدم تطابق مبلغ أو عملة العملية مع سجل الخادم');
  }
  return { alreadyConfirmed, payment: finalPayment, driverIdReactivated, rideUpdatedId };
}

export function adjustDriverWalletByAdmin(params: {
  driverId: string;
  adminUserId: string;
  walletPool: 'real' | 'bonus';
  deltaIqd: number;
  reason: string;
}): { wallet: DriverWallet; reactivated: boolean } {
  const cleanReason = params.reason.trim();
  if (!cleanReason) {
    throw new Error('يجب إدخال سبب واضح لتعديل رصيد المحفظة');
  }
  const delta = Math.round(Number(params.deltaIqd));
  if (!Number.isFinite(delta) || delta === 0) {
    throw new Error('قيمة التعديل غير صالحة');
  }

  const now = new Date().toISOString();
  let reactivated = false;

  const tx = db.transaction(() => {
    db.prepare(
      `INSERT OR IGNORE INTO driver_wallets (driver_id, bonus_balance_iqd, real_balance_iqd, updated_at)
       VALUES (?, 0, 0, ?)`,
    ).run(params.driverId, now);

    const w = db.prepare('SELECT * FROM driver_wallets WHERE driver_id = ?').get(params.driverId) as DriverWallet;
    const nextBonus = params.walletPool === 'bonus' ? w.bonus_balance_iqd + delta : w.bonus_balance_iqd;
    const nextReal = params.walletPool === 'real' ? w.real_balance_iqd + delta : w.real_balance_iqd;

    if (nextBonus < 0 || nextReal < 0) {
      throw new Error('لا يُسمح أبداً بأن يصبح رصيد المحفظة سالباً');
    }

    const willReachZero = nextBonus + nextReal <= 0;
    const canReactivate = !willReachZero && w.auto_paused_zero_balance === 1;

    db.prepare(
      `UPDATE driver_wallets
       SET bonus_balance_iqd = ?,
           real_balance_iqd = ?,
           auto_paused_zero_balance = CASE WHEN ? THEN 1 WHEN ? THEN 0 ELSE auto_paused_zero_balance END,
           updated_at = ?
       WHERE driver_id = ?`,
    ).run(nextBonus, nextReal, willReachZero ? 1 : 0, canReactivate ? 1 : 0, now, params.driverId);

    if (willReachZero) {
      db.prepare('UPDATE driver_profiles SET is_online = 0 WHERE user_id = ?').run(params.driverId);
    } else if (canReactivate) {
      const dp = db
        .prepare(
          `SELECT dp.approval_status, u.status FROM driver_profiles dp JOIN users u ON u.id = dp.user_id WHERE dp.user_id = ?`,
        )
        .get(params.driverId) as { approval_status: string; status: string } | undefined;
      if (dp && dp.approval_status === 'approved' && dp.status === 'active') {
        db.prepare('UPDATE driver_profiles SET is_online = 1 WHERE user_id = ?').run(params.driverId);
        reactivated = true;
      }
    }

    db.prepare(
      `INSERT INTO wallet_transactions (
        id, driver_id, ride_id, payment_id, entry_type,
        bonus_delta_iqd, real_delta_iqd, bonus_after_iqd, real_after_iqd,
        gross_amount_iqd, commission_iqd, is_real_money, note, created_by_user_id, created_at
      ) VALUES (?, ?, NULL, NULL, ?, ?, ?, ?, ?, 0, 0, ?, ?, ?, ?)`,
    ).run(
      crypto.randomUUID(),
      params.driverId,
      params.walletPool === 'real' ? 'admin_adjustment_real' : 'admin_adjustment_bonus',
      params.walletPool === 'bonus' ? delta : 0,
      params.walletPool === 'real' ? delta : 0,
      nextBonus,
      nextReal,
      params.walletPool === 'real' ? 1 : 0,
      `تعديل إداري (${params.walletPool === 'real' ? 'رصيد حقيقي' : 'رصيد سماح'}): ${cleanReason}`,
      params.adminUserId,
      now,
    );
  });

  tx.immediate();

  writeAuditLog({
    actorUserId: params.adminUserId,
    actorRole: 'admin',
    action: 'wallet.admin_adjusted',
    targetType: 'driver_wallet',
    targetId: params.driverId,
    details: { walletPool: params.walletPool, deltaIqd: delta, reason: cleanReason },
  });

  return { wallet: getOrCreateDriverWallet(params.driverId), reactivated };
}

export function getFinancialAccountingReport(): FinancialAccountingReport {
  const walletSums = db
    .prepare(
      `SELECT
        COALESCE(SUM(opening_bonus_iqd), 0) AS virtual_opening_bonuses_granted_iqd,
        COALESCE(SUM(bonus_balance_iqd), 0) AS virtual_opening_bonus_remaining_iqd,
        COALESCE(SUM(total_topped_up_iqd), 0) AS real_topups_confirmed_iqd,
        COALESCE(SUM(real_balance_iqd), 0) AS real_wallet_balances_total_iqd,
        COALESCE(SUM(total_commission_iqd), 0) AS total_commissions_charged_iqd,
        COALESCE(SUM(total_commission_from_bonus_iqd), 0) AS commissions_covered_by_virtual_bonus_iqd,
        COALESCE(SUM(total_commission_from_real_iqd), 0) AS commissions_collected_real_cash_iqd,
        COALESCE(SUM(total_electronic_earnings_iqd), 0) AS electronic_driver_net_payable_iqd,
        COALESCE(SUM(uncollected_commission_iqd), 0) AS uncollected_commissions_iqd
       FROM driver_wallets`,
    )
    .get() as Omit<FinancialAccountingReport, 'electronic_gross_volume_iqd' | 'cash_rides_gross_volume_iqd'>;

  const cashVolume = (
    db
      .prepare("SELECT COALESCE(SUM(final_fare_iqd), 0) AS s FROM rides WHERE status = 'completed' AND payment_method = 'cash'")
      .get() as { s: number }
  ).s;

  const electronicVolume = (
    db
      .prepare(
        "SELECT COALESCE(SUM(amount_iqd), 0) AS s FROM payment_transactions WHERE purpose = 'ride_payment' AND provider IN ('superqi', 'zaincash') AND status = 'confirmed'",
      )
      .get() as { s: number }
  ).s;

  return {
    ...walletSums,
    electronic_gross_volume_iqd: electronicVolume,
    cash_rides_gross_volume_iqd: cashVolume,
  };
}
