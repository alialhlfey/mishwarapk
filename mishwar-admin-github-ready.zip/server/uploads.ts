import crypto from 'crypto';
import fs from 'fs';
import path from 'path';
import { db } from './db.ts';

export const UPLOADS_DIR = path.resolve(process.cwd(), 'data', 'uploads');
fs.mkdirSync(UPLOADS_DIR, { recursive: true });

const ALLOWED_MIME: Record<string, { ext: string; magic: number[]; normalizedMime: string }> = {
  'image/jpeg': { ext: 'jpg', magic: [0xff, 0xd8, 0xff], normalizedMime: 'image/jpeg' },
  'image/jpg': { ext: 'jpg', magic: [0xff, 0xd8, 0xff], normalizedMime: 'image/jpeg' },
  'image/png': { ext: 'png', magic: [0x89, 0x50, 0x4e, 0x47], normalizedMime: 'image/png' },
  'image/webp': { ext: 'webp', magic: [0x52, 0x49, 0x46, 0x46], normalizedMime: 'image/webp' },
};

export type UploadPurpose = 'avatar' | 'driver_doc' | 'driver_avatar' | 'complaint_attachment';

export function saveUploadedImageBase64(
  dataUrl: string,
  purpose: UploadPurpose = 'avatar',
  ownerUserId: string | null = null,
): string {
  if (typeof dataUrl !== 'string') {
    throw new Error('صيغة الملف غير صالحة');
  }
  const match = dataUrl.match(/^data:(image\/(?:jpeg|jpg|png|webp));base64,([A-Za-z0-9+/=]+)$/);
  if (!match) {
    throw new Error('يجب رفع صورة بصيغة JPG أو PNG أو WebP فقط');
  }
  const mime = match[1].toLowerCase();
  const rule = ALLOWED_MIME[mime];
  if (!rule) {
    throw new Error('نوع الصورة غير مدعوم');
  }
  const buffer = Buffer.from(match[2], 'base64');
  if (buffer.length < 8 || buffer.length > 5 * 1024 * 1024) {
    throw new Error('حجم الصورة يجب أن يكون بين 8 بايت و 5 ميجابايت');
  }

  // Verify actual binary magic bytes to block disguised HTML/script payloads
  const magicOk = rule.magic.every((byte, idx) => buffer[idx] === byte);
  if (!magicOk) {
    throw new Error('محتوى الملف لا يطابق صيغة الصورة المحددة');
  }

  const filename = `${crypto.randomUUID()}.${rule.ext}`;
  const resolved = path.resolve(UPLOADS_DIR, filename);
  if (!resolved.startsWith(UPLOADS_DIR + path.sep)) {
    throw new Error('مسار غير صالح');
  }
  fs.writeFileSync(resolved, buffer);
  const sha256 = crypto.createHash('sha256').update(buffer).digest('hex');

  db.prepare(
    `INSERT INTO upload_records (filename, purpose, owner_user_id, mime_type, image_blob, sha256, created_at)
     VALUES (?, ?, ?, ?, ?, ?, ?)`,
  ).run(filename, purpose, ownerUserId, rule.normalizedMime, buffer, sha256, new Date().toISOString());

  return `/api/uploads/${filename}`;
}

export function getUploadRecord(filename: string) {
  if (!/^[a-f0-9-]+\.(jpg|png|webp)$/i.test(filename)) {
    return null;
  }
  return db.prepare('SELECT filename, purpose, owner_user_id, mime_type, image_blob, sha256, created_at FROM upload_records WHERE filename = ?').get(filename) as
    | {
        filename: string;
        purpose: UploadPurpose;
        owner_user_id: string | null;
        mime_type: string | null;
        image_blob: Buffer | null;
        sha256: string;
      }
    | undefined;
}

export function resolveSafeUploadPath(filename: string): string | null {
  if (!/^[a-f0-9-]+\.(jpg|png|webp)$/i.test(filename)) {
    return null;
  }
  const resolved = path.resolve(UPLOADS_DIR, filename);
  if (!resolved.startsWith(UPLOADS_DIR + path.sep)) {
    return null;
  }
  if (!fs.existsSync(resolved)) {
    return null;
  }
  return resolved;
}
