import React, { useCallback, useEffect, useState } from 'react';
import { AdminDashboard } from './components/AdminDashboard';
import { OfflineIndicator, PWAInstallBanner, PWAInstallButton } from './components/PWAInstallButton';
import { apiRequest } from './lib/api';
import type { User } from './types/mishwar';

const DEFAULT_DOCUMENT_TITLE = 'MISHWAR – إدارة مشوار | لوحة التحكم';

export default function App() {
  const [auth, setAuth] = useState<{ token: string | null; user: User | null }>({
    token: null,
    user: null,
  });
  const [alertCount, setAlertCount] = useState(0);

  const handleAlertCount = useCallback((count: number) => {
    setAlertCount((prev) => (prev === count ? prev : count));
  }, []);

  useEffect(() => {
    document.title = alertCount > 0 ? `(${alertCount}) إدارة مشوار` : DEFAULT_DOCUMENT_TITLE;
    const nav = navigator as Navigator & {
      setAppBadge?: (contents?: number) => Promise<void>;
      clearAppBadge?: () => Promise<void>;
    };
    if (alertCount > 0) {
      nav.setAppBadge?.(alertCount).catch(() => {});
    } else {
      nav.clearAppBadge?.().catch(() => {});
    }
  }, [alertCount]);

  const handleLogout = async () => {
    if (auth.token) {
      await apiRequest('/api/auth/logout', { method: 'POST', token: auth.token }).catch(() => {});
    }
    setAlertCount(0);
    setAuth({ token: null, user: null });
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col">
      <header className="sticky top-0 z-30 bg-white/95 backdrop-blur-md border-b border-slate-200">
        <div className="max-w-[1440px] mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-4">
          <div className="flex items-center gap-2.5 text-lg font-extrabold font-display text-slate-900 whitespace-nowrap shrink-0">
            <img
              src="/src/assets/images/mishwar_brand_mark_1795221944568.jpg"
              alt="شعار مشوار"
              className="w-8 h-8 rounded-lg object-cover"
              referrerPolicy="no-referrer"
            />
            <span>إدارة مشوار — لوحة التحكم</span>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <PWAInstallButton />
          </div>
        </div>
      </header>

      <PWAInstallBanner />

      <div className="flex-1">
        <AdminDashboard
          token={auth.token}
          user={auth.user}
          onAuthSuccess={(token, user) => setAuth({ token, user })}
          onLogout={handleLogout}
          onUnreadCountChange={handleAlertCount}
        />
      </div>

      <OfflineIndicator />
    </div>
  );
}
