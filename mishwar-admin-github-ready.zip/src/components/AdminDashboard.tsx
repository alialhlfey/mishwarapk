import React, { useCallback, useEffect, useState } from 'react';
import {
  AlertTriangle,
  Car,
  CheckCircle,
  CreditCard,
  Crown,
  Database,
  Download,
  FileText,
  HeadphonesIcon,
  LayoutDashboard,
  Link2,
  LogOut,
  MapPin,
  RefreshCw,
  Search,
  Send,
  Settings,
  ShieldAlert,
  ShieldCheck,
  Siren,
  Star,
  Tag,
  Users,
  Wallet,
  XCircle,
} from 'lucide-react';
import {
  apiRequest,
  createSocketConnection,
  fetchProtectedImageBlobUrl,
  formatDateTimeAr,
  formatIQD,
  resolveApiUrl,
} from '../lib/api';
import {
  CATEGORY_LABELS,
  PAYMENT_METHOD_LABELS,
  RIDE_STATUS_LABELS,
  type AppSettings,
  type AuditLog,
  type BackupRecord,
  type Complaint,
  type DriverProfile,
  type DriverWallet,
  type FinancialAccountingReport,
  type MessageReport,
  type PaymentGatewayConfig,
  type PaymentTransaction,
  type PlusSettings,
  type PlusSubscription,
  type PricingRules,
  type PromoCode,
  type Ride,
  type RideShareRecord,
  type SecurityEvent,
  type SosAlert,
  type User,
  type WalletTransaction,
} from '../types/mishwar';
import { MishwarMap, type FleetMarker } from './MishwarMap';
import { ProtectedImage } from './ProtectedImage';

interface AdminDashboardProps {
  token: string | null;
  user: User | null;
  onAuthSuccess: (token: string, user: User) => void;
  onLogout: () => void;
  onUnreadCountChange?: (count: number) => void;
}

type AdminTab =
  | 'overview'
  | 'sos'
  | 'drivers'
  | 'customers_rides'
  | 'finance'
  | 'ratings'
  | 'pricing'
  | 'plus'
  | 'support_reports'
  | 'shares'
  | 'security';

interface RatingRow {
  id: string;
  ride_number?: string;
  category: Ride['category'];
  driver_rating: number | null;
  driver_review: string | null;
  customer_rating: number | null;
  customer_review: string | null;
  rating_moderated: number;
  completed_at: string | null;
  pickup_address: string;
  dropoff_address: string;
  customer_name: string;
  customer_account_number?: string;
  driver_name: string | null;
  driver_account_number?: string | null;
}

interface ReportedUserRow {
  id: string;
  account_number?: string;
  name: string;
  phone: string;
  role: string;
  status: 'active' | 'suspended';
  rating_avg: number;
  report_count: number;
  latest_reason: string;
  latest_at: string;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({
  token,
  user,
  onAuthSuccess,
  onLogout,
  onUnreadCountChange,
}) => {
  // Bootstrap & Auth
  const [bootstrap, setBootstrap] = useState<{ configured: boolean; usesEnvPasscode: boolean } | null>(null);
  const [adminName, setAdminName] = useState('مدير منصة مشوار');
  const [adminPassword, setAdminPassword] = useState('');
  const [authError, setAuthError] = useState<string | null>(null);
  const [authBusy, setAuthBusy] = useState(false);

  // Console state
  const [tab, setTab] = useState<AdminTab>('overview');
  const [kpis, setKpis] = useState({
    totalCustomers: 0,
    totalDrivers: 0,
    onlineDrivers: 0,
    offlineDrivers: 0,
    activeRidesCount: 0,
    completedRidesCount: 0,
    cancelledRidesCount: 0,
    dailyRevenueIqd: 0,
    monthlyRevenueIqd: 0,
  });
  const [liveDrivers, setLiveDrivers] = useState<
    Array<{
      id: string;
      name: string;
      category: string;
      is_online: number;
      current_lat: number;
      current_lng: number;
      current_speed_kmh: number | null;
    }>
  >([]);
  const [customers, setCustomers] = useState<
    Array<User & { total_rides: number; plus_status: string | null }>
  >([]);
  const [customerSearchQ, setCustomerSearchQ] = useState('');
  const [drivers, setDrivers] = useState<Array<User & DriverProfile>>([]);
  const [driverSearchQ, setDriverSearchQ] = useState('');
  const [rides, setRides] = useState<Ride[]>([]);
  const [rideSearchQ, setRideSearchQ] = useState('');
  const [rideStatusFilter, setRideStatusFilter] = useState('all');

  const [sosAlerts, setSosAlerts] = useState<SosAlert[]>([]);
  const [sosNote, setSosNote] = useState<Record<string, string>>({});
  const [rideShares, setRideShares] = useState<RideShareRecord[]>([]);
  const [ratingsList, setRatingsList] = useState<RatingRow[]>([]);
  const [ratingSearchQ, setRatingSearchQ] = useState('');
  const [reportedUsers, setReportedUsers] = useState<ReportedUserRow[]>([]);
  const [messageReports, setMessageReports] = useState<MessageReport[]>([]);

  // Finance, Gateways & Wallets
  const [financeGateways, setFinanceGateways] = useState<PaymentGatewayConfig[]>([]);
  const [financeReport, setFinanceReport] = useState<FinancialAccountingReport | null>(null);
  const [financeWallets, setFinanceWallets] = useState<DriverWallet[]>([]);
  const [financeWalletTxs, setFinanceWalletTxs] = useState<WalletTransaction[]>([]);
  const [financePaymentTxs, setFinancePaymentTxs] = useState<PaymentTransaction[]>([]);
  const [financeSearchQ, setFinanceSearchQ] = useState('');
  const [savingGateway, setSavingGateway] = useState<string | null>(null);
  const [adjustTarget, setAdjustTarget] = useState<DriverWallet | null>(null);
  const [adjustPool, setAdjustPool] = useState<'real' | 'bonus'>('real');
  const [adjustDelta, setAdjustDelta] = useState('');
  const [adjustReason, setAdjustReason] = useState('');
  const [adjustBusy, setAdjustBusy] = useState(false);
  const [adjustError, setAdjustError] = useState<string | null>(null);

  const [pricing, setPricing] = useState<PricingRules | null>(null);
  const [promos, setPromos] = useState<PromoCode[]>([]);
  const [plusSettings, setPlusSettings] = useState<PlusSettings | null>(null);
  const [plusSubs, setPlusSubs] = useState<PlusSubscription[]>([]);
  const [complaints, setComplaints] = useState<Complaint[]>([]);
  const [complaintSearchQ, setComplaintSearchQ] = useState('');
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>([]);
  const [securityEvents, setSecurityEvents] = useState<SecurityEvent[]>([]);
  const [backups, setBackups] = useState<BackupRecord[]>([]);
  const [appSettings, setAppSettings] = useState<AppSettings | null>(null);

  // Forms & modals
  const [docPreview, setDocPreview] = useState<{ title: string; blobUrl: string } | null>(null);
  const [rejectTargetId, setRejectTargetId] = useState<string | null>(null);
  const [rejectReason, setRejectReason] = useState('');
  const [rejectPhotoId, setRejectPhotoId] = useState<string | null>(null);
  const [rejectPhotoReason, setRejectPhotoReason] = useState('');

  const [newPromoCode, setNewPromoCode] = useState('');
  const [newPromoPct, setNewPromoPct] = useState('15');
  const [newPromoMax, setNewPromoMax] = useState('5000');
  const [broadcastTitle, setBroadcastTitle] = useState('');
  const [broadcastBody, setBroadcastBody] = useState('');
  const [replyText, setReplyText] = useState<Record<string, string>>({});
  const [exportingTarget, setExportingTarget] = useState<'customer' | 'driver' | 'admin' | null>(null);
  const [statusBanner, setStatusBanner] = useState<string | null>(null);

  useEffect(() => {
    if (!token) {
      apiRequest<{ configured: boolean; usesEnvPasscode: boolean }>('/api/admin/bootstrap-status')
        .then(setBootstrap)
        .catch(() => setBootstrap({ configured: true, usesEnvPasscode: false }));
    }
  }, [token]);

  const loadRidesFiltered = useCallback(
    async (qStr: string, statusStr: string) => {
      if (!token || user?.role !== 'admin') return;
      const params = new URLSearchParams();
      if (qStr.trim()) params.set('q', qStr.trim());
      if (statusStr && statusStr !== 'all') params.set('status', statusStr);
      const res = await apiRequest<{ rides: Ride[] }>(`/api/admin/rides?${params.toString()}`, { token }).catch(
        () => null,
      );
      if (res) setRides(res.rides);
    },
    [token, user?.role],
  );

  const loadAdminData = useCallback(async () => {
    if (!token || user?.role !== 'admin') return;
    try {
      const [
        ov,
        cust,
        drv,
        rds,
        prc,
        pls,
        cmp,
        aud,
        sec,
        appSet,
        sosRes,
        shRes,
        rtRes,
        repMsgRes,
        repUsrRes,
        finRes,
      ] = await Promise.all([
        apiRequest<{ kpis: typeof kpis; liveDrivers: typeof liveDrivers }>('/api/admin/overview', { token }),
        apiRequest<{ customers: typeof customers }>(`/api/admin/customers?q=${encodeURIComponent(customerSearchQ)}`, {
          token,
        }),
        apiRequest<{ drivers: typeof drivers }>(`/api/admin/drivers?q=${encodeURIComponent(driverSearchQ)}`, {
          token,
        }),
        apiRequest<{ rides: Ride[] }>(
          `/api/admin/rides?q=${encodeURIComponent(rideSearchQ)}&status=${encodeURIComponent(rideStatusFilter)}`,
          { token },
        ),
        apiRequest<{ pricing: PricingRules; promos: PromoCode[] }>('/api/admin/pricing', { token }),
        apiRequest<{ settings: PlusSettings; subscriptions: PlusSubscription[] }>('/api/admin/plus', { token }),
        apiRequest<{ complaints: Complaint[] }>(`/api/complaints?q=${encodeURIComponent(complaintSearchQ)}`, {
          token,
        }),
        apiRequest<{ logs: AuditLog[] }>('/api/admin/audit-logs', { token }),
        apiRequest<{ events: SecurityEvent[]; backups: BackupRecord[] }>('/api/admin/security', { token }),
        apiRequest<{ settings: AppSettings }>('/api/admin/settings', { token }),
        apiRequest<{ alerts: SosAlert[] }>('/api/admin/sos', { token }),
        apiRequest<{ shares: RideShareRecord[] }>('/api/admin/shares', { token }),
        apiRequest<{ ratings: RatingRow[] }>(`/api/admin/ratings?q=${encodeURIComponent(ratingSearchQ)}`, { token }),
        apiRequest<{ reports: MessageReport[] }>('/api/admin/message-reports', { token }),
        apiRequest<{ reportedUsers: ReportedUserRow[] }>('/api/admin/reported-users', { token }),
        apiRequest<{
          gateways: PaymentGatewayConfig[];
          report: FinancialAccountingReport;
          wallets: DriverWallet[];
          walletTransactions: WalletTransaction[];
          paymentTransactions: PaymentTransaction[];
        }>(`/api/admin/finance?q=${encodeURIComponent(financeSearchQ)}`, { token }),
      ]);
      setKpis(ov.kpis);
      setLiveDrivers(ov.liveDrivers);
      setCustomers(cust.customers);
      setDrivers(drv.drivers);
      setRides(rds.rides);
      setPricing(prc.pricing);
      setPromos(prc.promos);
      setPlusSettings(pls.settings);
      setPlusSubs(pls.subscriptions);
      setComplaints(cmp.complaints);
      setAuditLogs(aud.logs);
      setSecurityEvents(sec.events);
      setBackups(sec.backups);
      setAppSettings(appSet.settings);
      setSosAlerts(sosRes.alerts);
      setRideShares(shRes.shares);
      setRatingsList(rtRes.ratings);
      setMessageReports(repMsgRes.reports);
      setReportedUsers(repUsrRes.reportedUsers);
      setFinanceGateways(finRes.gateways);
      setFinanceReport(finRes.report);
      setFinanceWallets(finRes.wallets);
      setFinanceWalletTxs(finRes.walletTransactions);
      setFinancePaymentTxs(finRes.paymentTransactions);
    } catch {
      // resilient
    }
  }, [
    token,
    user?.role,
    customerSearchQ,
    driverSearchQ,
    rideSearchQ,
    rideStatusFilter,
    ratingSearchQ,
    complaintSearchQ,
    financeSearchQ,
  ]);

  useEffect(() => {
    if (!token || user?.role !== 'admin') return;
    loadAdminData();
    const ws = createSocketConnection(token, (event) => {
      if (
        event === 'ride:updated' ||
        event === 'admin:driver_status' ||
        event === 'admin:driver_location' ||
        event === 'admin:driver_pending' ||
        event === 'admin:driver_photo_pending' ||
        event === 'admin:complaint_new' ||
        event === 'admin:message_reported' ||
        event === 'admin:sos_alert' ||
        event === 'admin:sos_updated' ||
        event === 'admin:security_alert'
      ) {
        loadAdminData();
        if (event === 'admin:sos_alert') {
          setStatusBanner('تنبيه طوارئ SOS جديد! يرجى الانتقال إلى تبويب الطوارئ للمتابعة فوراً.');
        }
      }
    });
    return () => ws.close();
  }, [token, user?.role, loadAdminData]);

  const handleAdminAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError(null);
    setAuthBusy(true);
    try {
      const isClaim = bootstrap && !bootstrap.configured && !bootstrap.usesEnvPasscode;
      const endpoint = isClaim ? '/api/admin/claim' : '/api/auth/admin/login';
      const body = isClaim ? { name: adminName, password: adminPassword } : { password: adminPassword };
      const res = await apiRequest<{ token: string; user: User }>(endpoint, { method: 'POST', body });
      onAuthSuccess(res.token, res.user);
    } catch (err) {
      setAuthError(err instanceof Error ? err.message : 'فشل تسجيل الدخول للإدارة');
    } finally {
      setAuthBusy(false);
    }
  };

  const openProtectedDoc = async (title: string, url: string | null | undefined) => {
    if (!url || !token) return;
    try {
      const blobUrl = await fetchProtectedImageBlobUrl(url, token);
      setDocPreview({ title, blobUrl });
    } catch {
      setStatusBanner('تعذر عرض الصورة أو المستمسك');
    }
  };

  const exportFinancialCSV = () => {
    const header = ['Ride ID', 'Date', 'Category', 'Status', 'Distance KM', 'Base IQD', 'Distance IQD', 'Discount IQD', 'Final IQD'];
    const rows = rides.map((r) => [
      r.id,
      r.created_at,
      r.category,
      r.status,
      r.distance_km,
      r.base_fare_iqd,
      r.distance_fare_iqd,
      r.discount_iqd,
      r.final_fare_iqd,
    ]);
    const csv = [header, ...rows].map((row) => row.join(',')).join('\n');
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `mishwar-financial-report-${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const unresolvedAlerts = securityEvents.filter(
    (e) => e.is_resolved === 0 && (e.severity === 'high' || e.severity === 'critical'),
  ).length;
  const activeSosCount = sosAlerts.filter((a) => a.status === 'active' || a.status === 'acknowledged').length;

  useEffect(() => {
    onUnreadCountChange?.(token && user?.role === 'admin' ? activeSosCount + unresolvedAlerts : 0);
  }, [token, user, activeSosCount, unresolvedAlerts, onUnreadCountChange]);

  // ==================== LOGIN / FIRST-RUN CLAIM ====================
  if (!token || user?.role !== 'admin') {
    const isClaim = bootstrap && !bootstrap.configured && !bootstrap.usesEnvPasscode;
    return (
      <div className="max-w-md mx-auto my-10 bg-white border border-slate-200 rounded-2xl p-6 sm:p-8 shadow-sm">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-11 h-11 rounded-xl bg-slate-900 text-white flex items-center justify-center">
            <ShieldCheck className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-slate-900">
              {isClaim ? 'إعداد حساب مدير النظام' : 'دخول لوحة تحكم الإدارة'}
            </h2>
            <p className="text-xs text-slate-500">
              {isClaim
                ? 'أنشئ كلمة مرور قوية لحماية لوحة إدارة مشوار'
                : 'منطقة محمية — مخصصة لمالك ومدير منصة مشوار فقط'}
            </p>
          </div>
        </div>

        {authError && (
          <div className="mb-4 rounded-xl bg-red-50 border border-red-200 px-4 py-3 text-xs text-red-700">
            {authError}
          </div>
        )}

        <form onSubmit={handleAdminAuth} className="space-y-4">
          {isClaim && (
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">اسم المدير</label>
              <input
                type="text"
                required
                value={adminName}
                onChange={(e) => setAdminName(e.target.value)}
                className="w-full rounded-xl border border-slate-300 px-3 py-2.5 text-sm"
              />
            </div>
          )}
          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">
              {isClaim ? 'كلمة مرور المدير (8 أحرف فأكثر)' : 'كلمة مرور الإدارة'}
            </label>
            <input
              type="password"
              required
              minLength={isClaim ? 8 : 1}
              value={adminPassword}
              onChange={(e) => setAdminPassword(e.target.value)}
              placeholder="••••••••"
              className="w-full rounded-xl border border-slate-300 px-3 py-3 text-sm"
            />
          </div>
          <button
            type="submit"
            disabled={authBusy}
            className="w-full rounded-xl bg-slate-900 py-3.5 text-sm font-bold text-white hover:bg-slate-800 transition-colors min-h-[48px]"
          >
            {authBusy ? 'جاري التحقق...' : isClaim ? 'حفظ والدخول للوحة الإدارة' : 'دخول آمن'}
          </button>
        </form>
      </div>
    );
  }

  const fleetMarkers: FleetMarker[] = liveDrivers.map((d) => ({
    id: d.id,
    lat: d.current_lat,
    lng: d.current_lng,
    name: d.name,
    category: d.category,
    isOnline: d.is_online === 1,
    speedKmh: d.current_speed_kmh,
  }));

  const pendingDriversCount = drivers.filter((d) => d.approval_status === 'pending').length;
  const pendingPhotosCount = drivers.filter((d) => d.photo_status === 'pending').length;
  const openMsgReportsCount = messageReports.filter((r) => r.status === 'open').length;

  return (
    <div className="max-w-[1440px] mx-auto px-4 py-4">
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 items-start">
        {/* Sidebar Navigation */}
        <aside className="lg:col-span-3 bg-white border border-slate-200 rounded-2xl p-4 space-y-1.5">
          <div className="pb-3 border-b border-slate-100 flex items-center justify-between">
            <div>
              <div className="text-sm font-bold text-slate-900">{user.name}</div>
              <div className="text-xs text-slate-500">
                لوحة تحكم الإدارة {user.account_number ? `· ${user.account_number}` : ''}
              </div>
            </div>
            <button
              type="button"
              onClick={onLogout}
              className="p-2 rounded-lg text-slate-500 hover:bg-slate-100 hover:text-slate-900"
              title="تسجيل الخروج"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>

          {[
            { id: 'overview', label: 'الإحصائيات والخريطة الحية', icon: LayoutDashboard },
            {
              id: 'sos',
              label: `الطوارئ SOS${activeSosCount > 0 ? ` (${activeSosCount})` : ''}`,
              icon: Siren,
              urgent: activeSosCount > 0,
            },
            {
              id: 'drivers',
              label: `السائقون والصور${pendingDriversCount + pendingPhotosCount > 0 ? ` (${pendingDriversCount + pendingPhotosCount})` : ''}`,
              icon: Car,
            },
            { id: 'customers_rides', label: 'الزبائن وسجل الرحلات', icon: Users },
            { id: 'finance', label: 'المحافظ وبوابات الدفع', icon: Wallet },
            { id: 'ratings', label: 'التقييمات المتبادلة', icon: Star },
            { id: 'pricing', label: 'التسعير والعمولة والعروض', icon: Tag },
            { id: 'plus', label: 'نظام MISHWAR PLUS', icon: Crown },
            {
              id: 'support_reports',
              label: `الشكاوى والتظلمات${openMsgReportsCount > 0 ? ` (${openMsgReportsCount})` : ''}`,
              icon: HeadphonesIcon,
            },
            { id: 'shares', label: 'روابط مشاركة الرحلات', icon: Link2 },
            {
              id: 'security',
              label: `الأمان والإعدادات${unresolvedAlerts > 0 ? ` (${unresolvedAlerts})` : ''}`,
              icon: ShieldAlert,
            },
          ].map((item) => {
            const Icon = item.icon;
            const active = tab === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => setTab(item.id as AdminTab)}
                className={`w-full flex items-center gap-2.5 px-3.5 py-2.5 rounded-xl text-xs font-semibold transition-colors ${
                  active
                    ? 'bg-slate-900 text-white'
                    : item.urgent
                      ? 'bg-red-50 text-red-700 hover:bg-red-100'
                      : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
                }`}
              >
                <Icon className="w-4 h-4 shrink-0" />
                <span className="truncate">{item.label}</span>
              </button>
            );
          })}
        </aside>

        {/* Main Viewport */}
        <main className="lg:col-span-9 space-y-4">
          {statusBanner && (
            <div className="bg-blue-50 border border-blue-200 rounded-xl px-4 py-2.5 text-xs text-blue-900 flex items-center justify-between">
              <span>{statusBanner}</span>
              <button type="button" onClick={() => setStatusBanner(null)} className="font-bold">
                ×
              </button>
            </div>
          )}

          {/* TAB: OVERVIEW & LIVE FLEET MAP */}
          {tab === 'overview' && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 sm:grid-cols-3 xl:grid-cols-5 gap-3">
                {[
                  { label: 'عدد الزبائن', val: kpis.totalCustomers },
                  { label: 'عدد السائقين', val: kpis.totalDrivers },
                  { label: 'متصلون (مشوار يعمل)', val: kpis.onlineDrivers },
                  { label: 'غير متصلين', val: kpis.offlineDrivers },
                  { label: 'الرحلات الجارية', val: kpis.activeRidesCount },
                  { label: 'الرحلات المكتملة', val: kpis.completedRidesCount },
                  { label: 'الرحلات الملغاة', val: kpis.cancelledRidesCount },
                  { label: 'إيرادات اليوم', val: formatIQD(kpis.dailyRevenueIqd) },
                  { label: 'إيرادات الشهر', val: formatIQD(kpis.monthlyRevenueIqd) },
                  { label: 'بلاغات SOS النشطة', val: activeSosCount },
                ].map((k) => (
                  <div key={k.label} className="bg-white border border-slate-200 rounded-2xl p-4">
                    <div className="text-xs text-slate-500">{k.label}</div>
                    <div className="text-lg font-bold font-mono text-slate-900 mt-1 tabular-nums">{k.val}</div>
                  </div>
                ))}
              </div>

              <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden">
                <div className="px-4 py-3 border-b border-slate-200 flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2 font-bold text-slate-900">
                    <MapPin className="w-4 h-4 text-blue-600" />
                    <span>خريطة متابعة السائقين والرحلات المباشرة</span>
                  </div>
                  <button
                    type="button"
                    onClick={loadAdminData}
                    className="inline-flex items-center gap-1 text-blue-600 font-semibold"
                  >
                    <RefreshCw className="w-3.5 h-3.5" />
                    <span>تحديث</span>
                  </button>
                </div>
                <div className="h-[420px]">
                  <MishwarMap fleetMarkers={fleetMarkers} zoom={11} />
                </div>
              </div>
            </div>
          )}

          {/* TAB: SOS EMERGENCY CENTER */}
          {tab === 'sos' && (
            <div className="bg-white border border-slate-200 rounded-2xl p-5 space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                    <Siren className="w-5 h-5 text-red-600" />
                    <span>سجل وحالات الطوارئ SOS</span>
                  </h3>
                  <p className="text-xs text-slate-500">
                    يظهر هنا موقع المستخدم وبيانات الرحلة فور الضغط على زر الطوارئ في تطبيق الزبون أو السائق
                  </p>
                </div>
                <span className="text-xs font-mono font-semibold text-slate-600">
                  رقم الطوارئ المعتمد: {appSettings?.emergency_phone || '104'}
                </span>
              </div>

              {sosAlerts.length === 0 ? (
                <p className="text-xs text-slate-500 py-8 text-center">لا توجد حالات طوارئ مسجلة.</p>
              ) : (
                <div className="divide-y divide-slate-100 space-y-3">
                  {sosAlerts.map((a) => (
                    <div
                      key={a.id}
                      className={`pt-4 space-y-2 text-xs ${
                        a.status === 'active' ? 'bg-red-50/50 rounded-xl p-3 border border-red-200' : ''
                      }`}
                    >
                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <div className="font-bold text-slate-900">
                          [{a.incident_type}] — {a.user_name}{' '}
                          {a.user_account_number ? (
                            <span className="font-mono text-slate-600">({a.user_account_number})</span>
                          ) : null}{' '}
                          ({a.user_role === 'driver' ? 'سائق' : 'زبون'}) ·{' '}
                          <span className="font-mono" dir="ltr">{a.user_phone}</span>
                        </div>
                        <span
                          className={`font-bold px-2 py-0.5 rounded-md ${
                            a.status === 'active'
                              ? 'bg-red-600 text-white'
                              : a.status === 'acknowledged'
                                ? 'bg-amber-100 text-amber-800'
                                : a.status === 'cancelled_false_alarm'
                                  ? 'bg-slate-200 text-slate-700'
                                  : 'bg-emerald-100 text-emerald-800'
                          }`}
                        >
                          {a.status === 'active'
                            ? 'طوارئ نشطة'
                            : a.status === 'acknowledged'
                              ? 'قيد المتابعة'
                              : a.status === 'cancelled_false_alarm'
                                ? 'ألغاه المستخدم (بالخطأ)'
                                : 'تمت المعالجة'}
                        </span>
                      </div>

                      {a.ride_id && (
                        <div className="text-slate-700">
                          الرحلة: <span className="font-mono">{a.ride_number || a.ride_id.slice(0, 8)}</span> · {a.pickup_address} ←{' '}
                          {a.dropoff_address} (الزبون: {a.customer_name || '—'} · السائق: {a.driver_name || '—'})
                        </div>
                      )}
                      {a.lat != null && a.lng != null && (
                        <div className="font-mono text-slate-600">
                          الإحداثيات: {a.lat.toFixed(5)}, {a.lng.toFixed(5)}
                        </div>
                      )}
                      {a.notes && <div className="text-slate-700">ملاحظة المبلّغ: {a.notes}</div>}
                      <div className="text-slate-400">وقت البلاغ: {formatDateTimeAr(a.created_at)}</div>

                      {(a.status === 'active' || a.status === 'acknowledged') && (
                        <div className="flex flex-wrap items-center gap-2 pt-2">
                          <input
                            type="text"
                            value={sosNote[a.id] ?? a.admin_note ?? ''}
                            onChange={(e) => setSosNote({ ...sosNote, [a.id]: e.target.value })}
                            placeholder="ملاحظة غرفة العمليات..."
                            className="flex-1 min-w-[180px] rounded-xl border border-slate-300 px-3 py-2 text-xs bg-white"
                          />
                          {a.status === 'active' && (
                            <button
                              type="button"
                              onClick={async () => {
                                await apiRequest(`/api/admin/sos/${a.id}`, {
                                  method: 'PATCH',
                                  token,
                                  body: { status: 'acknowledged', admin_note: sosNote[a.id] },
                                });
                                loadAdminData();
                              }}
                              className="rounded-xl bg-amber-600 px-3 py-2 font-bold text-white"
                            >
                              بدء المتابعة
                            </button>
                          )}
                          <button
                            type="button"
                            onClick={async () => {
                              await apiRequest(`/api/admin/sos/${a.id}`, {
                                method: 'PATCH',
                                token,
                                body: { status: 'resolved', admin_note: sosNote[a.id] || 'تمت المعالجة بنجاح' },
                              });
                              loadAdminData();
                            }}
                            className="rounded-xl bg-emerald-600 px-3 py-2 font-bold text-white"
                          >
                            إغلاق وحل الحالة
                          </button>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* TAB: DRIVERS, VEHICLES & DRIVER PHOTO REVIEW */}
          {tab === 'drivers' && (
            <div className="space-y-4">
              <div className="bg-white border border-slate-200 rounded-2xl p-5">
                <h3 className="text-sm font-bold text-slate-900 mb-3">إرسال إشعار إداري لجميع السائقين</h3>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                  <input
                    type="text"
                    value={broadcastTitle}
                    onChange={(e) => setBroadcastTitle(e.target.value)}
                    placeholder="عنوان الإشعار"
                    className="rounded-xl border border-slate-300 px-3 py-2 text-xs"
                  />
                  <input
                    type="text"
                    value={broadcastBody}
                    onChange={(e) => setBroadcastBody(e.target.value)}
                    placeholder="نص الرسالة للسائقين"
                    className="rounded-xl border border-slate-300 px-3 py-2 text-xs"
                  />
                  <button
                    type="button"
                    onClick={async () => {
                      const res = await apiRequest<{ sentCount: number }>('/api/admin/notify-drivers', {
                        method: 'POST',
                        token,
                        body: { title: broadcastTitle, body: broadcastBody },
                      });
                      setBroadcastTitle('');
                      setBroadcastBody('');
                      setStatusBanner(`تم إرسال الإشعار إلى ${res.sentCount} سائق`);
                    }}
                    className="inline-flex items-center justify-center gap-1.5 rounded-xl bg-blue-600 px-4 py-2 text-xs font-bold text-white hover:bg-blue-700"
                  >
                    <Send className="w-3.5 h-3.5" />
                    <span>إرسال الآن</span>
                  </button>
                </div>
              </div>

              <div className="bg-white border border-slate-200 rounded-2xl p-5">
                <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
                  <h3 className="text-base font-bold text-slate-900">إدارة السائقين ومراجعة الصور والمستمسكات</h3>
                  <div className="flex items-center border border-slate-300 rounded-xl px-3 py-1.5 bg-white">
                    <Search className="w-3.5 h-3.5 text-slate-400 ml-2" />
                    <input
                      type="text"
                      value={driverSearchQ}
                      onChange={(e) => setDriverSearchQ(e.target.value)}
                      placeholder="بحث برقم الحساب MSH-D، الاسم، الهاتف، اللوحة..."
                      className="text-xs focus:outline-none w-64"
                    />
                  </div>
                </div>
                {drivers.length === 0 ? (
                  <p className="text-xs text-slate-500 py-6 text-center">لا يوجد سائقون مسجلون حالياً.</p>
                ) : (
                  <div className="divide-y divide-slate-100">
                    {drivers.map((d) => {
                      const photoToReview = d.pending_avatar_url || d.avatar_url;
                      return (
                        <div key={d.user_id} className="py-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
                          <div className="flex items-start gap-3">
                            <ProtectedImage
                              src={photoToReview}
                              token={token}
                              alt={d.name}
                              className="w-16 h-16 rounded-2xl object-cover border border-slate-200 shrink-0"
                              fallback={
                                <div className="w-16 h-16 rounded-2xl bg-slate-100 flex items-center justify-center font-bold text-slate-500 shrink-0">
                                  {d.name.slice(0, 1)}
                                </div>
                              }
                            />
                            <div className="space-y-1">
                              <div className="flex flex-wrap items-center gap-2 text-xs">
                                <span className="font-bold text-sm text-slate-900">{d.name}</span>
                                {d.account_number && (
                                  <span className="font-mono font-bold text-blue-700 bg-blue-50 border border-blue-200 px-1.5 py-0.5 rounded">
                                    {d.account_number}
                                  </span>
                                )}
                                <span>·</span>
                                <span className="font-mono" dir="ltr">{d.phone}</span>
                                <span>·</span>
                                <span
                                  className={`font-semibold ${
                                    d.approval_status === 'approved'
                                      ? 'text-emerald-700'
                                      : d.approval_status === 'rejected'
                                        ? 'text-red-700'
                                        : 'text-amber-700'
                                  }`}
                                >
                                  الحساب:{' '}
                                  {d.approval_status === 'approved'
                                    ? 'معتمد'
                                    : d.approval_status === 'rejected'
                                      ? 'مرفوض'
                                      : 'بانتظار الموافقة'}
                                </span>
                                <span>·</span>
                                <span
                                  className={`font-semibold ${
                                    d.photo_status === 'approved'
                                      ? 'text-emerald-700'
                                      : d.photo_status === 'rejected'
                                        ? 'text-red-700'
                                        : 'text-amber-700'
                                  }`}
                                >
                                  الصورة:{' '}
                                  {d.photo_status === 'approved'
                                    ? 'معتمدة'
                                    : d.photo_status === 'rejected'
                                      ? 'مرفوضة'
                                      : 'بانتظار اعتماد الصورة'}
                                </span>
                              </div>
                              <div className="text-xs text-slate-600">
                                السيارة: {d.car_make} {d.car_model} ({d.car_year}) — {d.car_color} · اللوحة:{' '}
                                {d.plate_number} · الفئة: {CATEGORY_LABELS[d.category].ar} · التقييم: {d.rating_avg}★
                              </div>
                              <div className="flex flex-wrap gap-3 pt-1">
                                <button
                                  type="button"
                                  onClick={() => openProtectedDoc(`الصورة الشخصية — ${d.name}`, photoToReview)}
                                  className="text-xs text-blue-600 hover:underline font-semibold"
                                >
                                  تكبير الصورة الشخصية
                                </button>
                                <button
                                  type="button"
                                  onClick={() => openProtectedDoc('إجازة السوق', d.license_doc_url)}
                                  className="text-xs text-blue-600 hover:underline font-semibold"
                                >
                                  عرض إجازة السوق
                                </button>
                                <button
                                  type="button"
                                  onClick={() => openProtectedDoc('السنوية', d.registration_doc_url)}
                                  className="text-xs text-blue-600 hover:underline font-semibold"
                                >
                                  عرض السنوية
                                </button>
                                <button
                                  type="button"
                                  onClick={() => openProtectedDoc('البطاقة الوطنية', d.national_id_doc_url)}
                                  className="text-xs text-blue-600 hover:underline font-semibold"
                                >
                                  عرض البطاقة الوطنية
                                </button>
                              </div>
                            </div>
                          </div>

                          <div className="flex flex-wrap items-center gap-2 shrink-0">
                            {d.photo_status !== 'approved' && (
                              <button
                                type="button"
                                onClick={async () => {
                                  await apiRequest(`/api/admin/drivers/${d.user_id}/photo/approve`, {
                                    method: 'POST',
                                    token,
                                  });
                                  loadAdminData();
                                }}
                                className="rounded-xl bg-blue-600 px-3 py-2 text-xs font-bold text-white hover:bg-blue-700"
                              >
                                اعتماد الصورة
                              </button>
                            )}
                            {d.photo_status !== 'rejected' && (
                              <button
                                type="button"
                                onClick={() => setRejectPhotoId(d.user_id)}
                                className="rounded-xl border border-amber-200 bg-amber-50 px-3 py-2 text-xs font-bold text-amber-800"
                              >
                                رفض الصورة
                              </button>
                            )}

                            {d.approval_status !== 'approved' && (
                              <button
                                type="button"
                                onClick={async () => {
                                  await apiRequest(`/api/admin/drivers/${d.user_id}/approve`, {
                                    method: 'POST',
                                    token,
                                    body: { approvePhoto: true },
                                  });
                                  loadAdminData();
                                }}
                                className="inline-flex items-center gap-1 rounded-xl bg-emerald-600 px-3 py-2 text-xs font-bold text-white hover:bg-emerald-700"
                              >
                                <CheckCircle className="w-3.5 h-3.5" />
                                <span>موافقة الحساب والصورة</span>
                              </button>
                            )}
                            {d.approval_status !== 'rejected' && (
                              <button
                                type="button"
                                onClick={() => setRejectTargetId(d.user_id)}
                                className="inline-flex items-center gap-1 rounded-xl border border-red-200 bg-red-50 px-3 py-2 text-xs font-bold text-red-700"
                              >
                                <XCircle className="w-3.5 h-3.5" />
                                <span>رفض</span>
                              </button>
                            )}
                            <button
                              type="button"
                              onClick={async () => {
                                await apiRequest(`/api/admin/users/${d.user_id}/status`, {
                                  method: 'PATCH',
                                  token,
                                  body: { status: d.status === 'active' ? 'suspended' : 'active' },
                                });
                                loadAdminData();
                              }}
                              className="rounded-xl border border-slate-200 px-3 py-2 text-xs font-semibold text-slate-700"
                            >
                              {d.status === 'active' ? 'إيقاف الحساب' : 'تفعيل الحساب'}
                            </button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* TAB: CUSTOMERS & SEARCHABLE RIDES HISTORY */}
          {tab === 'customers_rides' && (
            <div className="space-y-4">
              <div className="bg-white border border-slate-200 rounded-2xl p-5">
                <div className="flex flex-wrap items-center justify-between gap-3 mb-3">
                  <h3 className="text-base font-bold text-slate-900">إدارة الزبائن</h3>
                  <div className="flex items-center border border-slate-300 rounded-xl px-3 py-1.5 bg-white">
                    <Search className="w-3.5 h-3.5 text-slate-400 ml-2" />
                    <input
                      type="text"
                      value={customerSearchQ}
                      onChange={(e) => setCustomerSearchQ(e.target.value)}
                      placeholder="بحث برقم الحساب MSH-C، الاسم، الهاتف..."
                      className="text-xs focus:outline-none w-56"
                    />
                  </div>
                </div>
                {customers.length === 0 ? (
                  <p className="text-xs text-slate-500">لا يوجد زبائن مسجلون.</p>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="w-full text-xs text-right">
                      <thead className="border-b border-slate-200 text-slate-500">
                        <tr>
                          <th className="py-2">رقم الحساب</th>
                          <th className="py-2">الاسم</th>
                          <th className="py-2">الهاتف</th>
                          <th className="py-2">الرحلات</th>
                          <th className="py-2">التقييم</th>
                          <th className="py-2">PLUS</th>
                          <th className="py-2">الحالة</th>
                          <th className="py-2">إجراء</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                        {customers.map((c) => (
                          <tr key={c.id}>
                            <td className="py-2.5 font-mono font-bold text-blue-700">{c.account_number || '—'}</td>
                            <td className="py-2.5 font-semibold text-slate-900">{c.name}</td>
                            <td className="py-2.5 font-mono" dir="ltr">{c.phone}</td>
                            <td className="py-2.5 font-mono">{c.total_rides}</td>
                            <td className="py-2.5 font-mono text-amber-600">{(c.rating_avg ?? 5).toFixed(1)} ★</td>
                            <td className="py-2.5">{c.plus_status === 'active' ? 'مشترك' : '—'}</td>
                            <td className="py-2.5">{c.status === 'active' ? 'نشط' : 'موقوف'}</td>
                            <td className="py-2.5">
                              <button
                                type="button"
                                onClick={async () => {
                                  await apiRequest(`/api/admin/users/${c.id}/status`, {
                                    method: 'PATCH',
                                    token,
                                    body: { status: c.status === 'active' ? 'suspended' : 'active' },
                                  });
                                  loadAdminData();
                                }}
                                className="text-blue-600 font-semibold hover:underline"
                              >
                                {c.status === 'active' ? 'إيقاف' : 'تفعيل'}
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>

              <div className="bg-white border border-slate-200 rounded-2xl p-5 space-y-4">
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <h3 className="text-base font-bold text-slate-900">سجل الرحلات والبحث الكامل</h3>
                  <div className="flex flex-wrap items-center gap-2">
                    <div className="flex items-center border border-slate-300 rounded-xl px-3 py-1.5 bg-white">
                      <Search className="w-3.5 h-3.5 text-slate-400 ml-2" />
                      <input
                        type="text"
                        value={rideSearchQ}
                        onChange={(e) => setRideSearchQ(e.target.value)}
                        placeholder="بحث برقم الرحلة MSH-TR أو الحساب MSH-C/D..."
                        className="text-xs focus:outline-none w-60"
                      />
                    </div>
                    <select
                      value={rideStatusFilter}
                      onChange={(e) => setRideStatusFilter(e.target.value)}
                      className="rounded-xl border border-slate-300 px-3 py-2 text-xs bg-white"
                    >
                      <option value="all">جميع الحالات</option>
                      <option value="completed">مكتملة</option>
                      <option value="cancelled">ملغاة</option>
                      <option value="in_progress">بدأت الرحلة</option>
                      <option value="on_the_way">السائق في الطريق</option>
                      <option value="searching">جاري البحث</option>
                    </select>
                    <button
                      type="button"
                      onClick={() => loadRidesFiltered(rideSearchQ, rideStatusFilter)}
                      className="rounded-xl bg-slate-900 px-3.5 py-2 text-xs font-bold text-white"
                    >
                      بحث
                    </button>
                  </div>
                </div>

                {rides.length === 0 ? (
                  <p className="text-xs text-slate-500 py-6 text-center">لا توجد رحلات مطابقة.</p>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="w-full text-xs text-right">
                      <thead className="border-b border-slate-200 text-slate-500">
                        <tr>
                          <th className="py-2">رقم الرحلة</th>
                          <th className="py-2">الزبون</th>
                          <th className="py-2">السائق</th>
                          <th className="py-2">الدفع والعمولة</th>
                          <th className="py-2">المسار والتفاصيل</th>
                          <th className="py-2">الحالة</th>
                          <th className="py-2">الأجرة</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                        {rides.map((r) => (
                          <tr key={r.id}>
                            <td className="py-2.5 font-mono font-bold text-blue-700">{r.ride_number || r.id.slice(0, 8)}</td>
                            <td className="py-2.5">
                              <div className="font-semibold">{r.customer_name}</div>
                              {r.customer_account_number && (
                                <div className="font-mono text-[10px] text-slate-500">{r.customer_account_number}</div>
                              )}
                            </td>
                            <td className="py-2.5">
                              <div>{r.driver_name || '—'}</div>
                              {r.driver_account_number && (
                                <div className="font-mono text-[10px] text-slate-500">{r.driver_account_number}</div>
                              )}
                            </td>
                            <td className="py-2.5">
                              <div>
                                {r.payment_method !== 'electronic_pending'
                                  ? PAYMENT_METHOD_LABELS[r.payment_method]
                                  : 'إلكتروني'}
                              </div>
                              {(r.commission_iqd ?? 0) > 0 && (
                                <div className="font-mono text-[10px] text-amber-700">
                                  عمولة: {formatIQD(r.commission_iqd ?? 0)}
                                </div>
                              )}
                            </td>
                            <td className="py-2.5">
                              <div className="font-semibold text-slate-900">
                                {r.pickup_address} ← {r.dropoff_address}
                              </div>
                              <div className="text-[11px] text-slate-500">
                                {CATEGORY_LABELS[r.category].ar} · {r.distance_km} كم · {r.duration_min} د ·{' '}
                                {formatDateTimeAr(r.created_at)}
                                {r.cancel_reason ? ` · سبب الإلغاء: ${r.cancel_reason}` : ''}
                              </div>
                            </td>
                            <td className="py-2.5">{RIDE_STATUS_LABELS[r.status]}</td>
                            <td className="py-2.5 font-mono font-bold">{formatIQD(r.final_fare_iqd)}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* TAB: FINANCE, DRIVER WALLETS & OFFICIAL PAYMENT GATEWAYS */}
          {tab === 'finance' && (
            <div className="space-y-4">
              {financeReport && (
                <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
                  {[
                    {
                      label: 'رصيد السماح الافتتاحي الممنوح (غير نقدي)',
                      val: formatIQD(financeReport.virtual_opening_bonuses_granted_iqd),
                      sub: `المتبقي منه: ${formatIQD(financeReport.virtual_opening_bonus_remaining_iqd)}`,
                    },
                    {
                      label: 'شحن المحافظ الحقيقي المؤكد',
                      val: formatIQD(financeReport.real_topups_confirmed_iqd),
                      sub: `إجمالي الأرصدة الحقيقية: ${formatIQD(financeReport.real_wallet_balances_total_iqd)}`,
                    },
                    {
                      label: 'العمولات المغطاة من السماح الافتراضي',
                      val: formatIQD(financeReport.commissions_covered_by_virtual_bonus_iqd),
                      sub: 'لا تمثل تحصيل نقدي من السائقين',
                    },
                    {
                      label: 'العمولات المحصّلة من الرصيد الحقيقي',
                      val: formatIQD(financeReport.commissions_collected_real_cash_iqd),
                      sub: `غير محصّل: ${formatIQD(financeReport.uncollected_commissions_iqd)}`,
                    },
                    {
                      label: 'حجم الدفع الإلكتروني المؤكد',
                      val: formatIQD(financeReport.electronic_gross_volume_iqd),
                      sub: `صافي مستحقات السائقين: ${formatIQD(financeReport.electronic_driver_net_payable_iqd)}`,
                    },
                    {
                      label: 'حجم الرحلات النقدية المكتملة',
                      val: formatIQD(financeReport.cash_rides_gross_volume_iqd),
                      sub: `إجمالي العمولات المسجلة: ${formatIQD(financeReport.total_commissions_charged_iqd)}`,
                    },
                  ].map((card) => (
                    <div key={card.label} className="bg-white border border-slate-200 rounded-2xl p-4">
                      <div className="text-[11px] text-slate-500">{card.label}</div>
                      <div className="text-base font-bold font-mono text-slate-900 mt-1 tabular-nums">{card.val}</div>
                      <div className="text-[11px] text-slate-500 mt-1">{card.sub}</div>
                    </div>
                  ))}
                </div>
              )}

              {/* Payment Gateways Configuration */}
              <div className="bg-white border border-slate-200 rounded-2xl p-5 space-y-4">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div>
                    <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                      <CreditCard className="w-4 h-4 text-blue-600" />
                      <span>إعداد وتفعيل طرق وبوابات الدفع الرسمية</span>
                    </h3>
                    <p className="text-xs text-slate-500 mt-0.5">
                      تبقى البوابات الإلكترونية مقفلة حتى اعتماد حساب التاجر الرسمي وضبط مفاتيح الربط في الخادم.
                    </p>
                  </div>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
                  {financeGateways.map((gw) => (
                    <div key={gw.provider} className="rounded-xl border border-slate-200 p-4 space-y-3 text-xs">
                      <div className="flex items-center justify-between gap-2">
                        <div className="font-bold text-sm text-slate-900">{gw.display_name_ar}</div>
                        <span
                          className={`font-semibold ${gw.available ? 'text-emerald-700' : 'text-amber-700'}`}
                        >
                          {gw.available ? 'متاح للمستخدمين' : 'مقفل / بانتظار الاعتماد'}
                        </span>
                      </div>

                      {gw.provider !== 'cash' && (
                        <div className="text-[11px] text-slate-600">
                          مفاتيح الخادم (.env):{' '}
                          <span className={gw.credentials_configured ? 'text-emerald-700 font-bold' : 'text-red-600 font-bold'}>
                            {gw.credentials_configured ? 'مهيأة' : 'غير مضبوطة'}
                          </span>
                        </div>
                      )}

                      <label className="flex items-center gap-2">
                        <input
                          type="checkbox"
                          checked={gw.is_enabled === 1}
                          onChange={(e) =>
                            setFinanceGateways((prev) =>
                              prev.map((x) =>
                                x.provider === gw.provider ? { ...x, is_enabled: e.target.checked ? 1 : 0 } : x,
                              ),
                            )
                          }
                        />
                        <span>تفعيل طريقة الدفع</span>
                      </label>

                      {gw.provider !== 'cash' && (
                        <>
                          <label className="flex items-center gap-2">
                            <input
                              type="checkbox"
                              checked={gw.merchant_approved === 1}
                              onChange={(e) =>
                                setFinanceGateways((prev) =>
                                  prev.map((x) =>
                                    x.provider === gw.provider
                                      ? { ...x, merchant_approved: e.target.checked ? 1 : 0 }
                                      : x,
                                  ),
                                )
                              }
                            />
                            <span>تمت موافقة حساب التاجر الرسمي</span>
                          </label>

                          <div>
                            <label className="block text-slate-600 mb-1">بيئة التشغيل</label>
                            <select
                              value={gw.environment}
                              onChange={(e) =>
                                setFinanceGateways((prev) =>
                                  prev.map((x) =>
                                    x.provider === gw.provider
                                      ? { ...x, environment: e.target.value as PaymentGatewayConfig['environment'] }
                                      : x,
                                  ),
                                )
                              }
                              className="w-full rounded-lg border border-slate-300 px-2.5 py-1.5 bg-white"
                            >
                              <option value="pending_approval">بانتظار الموافقة</option>
                              <option value="sandbox">اختبار رسمي (Sandbox)</option>
                              <option value="production">تشغيل فعلي (Production)</option>
                            </select>
                          </div>

                          <div>
                            <label className="block text-slate-600 mb-1">معرف التاجر (Merchant ID)</label>
                            <input
                              type="text"
                              value={gw.merchant_id || ''}
                              onChange={(e) =>
                                setFinanceGateways((prev) =>
                                  prev.map((x) =>
                                    x.provider === gw.provider ? { ...x, merchant_id: e.target.value } : x,
                                  ),
                                )
                              }
                              className="w-full rounded-lg border border-slate-300 px-2.5 py-1.5 font-mono"
                            />
                          </div>

                          <div>
                            <label className="block text-slate-600 mb-1">رابط البوابة الرسمي (HTTPS)</label>
                            <input
                              type="url"
                              dir="ltr"
                              value={gw.api_base_url || ''}
                              onChange={(e) =>
                                setFinanceGateways((prev) =>
                                  prev.map((x) =>
                                    x.provider === gw.provider ? { ...x, api_base_url: e.target.value } : x,
                                  ),
                                )
                              }
                              className="w-full rounded-lg border border-slate-300 px-2.5 py-1.5 font-mono text-left"
                            />
                          </div>

                          <div>
                            <label className="block text-slate-600 mb-1">الحد الأدنى للشحن (د.ع)</label>
                            <input
                              type="number"
                              min={1000}
                              value={gw.min_topup_iqd}
                              onChange={(e) =>
                                setFinanceGateways((prev) =>
                                  prev.map((x) =>
                                    x.provider === gw.provider ? { ...x, min_topup_iqd: Number(e.target.value) } : x,
                                  ),
                                )
                              }
                              className="w-full rounded-lg border border-slate-300 px-2.5 py-1.5 font-mono"
                            />
                          </div>
                        </>
                      )}

                      <button
                        type="button"
                        disabled={savingGateway === gw.provider}
                        onClick={async () => {
                          setSavingGateway(gw.provider);
                          try {
                            const res = await apiRequest<{ gateways: PaymentGatewayConfig[] }>(
                              `/api/admin/payments/gateways/${gw.provider}`,
                              {
                                method: 'PUT',
                                token,
                                body: gw,
                              },
                            );
                            setFinanceGateways(res.gateways);
                            setStatusBanner(`تم تحديث إعدادات بوابة ${gw.display_name_ar}`);
                          } catch (err) {
                            setStatusBanner(err instanceof Error ? err.message : 'تعذر حفظ إعدادات البوابة');
                          } finally {
                            setSavingGateway(null);
                          }
                        }}
                        className="w-full rounded-xl bg-slate-900 py-2 font-bold text-white hover:bg-slate-800 disabled:opacity-60"
                      >
                        {savingGateway === gw.provider ? 'جاري الحفظ...' : 'حفظ إعدادات البوابة'}
                      </button>
                    </div>
                  ))}
                </div>
              </div>

              {/* Driver Wallets & Search */}
              <div className="bg-white border border-slate-200 rounded-2xl p-5 space-y-4">
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <h3 className="text-base font-bold text-slate-900">محافظ السائقين</h3>
                  <div className="flex items-center border border-slate-300 rounded-xl px-3 py-1.5 bg-white">
                    <Search className="w-3.5 h-3.5 text-slate-400 ml-2" />
                    <input
                      type="text"
                      value={financeSearchQ}
                      onChange={(e) => setFinanceSearchQ(e.target.value)}
                      placeholder="بحث بـ MSH-D، MSH-TR، رقم الفاتورة، الاسم..."
                      className="text-xs focus:outline-none w-64"
                    />
                  </div>
                </div>

                {financeWallets.length === 0 ? (
                  <p className="text-xs text-slate-500 py-4 text-center">لا توجد محافظ مطابقة.</p>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="w-full text-xs text-right">
                      <thead className="border-b border-slate-200 text-slate-500">
                        <tr>
                          <th className="py-2">حساب السائق</th>
                          <th className="py-2">الاسم</th>
                          <th className="py-2">رصيد السماح</th>
                          <th className="py-2">الرصيد الحقيقي</th>
                          <th className="py-2">العمولات المخصومة</th>
                          <th className="py-2">الحالة</th>
                          <th className="py-2">إجراء</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                        {financeWallets.map((w) => (
                          <tr key={w.driver_id}>
                            <td className="py-2.5 font-mono font-bold text-blue-700">{w.driver_account_number || '—'}</td>
                            <td className="py-2.5 font-semibold">{w.driver_name}</td>
                            <td className="py-2.5 font-mono text-indigo-700">{formatIQD(w.bonus_balance_iqd)}</td>
                            <td className="py-2.5 font-mono text-emerald-700">{formatIQD(w.real_balance_iqd)}</td>
                            <td className="py-2.5 font-mono text-amber-700">{formatIQD(w.total_commission_iqd)}</td>
                            <td className="py-2.5">
                              {w.auto_paused_zero_balance === 1
                                ? 'متوقف لنفاد الرصيد'
                                : w.is_online === 1
                                  ? 'متصل'
                                  : 'غير متصل'}
                            </td>
                            <td className="py-2.5">
                              <button
                                type="button"
                                onClick={() => {
                                  setAdjustTarget(w);
                                  setAdjustPool('real');
                                  setAdjustDelta('');
                                  setAdjustReason('');
                                  setAdjustError(null);
                                }}
                                className="rounded-lg border border-slate-300 px-2.5 py-1 font-bold text-slate-800 hover:bg-slate-50"
                              >
                                تعديل رصيد
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>

              {/* Wallet Transactions & Payment Gateways Ledger */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                <div className="bg-white border border-slate-200 rounded-2xl p-5">
                  <h3 className="text-sm font-bold text-slate-900 mb-3">سجل حركات المحافظ والعمولات</h3>
                  <div className="max-h-80 overflow-y-auto divide-y divide-slate-100 text-xs">
                    {financeWalletTxs.map((tx) => (
                      <div key={tx.id} className="py-2.5 flex items-center justify-between gap-2">
                        <div>
                          <div className="font-bold text-slate-900">
                            {tx.driver_name} ({tx.driver_account_number})
                            {tx.ride_number ? ` · ${tx.ride_number}` : ''}
                          </div>
                          <div className="text-slate-600">{tx.note}</div>
                          <div className="text-[11px] text-slate-400">{formatDateTimeAr(tx.created_at)}</div>
                        </div>
                        <div className="font-mono font-bold text-left shrink-0">
                          {tx.bonus_delta_iqd !== 0 && (
                            <div className={tx.bonus_delta_iqd > 0 ? 'text-indigo-700' : 'text-red-700'}>
                              سماح: {tx.bonus_delta_iqd > 0 ? `+${formatIQD(tx.bonus_delta_iqd)}` : formatIQD(tx.bonus_delta_iqd)}
                            </div>
                          )}
                          {tx.real_delta_iqd !== 0 && (
                            <div className={tx.real_delta_iqd > 0 ? 'text-emerald-700' : 'text-red-700'}>
                              حقيقي: {tx.real_delta_iqd > 0 ? `+${formatIQD(tx.real_delta_iqd)}` : formatIQD(tx.real_delta_iqd)}
                            </div>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="bg-white border border-slate-200 rounded-2xl p-5">
                  <h3 className="text-sm font-bold text-slate-900 mb-3">سجل معاملات بوابات الدفع الإلكتروني</h3>
                  <div className="max-h-80 overflow-y-auto divide-y divide-slate-100 text-xs">
                    {financePaymentTxs.map((pt) => (
                      <div key={pt.id} className="py-2.5 flex items-center justify-between gap-2">
                        <div>
                          <div className="font-bold text-slate-900">
                            <span className="font-mono">{pt.reference_id}</span> · {PAYMENT_METHOD_LABELS[pt.provider]}
                            {pt.ride_number ? ` · ${pt.ride_number}` : ''}
                          </div>
                          <div className="text-slate-600">
                            {pt.user_name} ({pt.user_account_number}) · الحالة: {pt.status}
                          </div>
                          <div className="text-[11px] text-slate-400">{formatDateTimeAr(pt.created_at)}</div>
                        </div>
                        <div className="font-mono font-bold text-left shrink-0">
                          <div>{formatIQD(pt.amount_iqd)}</div>
                          {pt.commission_iqd > 0 && (
                            <div className="text-[11px] text-amber-700">عمولة: {formatIQD(pt.commission_iqd)}</div>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB: MUTUAL RATINGS MODERATION */}
          {tab === 'ratings' && (
            <div className="bg-white border border-slate-200 rounded-2xl p-5 space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                  <Star className="w-4 h-4 text-amber-500" />
                  <span>مراجعة التقييمات المتبادلة بين الزبائن والسائقين</span>
                </h3>
                <div className="flex items-center border border-slate-300 rounded-xl px-3 py-1.5 bg-white">
                  <Search className="w-3.5 h-3.5 text-slate-400 ml-2" />
                  <input
                    type="text"
                    value={ratingSearchQ}
                    onChange={(e) => setRatingSearchQ(e.target.value)}
                    placeholder="بحث بـ MSH-TR، MSH-C، MSH-D، الاسم..."
                    className="text-xs focus:outline-none w-56"
                  />
                </div>
              </div>
              {ratingsList.length === 0 ? (
                <p className="text-xs text-slate-500 py-6 text-center">لا توجد تقييمات مسجلة بعد.</p>
              ) : (
                <div className="divide-y divide-slate-100">
                  {ratingsList.map((rt) => (
                    <div key={rt.id} className="py-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
                      <div className="space-y-1">
                        <div className="font-bold text-slate-900">
                          رحلة <span className="font-mono">{rt.ride_number || rt.id.slice(0, 8)}</span> — {rt.pickup_address} ←{' '}
                          {rt.dropoff_address}
                        </div>
                        <div className="text-slate-700">
                          تقييم الزبون ({rt.customer_name} {rt.customer_account_number ? `[${rt.customer_account_number}]` : ''}) للسائق (
                          {rt.driver_name || '—'} {rt.driver_account_number ? `[${rt.driver_account_number}]` : ''}):{' '}
                          <span className="font-bold text-amber-600">
                            {rt.driver_rating != null ? `${rt.driver_rating}/5` : 'لم يُقيّم'}
                          </span>
                          {rt.driver_review ? ` — "${rt.driver_review}"` : ''}
                        </div>
                        <div className="text-slate-700">
                          تقييم السائق للزبون:{' '}
                          <span className="font-bold text-blue-700">
                            {rt.customer_rating != null ? `${rt.customer_rating}/5` : 'لم يُقيّم'}
                          </span>
                          {rt.customer_review ? ` — "${rt.customer_review}"` : ''}
                        </div>
                      </div>
                      <button
                        type="button"
                        onClick={async () => {
                          await apiRequest(`/api/admin/ratings/${rt.id}/moderate`, {
                            method: 'PATCH',
                            token,
                            body: { moderated: rt.rating_moderated !== 1 },
                          });
                          loadAdminData();
                        }}
                        className={`rounded-xl px-3 py-2 font-bold shrink-0 ${
                          rt.rating_moderated === 1
                            ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                            : 'bg-red-50 text-red-700 border border-red-200'
                        }`}
                      >
                        {rt.rating_moderated === 1 ? 'مخفي (إعادة إظهار)' : 'إخفاء التقييم المسيء'}
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* TAB: PRICING & PROMOS */}
          {tab === 'pricing' && pricing && (
            <div className="space-y-4">
              <div className="bg-white border border-slate-200 rounded-2xl p-5 space-y-4">
                <h3 className="text-base font-bold text-slate-900">إدارة الأسعار والتعرفة (بالدينار العراقي)</h3>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                  {[
                    { key: 'base_fare_iqd', label: 'سعر بداية الرحلة (د.ع)' },
                    { key: 'per_km_iqd', label: 'سعر الكيلومتر (د.ع)' },
                    { key: 'min_fare_iqd', label: 'الحد الأدنى للأجرة (د.ع)' },
                    { key: 'waiting_fee_per_min_iqd', label: 'رسوم الانتظار / دقيقة (د.ع)' },
                    { key: 'cancellation_fee_iqd', label: 'رسوم الإلغاء (د.ع)' },
                    { key: 'economy_multiplier', label: 'معامل Economy' },
                    { key: 'super_multiplier', label: 'معامل Super' },
                    { key: 'plus_multiplier', label: 'معامل Plus' },
                    { key: 'family_multiplier', label: 'معامل Family' },
                    { key: 'commission_percent', label: 'نسبة عمولة مشوار (%)' },
                  ].map((field) => (
                    <div key={field.key}>
                      <label className="block font-medium text-slate-600 mb-1">{field.label}</label>
                      <input
                        type="number"
                        step={field.key === 'commission_percent' ? '0.5' : '0.05'}
                        min={field.key === 'commission_percent' ? 0 : undefined}
                        max={field.key === 'commission_percent' ? 50 : undefined}
                        value={pricing[field.key as keyof PricingRules] as number}
                        onChange={(e) => setPricing({ ...pricing, [field.key]: Number(e.target.value) })}
                        className="w-full rounded-xl border border-slate-300 px-3 py-2 font-mono text-sm"
                      />
                    </div>
                  ))}
                </div>
                <p className="text-[11px] text-slate-500">
                  ملاحظة البند السابع: عند تعديل نسبة العمولة، يتم إشعار السائقين تلقائياً ويتوقف استقبال الطلبات الجديدة للسائق حتى موافقته الصريحة.
                </p>
                <button
                  type="button"
                  onClick={async () => {
                    const res = await apiRequest<{ pricing: PricingRules }>('/api/admin/pricing', {
                      method: 'PUT',
                      token,
                      body: pricing,
                    });
                    setPricing(res.pricing);
                    setStatusBanner('تم حفظ قواعد التسعير ونسبة العمولة الجديدة');
                    loadAdminData();
                  }}
                  className="rounded-xl bg-blue-600 px-5 py-2.5 text-xs font-bold text-white hover:bg-blue-700"
                >
                  حفظ الأسعار والعمولة
                </button>
              </div>

              <div className="bg-white border border-slate-200 rounded-2xl p-5 space-y-4">
                <h3 className="text-base font-bold text-slate-900">أكواد الخصم والعروض</h3>
                <div className="grid grid-cols-1 sm:grid-cols-4 gap-2">
                  <input
                    type="text"
                    value={newPromoCode}
                    onChange={(e) => setNewPromoCode(e.target.value)}
                    placeholder="الكود (مثال: IRAQ20)"
                    className="rounded-xl border border-slate-300 px-3 py-2 text-xs uppercase"
                  />
                  <input
                    type="number"
                    value={newPromoPct}
                    onChange={(e) => setNewPromoPct(e.target.value)}
                    placeholder="نسبة الخصم %"
                    className="rounded-xl border border-slate-300 px-3 py-2 text-xs font-mono"
                  />
                  <input
                    type="number"
                    value={newPromoMax}
                    onChange={(e) => setNewPromoMax(e.target.value)}
                    placeholder="الحد الأقصى للخصم د.ع"
                    className="rounded-xl border border-slate-300 px-3 py-2 text-xs font-mono"
                  />
                  <button
                    type="button"
                    onClick={async () => {
                      await apiRequest('/api/admin/promos', {
                        method: 'POST',
                        token,
                        body: {
                          code: newPromoCode,
                          discount_percent: Number(newPromoPct),
                          max_discount_iqd: Number(newPromoMax),
                        },
                      });
                      setNewPromoCode('');
                      loadAdminData();
                    }}
                    className="rounded-xl bg-slate-900 px-4 py-2 text-xs font-bold text-white"
                  >
                    إضافة عرض
                  </button>
                </div>

                <div className="divide-y divide-slate-100 text-xs">
                  {promos.map((pr) => (
                    <div key={pr.id} className="py-2.5 flex items-center justify-between">
                      <div>
                        <span className="font-mono font-bold text-slate-900">{pr.code}</span>
                        <span className="mx-2">·</span>
                        <span>خصم {pr.discount_percent}% (بحد أقصى {formatIQD(pr.max_discount_iqd)})</span>
                      </div>
                      <button
                        type="button"
                        onClick={async () => {
                          await apiRequest(`/api/admin/promos/${pr.id}`, {
                            method: 'PATCH',
                            token,
                            body: { is_active: pr.is_active ? 0 : 1 },
                          });
                          loadAdminData();
                        }}
                        className={`font-bold ${pr.is_active ? 'text-emerald-700' : 'text-slate-400'}`}
                      >
                        {pr.is_active ? 'مفعل (إيقاف)' : 'معطل (تفعيل)'}
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* TAB: MISHWAR PLUS */}
          {tab === 'plus' && plusSettings && (
            <div className="space-y-4">
              <div className="bg-white border border-slate-200 rounded-2xl p-5 space-y-4">
                <h3 className="text-base font-bold text-slate-900">إعدادات اشتراك MISHWAR PLUS</h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                  <div>
                    <label className="block text-slate-600 mb-1">سعر الاشتراك الشهري (د.ع)</label>
                    <input
                      type="number"
                      value={plusSettings.monthly_price_iqd}
                      onChange={(e) =>
                        setPlusSettings({ ...plusSettings, monthly_price_iqd: Number(e.target.value) })
                      }
                      className="w-full rounded-xl border border-slate-300 px-3 py-2 font-mono text-sm"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-600 mb-1">نسبة الخصم للمشتركين (%)</label>
                    <input
                      type="number"
                      value={plusSettings.discount_percent}
                      onChange={(e) =>
                        setPlusSettings({ ...plusSettings, discount_percent: Number(e.target.value) })
                      }
                      className="w-full rounded-xl border border-slate-300 px-3 py-2 font-mono text-sm"
                    />
                  </div>
                </div>

                <div className="space-y-2 text-xs">
                  <label className="flex items-center gap-2">
                    <input
                      type="checkbox"
                      checked={plusSettings.is_enabled === 1}
                      onChange={(e) => setPlusSettings({ ...plusSettings, is_enabled: e.target.checked ? 1 : 0 })}
                    />
                    <span>تفعيل نظام اشتراك MISHWAR PLUS للزبائن</span>
                  </label>
                  <label className="flex items-center gap-2">
                    <input
                      type="checkbox"
                      checked={plusSettings.waive_cancellation_fee === 1}
                      onChange={(e) =>
                        setPlusSettings({ ...plusSettings, waive_cancellation_fee: e.target.checked ? 1 : 0 })
                      }
                    />
                    <span>إعفاء المشتركين من رسوم الإلغاء</span>
                  </label>
                  <label className="flex items-center gap-2">
                    <input
                      type="checkbox"
                      checked={plusSettings.priority_matching_enabled === 1}
                      onChange={(e) =>
                        setPlusSettings({ ...plusSettings, priority_matching_enabled: e.target.checked ? 1 : 0 })
                      }
                    />
                    <span>منح أولوية التوزيع لأعلى السائقين تقييماً للمشتركين (تبقى معطلة ما لم يفعّلها المدير)</span>
                  </label>
                </div>

                <button
                  type="button"
                  onClick={async () => {
                    const res = await apiRequest<{ settings: PlusSettings }>('/api/admin/plus', {
                      method: 'PUT',
                      token,
                      body: plusSettings,
                    });
                    setPlusSettings(res.settings);
                    setStatusBanner('تم تحديث إعدادات MISHWAR PLUS');
                  }}
                  className="rounded-xl bg-blue-600 px-5 py-2.5 text-xs font-bold text-white"
                >
                  حفظ إعدادات PLUS
                </button>
              </div>

              <div className="bg-white border border-slate-200 rounded-2xl p-5">
                <h3 className="text-base font-bold text-slate-900 mb-3">المشتركون</h3>
                {plusSubs.length === 0 ? (
                  <p className="text-xs text-slate-500">لا يوجد مشتركون حالياً.</p>
                ) : (
                  <div className="divide-y divide-slate-100 text-xs">
                    {plusSubs.map((s) => (
                      <div key={s.id} className="py-3 flex items-center justify-between gap-2">
                        <div>
                          <div className="font-bold text-slate-900">
                            {s.user_name} ({s.user_phone})
                          </div>
                          <div className="text-slate-500">
                            البداية: {formatDateTimeAr(s.starts_at)} · النهاية: {formatDateTimeAr(s.ends_at)} ·{' '}
                            {formatIQD(s.price_iqd)}
                          </div>
                        </div>
                        <button
                          type="button"
                          onClick={async () => {
                            await apiRequest(`/api/admin/plus/subscriptions/${s.id}`, {
                              method: 'PATCH',
                              token,
                              body: { status: s.status === 'active' ? 'inactive' : 'active' },
                            });
                            loadAdminData();
                          }}
                          className={`font-bold ${s.status === 'active' ? 'text-emerald-700' : 'text-red-600'}`}
                        >
                          {s.status === 'active' ? 'نشط (إيقاف)' : 'متوقف (تفعيل)'}
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* TAB: COMPLAINTS, CHAT REPORTS, REPORTED USERS & AUDIT */}
          {tab === 'support_reports' && (
            <div className="space-y-4">
              <div className="bg-white border border-slate-200 rounded-2xl p-5 flex flex-wrap items-center justify-between gap-3">
                <div>
                  <h3 className="text-base font-bold text-slate-900">التقارير المالية</h3>
                  <p className="text-xs text-slate-500">تصدير سجل الرحلات والإيرادات بصيغة CSV</p>
                </div>
                <button
                  type="button"
                  onClick={exportFinancialCSV}
                  className="inline-flex items-center gap-2 rounded-xl bg-slate-900 px-4 py-2.5 text-xs font-bold text-white"
                >
                  <Download className="w-4 h-4" />
                  <span>تنزيل التقرير المالي (CSV)</span>
                </button>
              </div>

              {/* Reported Users Summary */}
              <div className="bg-white border border-slate-200 rounded-2xl p-5">
                <h3 className="text-base font-bold text-slate-900 mb-3">المستخدمون المبلغ عنهم</h3>
                {reportedUsers.length === 0 ? (
                  <p className="text-xs text-slate-500">لا يوجد مستخدمون مبلغ عنهم حالياً.</p>
                ) : (
                  <div className="divide-y divide-slate-100 text-xs">
                    {reportedUsers.map((ru) => (
                      <div key={ru.id} className="py-3 flex flex-wrap items-center justify-between gap-2">
                        <div>
                          <div className="font-bold text-slate-900">
                            {ru.name} {ru.account_number ? `[${ru.account_number}]` : ''} ({ru.role === 'driver' ? 'سائق' : 'زبون'}) ·{' '}
                            <span className="font-mono" dir="ltr">{ru.phone}</span>
                          </div>
                          <div className="text-slate-600">
                            عدد البلاغات: <span className="font-bold text-red-700">{ru.report_count}</span> · آخر سبب:{' '}
                            {ru.latest_reason}
                          </div>
                        </div>
                        <button
                          type="button"
                          onClick={async () => {
                            await apiRequest(`/api/admin/users/${ru.id}/status`, {
                              method: 'PATCH',
                              token,
                              body: { status: ru.status === 'active' ? 'suspended' : 'active' },
                            });
                            loadAdminData();
                          }}
                          className={`rounded-lg px-3 py-1.5 font-bold ${
                            ru.status === 'active' ? 'bg-red-600 text-white' : 'bg-emerald-600 text-white'
                          }`}
                        >
                          {ru.status === 'active' ? 'إيقاف الحساب فوراً' : 'إعادة التفعيل'}
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Abusive Chat Message Reports */}
              <div className="bg-white border border-slate-200 rounded-2xl p-5">
                <h3 className="text-base font-bold text-slate-900 mb-3">بلاغات رسائل المحادثة المسيئة</h3>
                {messageReports.length === 0 ? (
                  <p className="text-xs text-slate-500">لا توجد بلاغات محادثة.</p>
                ) : (
                  <div className="divide-y divide-slate-100 text-xs">
                    {messageReports.map((mr) => (
                      <div key={mr.id} className="py-3 space-y-1.5">
                        <div className="flex items-center justify-between">
                          <span className="font-bold text-slate-900">
                            المُبلّغ: {mr.reporter_name} ضد: {mr.reported_user_name}
                          </span>
                          <span className="text-slate-500">{mr.status}</span>
                        </div>
                        <div className="rounded-lg bg-red-50 border border-red-200 p-2 text-red-900">
                          الرسالة: "{mr.message_body}" — السبب: {mr.reason}
                        </div>
                        {mr.status === 'open' && (
                          <div className="flex gap-2">
                            <button
                              type="button"
                              onClick={async () => {
                                await apiRequest(`/api/admin/message-reports/${mr.id}`, {
                                  method: 'PATCH',
                                  token,
                                  body: { status: 'reviewed' },
                                });
                                loadAdminData();
                              }}
                              className="rounded-lg border border-slate-300 px-3 py-1 font-semibold"
                            >
                              تمت المراجعة
                            </button>
                            <button
                              type="button"
                              onClick={async () => {
                                await apiRequest(`/api/admin/message-reports/${mr.id}`, {
                                  method: 'PATCH',
                                  token,
                                  body: { status: 'action_taken', admin_note: 'تم اتخاذ إجراء إداري' },
                                });
                                loadAdminData();
                              }}
                              className="rounded-lg bg-slate-900 text-white px-3 py-1 font-semibold"
                            >
                              اتخاذ إجراء
                            </button>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Categorized Complaints & Appeals with Context Snapshot */}
              <div className="bg-white border border-slate-200 rounded-2xl p-5">
                <div className="flex flex-wrap items-center justify-between gap-3 mb-3">
                  <h3 className="text-base font-bold text-slate-900">إدارة الشكاوى والتظلمات المصنفة</h3>
                  <div className="flex items-center border border-slate-300 rounded-xl px-3 py-1.5 bg-white">
                    <Search className="w-3.5 h-3.5 text-slate-400 ml-2" />
                    <input
                      type="text"
                      value={complaintSearchQ}
                      onChange={(e) => setComplaintSearchQ(e.target.value)}
                      placeholder="بحث بـ MSH-C، MSH-D، MSH-TR، الموضوع..."
                      className="text-xs focus:outline-none w-56"
                    />
                  </div>
                </div>
                {complaints.length === 0 ? (
                  <p className="text-xs text-slate-500">لا توجد شكاوى أو تظلمات.</p>
                ) : (
                  <div className="divide-y divide-slate-100 space-y-3">
                    {complaints.map((c) => {
                      let parsedCtx: Record<string, unknown> | null = null;
                      if (c.appeal_context) {
                        try {
                          parsedCtx = JSON.parse(c.appeal_context) as Record<string, unknown>;
                        } catch {
                          parsedCtx = null;
                        }
                      }
                      return (
                        <div key={c.id} className="pt-3 space-y-2 text-xs">
                          <div className="flex flex-wrap items-center justify-between gap-2">
                            <span className="font-bold text-slate-900">
                              [{c.category || 'أسباب أخرى'}] {c.subject} — {c.user_name}{' '}
                              {c.user_account_number ? (
                                <span className="font-mono text-blue-700">({c.user_account_number})</span>
                              ) : null}{' '}
                              ({c.user_role})
                              {c.ride_number ? ` · رحلة ${c.ride_number}` : ''}
                            </span>
                            <span className="text-slate-500">{c.status}</span>
                          </div>
                          <p className="text-slate-600">{c.message}</p>
                          {parsedCtx && (
                            <div className="rounded-lg bg-slate-50 border border-slate-200 p-2.5 text-[11px] text-slate-700 flex flex-wrap gap-x-4 gap-y-1">
                              <span>حالة الحساب: <strong>{String(parsedCtx.user_status ?? '—')}</strong></span>
                              {parsedCtx.approval_status != null && (
                                <span>حالة الاعتماد: <strong>{String(parsedCtx.approval_status)}</strong></span>
                              )}
                              {parsedCtx.agreed_commission_percent !== undefined && (
                                <span>
                                  العمولة: <strong className="font-mono">{String(parsedCtx.agreed_commission_percent ?? '—')}%</strong>{' '}
                                  (الفعالة: <strong className="font-mono">{String(parsedCtx.active_commission_percent ?? '—')}%</strong>)
                                </span>
                              )}
                              {parsedCtx.wallet_bonus_balance_iqd !== undefined && (
                                <span>
                                  المحفظة: سماح <strong className="font-mono">{formatIQD(Number(parsedCtx.wallet_bonus_balance_iqd))}</strong> / حقيقي{' '}
                                  <strong className="font-mono">{formatIQD(Number(parsedCtx.wallet_real_balance_iqd ?? 0))}</strong>
                                </span>
                              )}
                            </div>
                          )}
                          {c.attachment_url && (
                            <button
                              type="button"
                              onClick={() => openProtectedDoc(`مرفق شكوى — ${c.subject}`, c.attachment_url)}
                              className="text-blue-600 font-semibold hover:underline"
                            >
                              عرض الصورة المرفقة
                            </button>
                          )}
                          <div className="flex gap-2">
                            <input
                              type="text"
                              value={replyText[c.id] ?? c.admin_reply ?? ''}
                              onChange={(e) => setReplyText({ ...replyText, [c.id]: e.target.value })}
                              placeholder="اكتب رد الإدارة..."
                              className="flex-1 rounded-xl border border-slate-300 px-3 py-2 text-xs"
                            />
                            <button
                              type="button"
                              onClick={async () => {
                                await apiRequest(`/api/admin/complaints/${c.id}`, {
                                  method: 'PATCH',
                                  token,
                                  body: { status: 'resolved', admin_reply: replyText[c.id] || 'تمت المعالجة' },
                                });
                                loadAdminData();
                              }}
                              className="rounded-xl bg-emerald-600 px-3 py-2 font-bold text-white"
                            >
                              حل وإغلاق
                            </button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>

              <div className="bg-white border border-slate-200 rounded-2xl p-5">
                <h3 className="text-base font-bold text-slate-900 mb-3 flex items-center gap-2">
                  <FileText className="w-4 h-4 text-slate-600" />
                  <span>سجل العمليات الحساسة (Audit Log)</span>
                </h3>
                <div className="max-h-72 overflow-y-auto divide-y divide-slate-100 text-xs">
                  {auditLogs.map((log) => (
                    <div key={log.id} className="py-2 flex items-center justify-between gap-2">
                      <div>
                        <span className="font-mono font-bold text-slate-800">{log.action}</span>
                        <span className="mx-1.5 text-slate-400">·</span>
                        <span className="text-slate-600">{log.actor_role}</span>
                        {log.details && <span className="mr-2 text-slate-400">{log.details}</span>}
                      </div>
                      <span className="text-slate-400 shrink-0">{formatDateTimeAr(log.created_at)}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* TAB: TRIP SHARES MONITORING */}
          {tab === 'shares' && (
            <div className="bg-white border border-slate-200 rounded-2xl p-5 space-y-4">
              <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                <Link2 className="w-4 h-4 text-blue-600" />
                <span>روابط مشاركة الرحلات الحية</span>
              </h3>
              {rideShares.length === 0 ? (
                <p className="text-xs text-slate-500 py-6 text-center">لم يتم إنشاء روابط مشاركة بعد.</p>
              ) : (
                <div className="divide-y divide-slate-100 text-xs">
                  {rideShares.map((sh) => (
                    <div key={sh.id} className="py-3 flex flex-wrap items-center justify-between gap-2">
                      <div>
                        <div className="font-bold text-slate-900">
                          الزبون: {sh.creator_name} · رحلة{' '}
                          <span className="font-mono">{sh.ride_number || sh.ride_id.slice(0, 8)}</span>
                        </div>
                        <div className="text-slate-600">
                          {sh.pickup_address} ← {sh.dropoff_address} ({sh.ride_status ? RIDE_STATUS_LABELS[sh.ride_status] : ''})
                        </div>
                        <div className="text-slate-400">
                          الإنشاء: {formatDateTimeAr(sh.created_at)} · الحالة:{' '}
                          {sh.is_active === 1 ? 'نشط' : `متوقف (${formatDateTimeAr(sh.revoked_at)})`}
                        </div>
                      </div>
                      {sh.is_active === 1 && (
                        <button
                          type="button"
                          onClick={async () => {
                            await apiRequest(`/api/admin/shares/${sh.id}/revoke`, { method: 'POST', token });
                            loadAdminData();
                          }}
                          className="rounded-xl bg-red-600 px-3 py-2 font-bold text-white"
                        >
                          إيقاف الرابط
                        </button>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* TAB: SECURITY, BACKUPS & APP SETTINGS */}
          {tab === 'security' && (
            <div className="space-y-4">
              {appSettings && (
                <div className="bg-white border border-slate-200 rounded-2xl p-5 space-y-3">
                  <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                    <Settings className="w-4 h-4 text-slate-600" />
                    <span>إعدادات التشغيل والنظام والطوارئ</span>
                  </h3>
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-xs">
                    <div>
                      <label className="block text-slate-600 mb-1">مهلة رد السائق (ثانية)</label>
                      <input
                        type="number"
                        value={appSettings.dispatch_timeout_sec}
                        onChange={(e) =>
                          setAppSettings({ ...appSettings, dispatch_timeout_sec: Number(e.target.value) })
                        }
                        className="w-full rounded-xl border border-slate-300 px-3 py-2 font-mono"
                      />
                    </div>
                    <div>
                      <label className="block text-slate-600 mb-1">نطاق البحث عن سائق (كم)</label>
                      <input
                        type="number"
                        value={appSettings.search_radius_km}
                        onChange={(e) =>
                          setAppSettings({ ...appSettings, search_radius_km: Number(e.target.value) })
                        }
                        className="w-full rounded-xl border border-slate-300 px-3 py-2 font-mono"
                      />
                    </div>
                    <div>
                      <label className="block text-slate-600 mb-1">رقم الطوارئ المعتمد (SOS)</label>
                      <input
                        type="tel"
                        dir="ltr"
                        value={appSettings.emergency_phone || '104'}
                        onChange={(e) =>
                          setAppSettings({ ...appSettings, emergency_phone: e.target.value })
                        }
                        className="w-full rounded-xl border border-slate-300 px-3 py-2 font-mono text-left"
                      />
                    </div>
                    <div className="flex items-end">
                      <label className="flex items-center gap-2 py-2">
                        <input
                          type="checkbox"
                          checked={appSettings.allow_driver_registration === 1}
                          onChange={(e) =>
                            setAppSettings({
                              ...appSettings,
                              allow_driver_registration: e.target.checked ? 1 : 0,
                            })
                          }
                        />
                        <span>السماح بتسجيل سائقين جدد</span>
                      </label>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={async () => {
                      const res = await apiRequest<{ settings: AppSettings }>('/api/admin/settings', {
                        method: 'PUT',
                        token,
                        body: appSettings,
                      });
                      setAppSettings(res.settings);
                      setStatusBanner('تم حفظ إعدادات التطبيق ورقم الطوارئ');
                    }}
                    className="rounded-xl bg-slate-900 px-4 py-2 text-xs font-bold text-white"
                  >
                    حفظ الإعدادات
                  </button>
                </div>
              )}

              <div className="bg-white border border-slate-200 rounded-2xl p-5">
                <h3 className="text-base font-bold text-slate-900 mb-3 flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 text-amber-600" />
                  <span>تنبيهات النشاط المشبوه والحماية</span>
                </h3>
                {securityEvents.length === 0 ? (
                  <p className="text-xs text-slate-500 py-4">لم يتم رصد أي نشاط مشبوه.</p>
                ) : (
                  <div className="divide-y divide-slate-100 max-h-80 overflow-y-auto text-xs">
                    {securityEvents.map((ev) => (
                      <div key={ev.id} className="py-3 flex items-center justify-between gap-3">
                        <div>
                          <div className="font-bold text-slate-900">
                            <span
                              className={
                                ev.severity === 'high' || ev.severity === 'critical'
                                  ? 'text-red-700'
                                  : 'text-amber-700'
                              }
                            >
                              [{ev.severity.toUpperCase()}]
                            </span>{' '}
                            {ev.summary}
                          </div>
                          <div className="text-slate-500 mt-0.5">
                            النوع: <span className="font-mono">{ev.event_type}</span> · IP:{' '}
                            <span className="font-mono">{ev.ip_address || '—'}</span> ·{' '}
                            {formatDateTimeAr(ev.created_at)}
                          </div>
                        </div>
                        {ev.is_resolved === 0 ? (
                          <button
                            type="button"
                            onClick={async () => {
                              await apiRequest(`/api/admin/security/${ev.id}/resolve`, {
                                method: 'PATCH',
                                token,
                              });
                              loadAdminData();
                            }}
                            className="rounded-lg border border-slate-200 px-3 py-1.5 font-semibold text-slate-700 shrink-0"
                          >
                            تمت المراجعة
                          </button>
                        ) : (
                          <span className="text-emerald-700 font-semibold shrink-0">مغلق</span>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </div>

              <div className="bg-white border border-slate-200 rounded-2xl p-5 space-y-3">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                      <Database className="w-4 h-4 text-blue-600" />
                      <span>النسخ الاحتياطية الدورية لقاعدة البيانات</span>
                    </h3>
                    <p className="text-xs text-slate-500">
                      نسخ تلقائي كل 6 ساعات مع بصمة تحقق SHA-256 وتشفير AES-256-GCM عند تفعيل مفتاح التشفير
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={async () => {
                      await apiRequest('/api/admin/backups', { method: 'POST', token });
                      loadAdminData();
                      setStatusBanner('تم إنشاء نسخة احتياطية جديدة بنجاح');
                    }}
                    className="rounded-xl bg-blue-600 px-4 py-2 text-xs font-bold text-white hover:bg-blue-700"
                  >
                    نسخة احتياطية الآن
                  </button>
                </div>

                <div className="divide-y divide-slate-100 text-xs">
                  {backups.map((b) => (
                    <div key={b.id} className="py-2.5 flex flex-wrap items-center justify-between gap-2">
                      <div>
                        <div className="font-mono font-bold text-slate-900">{b.filename}</div>
                        <div className="text-slate-500 font-mono text-[11px]">
                          SHA-256: {b.sha256.slice(0, 24)}... · {(b.size_bytes / 1024).toFixed(1)} KB ·{' '}
                          {b.encrypted ? 'مشفر AES-256-GCM' : 'نسخة SQLite موثقة'}
                        </div>
                      </div>
                      <span className="text-slate-500">{formatDateTimeAr(b.created_at)}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="bg-white border border-slate-200 rounded-2xl p-5 space-y-4">
                <div>
                  <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                    <Download className="w-4 h-4 text-blue-600" />
                    <span>تصدير المشاريع الثلاثة المستقلة بصيغة ZIP</span>
                  </h3>
                  <p className="text-xs text-slate-500 mt-1">
                    تنزيل كل مشروع بشكل مستقل مع كامل الكود المصدري، الصور، الأيقونات، ملفات الإعدادات، و{' '}
                    <span className="font-mono">package.json</span> جاهزاً للتشغيل والبناء.
                  </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  {[
                    {
                      target: 'customer' as const,
                      title: 'مشوار الزبون',
                      file: 'mishwar-customer.zip',
                      desc: 'تطبيق الزبون المستقل + الدليل الترحيبي + الدفع + الشعار',
                    },
                    {
                      target: 'driver' as const,
                      title: 'مشوار السائق',
                      file: 'mishwar-driver.zip',
                      desc: 'تطبيق السائق المستقل + زر مشوار + المحفظة + العمولات',
                    },
                    {
                      target: 'admin' as const,
                      title: 'لوحة الإدارة',
                      file: 'mishwar-admin.zip',
                      desc: 'لوحة الإدارة المستقلة + المالية + البحث الفوري + الأمان',
                    },
                  ].map((item) => (
                    <div
                      key={item.target}
                      className="rounded-xl border border-slate-200 bg-slate-50/70 p-4 flex flex-col justify-between gap-3"
                    >
                      <div>
                        <div className="text-sm font-bold text-slate-900">{item.title}</div>
                        <div className="text-[11px] font-mono text-blue-700 mt-0.5">{item.file}</div>
                        <p className="text-xs text-slate-600 mt-1.5 leading-relaxed">{item.desc}</p>
                      </div>
                      <button
                        type="button"
                        disabled={exportingTarget !== null}
                        onClick={async () => {
                          setExportingTarget(item.target);
                          try {
                            const res = await fetch(resolveApiUrl(`/api/admin/export/${item.target}`), {
                              headers: { Authorization: `Bearer ${token}` },
                            });
                            if (!res.ok) {
                              const errData = (await res.json().catch(() => ({}))) as { error?: string };
                              throw new Error(errData.error || 'تعذر تنزيل الحزمة');
                            }
                            const blob = await res.blob();
                            const url = URL.createObjectURL(blob);
                            const a = document.createElement('a');
                            a.href = url;
                            a.download = item.file;
                            document.body.appendChild(a);
                            a.click();
                            a.remove();
                            URL.revokeObjectURL(url);
                            setStatusBanner(`تم تجهيز وتنزيل ${item.file} بنجاح`);
                          } catch (err) {
                            setStatusBanner(err instanceof Error ? err.message : 'فشل تنزيل ملف ZIP');
                          } finally {
                            setExportingTarget(null);
                          }
                        }}
                        className="w-full inline-flex items-center justify-center gap-2 rounded-xl bg-blue-600 px-3 py-2.5 text-xs font-bold text-white hover:bg-blue-700 disabled:opacity-50 transition-colors"
                      >
                        <Download className="w-4 h-4" />
                        <span>
                          {exportingTarget === item.target ? 'جاري التجهيز...' : `تحميل ${item.file}`}
                        </span>
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </main>
      </div>

      {/* PROTECTED DOCUMENT / PHOTO PREVIEW MODAL */}
      {docPreview && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/70 p-4 backdrop-blur-sm">
          <div className="w-full max-w-lg rounded-2xl bg-white p-5 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-slate-900">{docPreview.title}</h3>
              <button
                type="button"
                onClick={() => {
                  URL.revokeObjectURL(docPreview.blobUrl);
                  setDocPreview(null);
                }}
                className="text-sm font-bold text-slate-500"
              >
                إغلاق
              </button>
            </div>
            <img
              src={docPreview.blobUrl}
              alt={docPreview.title}
              className="w-full max-h-[70vh] object-contain rounded-xl border border-slate-200"
            />
          </div>
        </div>
      )}

      {/* REJECT DRIVER REASON MODAL */}
      {rejectTargetId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 p-4">
          <div className="w-full max-w-md rounded-2xl bg-white p-5 space-y-3">
            <h3 className="font-bold text-slate-900">سبب رفض طلب السائق</h3>
            <textarea
              rows={3}
              value={rejectReason}
              onChange={(e) => setRejectReason(e.target.value)}
              placeholder="اكتب السبب ليظهر للسائق..."
              className="w-full rounded-xl border border-slate-300 p-3 text-xs"
            />
            <div className="flex gap-2">
              <button
                type="button"
                onClick={async () => {
                  await apiRequest(`/api/admin/drivers/${rejectTargetId}/reject`, {
                    method: 'POST',
                    token,
                    body: { reason: rejectReason },
                  });
                  setRejectTargetId(null);
                  setRejectReason('');
                  loadAdminData();
                }}
                className="flex-1 rounded-xl bg-red-600 py-2.5 text-xs font-bold text-white"
              >
                تأكيد الرفض
              </button>
              <button
                type="button"
                onClick={() => setRejectTargetId(null)}
                className="rounded-xl border border-slate-200 px-4 py-2.5 text-xs font-semibold"
              >
                إلغاء
              </button>
            </div>
          </div>
        </div>
      )}

      {/* REJECT DRIVER PHOTO REASON MODAL */}
      {rejectPhotoId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 p-4">
          <div className="w-full max-w-md rounded-2xl bg-white p-5 space-y-3">
            <h3 className="font-bold text-slate-900">سبب رفض الصورة الشخصية للسائق</h3>
            <textarea
              rows={3}
              value={rejectPhotoReason}
              onChange={(e) => setRejectPhotoReason(e.target.value)}
              placeholder="مثال: الصورة غير واضحة أو لا تظهر الوجه بوضوح..."
              className="w-full rounded-xl border border-slate-300 p-3 text-xs"
            />
            <div className="flex gap-2">
              <button
                type="button"
                onClick={async () => {
                  await apiRequest(`/api/admin/drivers/${rejectPhotoId}/photo/reject`, {
                    method: 'POST',
                    token,
                    body: { reason: rejectPhotoReason },
                  });
                  setRejectPhotoId(null);
                  setRejectPhotoReason('');
                  loadAdminData();
                }}
                className="flex-1 rounded-xl bg-amber-600 py-2.5 text-xs font-bold text-white"
              >
                رفض الصورة
              </button>
              <button
                type="button"
                onClick={() => setRejectPhotoId(null)}
                className="rounded-xl border border-slate-200 px-4 py-2.5 text-xs font-semibold"
              >
                إلغاء
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ADMIN WALLET ADJUSTMENT MODAL */}
      {adjustTarget && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 p-4 backdrop-blur-sm">
          <form
            onSubmit={async (e) => {
              e.preventDefault();
              setAdjustBusy(true);
              setAdjustError(null);
              try {
                await apiRequest(`/api/admin/wallets/${adjustTarget.driver_id}/adjust`, {
                  method: 'POST',
                  token,
                  body: {
                    walletPool: adjustPool,
                    deltaIqd: Number(adjustDelta),
                    reason: adjustReason,
                  },
                });
                setAdjustTarget(null);
                setStatusBanner(`تم تحديث محفظة السائق ${adjustTarget.driver_name}`);
                loadAdminData();
              } catch (err) {
                setAdjustError(err instanceof Error ? err.message : 'تعذر تعديل الرصيد');
              } finally {
                setAdjustBusy(false);
              }
            }}
            className="w-full max-w-md rounded-2xl bg-white p-5 space-y-3 text-xs"
          >
            <h3 className="text-base font-bold text-slate-900">
              تعديل محفظة السائق: {adjustTarget.driver_name} ({adjustTarget.driver_account_number})
            </h3>
            {adjustError && (
              <div className="rounded-xl bg-red-50 border border-red-200 p-2.5 text-red-700">{adjustError}</div>
            )}
            <div>
              <label className="block font-medium text-slate-700 mb-1">نوع الرصيد</label>
              <select
                value={adjustPool}
                onChange={(e) => setAdjustPool(e.target.value as 'real' | 'bonus')}
                className="w-full rounded-xl border border-slate-300 px-3 py-2 bg-white"
              >
                <option value="real">الرصيد الحقيقي (شحن / تسوية مالية)</option>
                <option value="bonus">رصيد السماح الافتراضي</option>
              </select>
            </div>
            <div>
              <label className="block font-medium text-slate-700 mb-1">
                المبلغ (موجب للإضافة أو سالب للخصم بالدينار العراقي)
              </label>
              <input
                type="number"
                required
                value={adjustDelta}
                onChange={(e) => setAdjustDelta(e.target.value)}
                placeholder="مثال: 10000 أو -2000"
                className="w-full rounded-xl border border-slate-300 px-3 py-2 font-mono"
              />
            </div>
            <div>
              <label className="block font-medium text-slate-700 mb-1">سبب التعديل الإداري (إلزامي)</label>
              <input
                type="text"
                required
                minLength={3}
                value={adjustReason}
                onChange={(e) => setAdjustReason(e.target.value)}
                placeholder="مثال: تعويض رحلة أو تسوية إدارية"
                className="w-full rounded-xl border border-slate-300 px-3 py-2"
              />
            </div>
            <div className="flex gap-2 pt-1">
              <button
                type="submit"
                disabled={adjustBusy}
                className="flex-1 rounded-xl bg-slate-900 py-2.5 font-bold text-white disabled:opacity-60"
              >
                {adjustBusy ? 'جاري التنفيذ...' : 'تأكيد التعديل'}
              </button>
              <button
                type="button"
                onClick={() => setAdjustTarget(null)}
                className="rounded-xl border border-slate-200 px-4 py-2.5 font-semibold"
              >
                إلغاء
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
