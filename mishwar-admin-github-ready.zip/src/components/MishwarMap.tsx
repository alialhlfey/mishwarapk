import L from 'leaflet';
import React, { useEffect, useRef } from 'react';

export interface MapPoint {
  lat: number;
  lng: number;
  label?: string;
}

export interface FleetMarker {
  id: string;
  lat: number;
  lng: number;
  name: string;
  category: string;
  isOnline: boolean;
  speedKmh: number | null;
}

interface MishwarMapProps {
  center?: [number, number];
  zoom?: number;
  pickup?: MapPoint | null;
  dropoff?: MapPoint | null;
  driverLocation?: { lat: number; lng: number; heading?: number | null } | null;
  routeGeometry?: [number, number][];
  driverToPickupGeometry?: [number, number][];
  fleetMarkers?: FleetMarker[];
  onMapClick?: (lat: number, lng: number) => void;
  onPickupDrag?: (lat: number, lng: number) => void;
  onDropoffDrag?: (lat: number, lng: number) => void;
  className?: string;
}

function createPinIcon(color: string, label: string) {
  return L.divIcon({
    className: 'mishwar-map-pin',
    html: `<div style="display:flex;flex-direction:column;align-items:center;transform:translate(-50%,-100%);">
      <div style="background:${color};color:#fff;font-family:'Cairo',sans-serif;font-size:11px;font-weight:700;padding:3px 8px;border-radius:8px;white-space:nowrap;box-shadow:0 4px 12px rgba(15,23,42,0.28);border:2px solid #fff;">${label}</div>
      <div style="width:12px;height:12px;background:${color};border:2.5px solid #fff;border-radius:50%;margin-top:2px;box-shadow:0 2px 6px rgba(0,0,0,0.3);"></div>
    </div>`,
    iconSize: [0, 0],
    iconAnchor: [0, 0],
  });
}

function createCarIcon(heading: number | null | undefined, online = true) {
  const rot = typeof heading === 'number' && Number.isFinite(heading) ? heading : 0;
  const fill = online ? '#1D4ED8' : '#64748B';
  return L.divIcon({
    className: 'mishwar-car-icon',
    html: `<div style="width:36px;height:36px;display:flex;align-items:center;justify-content:center;transform:translate(-50%,-50%) rotate(${rot}deg);transition:transform 0.3s ease;">
      <svg width="32" height="32" viewBox="0 0 36 36" fill="none">
        <circle cx="18" cy="18" r="16" fill="#FFFFFF" stroke="${fill}" stroke-width="2.5"/>
        <path d="M18 7 L24 23 L18 19.5 L12 23 Z" fill="${fill}"/>
      </svg>
    </div>`,
    iconSize: [36, 36],
    iconAnchor: [0, 0],
  });
}

export const MishwarMap: React.FC<MishwarMapProps> = ({
  center = [33.3152, 44.3661], // Baghdad default center
  zoom = 12,
  pickup,
  dropoff,
  driverLocation,
  routeGeometry,
  driverToPickupGeometry,
  fleetMarkers,
  onMapClick,
  onPickupDrag,
  onDropoffDrag,
  className = 'w-full h-full min-h-[360px]',
}) => {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const mapRef = useRef<L.Map | null>(null);
  const layersRef = useRef<{
    pickup?: L.Marker;
    dropoff?: L.Marker;
    driver?: L.Marker;
    route?: L.Polyline;
    approach?: L.Polyline;
    fleet: L.Marker[];
  }>({ fleet: [] });

  const onMapClickRef = useRef(onMapClick);
  const onPickupDragRef = useRef(onPickupDrag);
  const onDropoffDragRef = useRef(onDropoffDrag);
  onMapClickRef.current = onMapClick;
  onPickupDragRef.current = onPickupDrag;
  onDropoffDragRef.current = onDropoffDrag;

  useEffect(() => {
    if (!containerRef.current || mapRef.current) return;

    const map = L.map(containerRef.current, {
      center,
      zoom,
      zoomControl: true,
    });

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '&copy; OpenStreetMap',
      maxZoom: 19,
    }).addTo(map);

    map.on('click', (e: L.LeafletMouseEvent) => {
      onMapClickRef.current?.(e.latlng.lat, e.latlng.lng);
    });

    mapRef.current = map;
    return () => {
      map.remove();
      mapRef.current = null;
    };
  }, []);

  // Update center when explicitly changed and no markers override
  useEffect(() => {
    const map = mapRef.current;
    if (!map) return;
    if (!pickup && !dropoff && !driverLocation && (!fleetMarkers || fleetMarkers.length === 0)) {
      map.setView(center, zoom, { animate: true });
    }
  }, [center[0], center[1], zoom]);

  // Update Pickup, Dropoff, Driver, Routes, and Fleet Markers
  useEffect(() => {
    const map = mapRef.current;
    if (!map) return;
    const layers = layersRef.current;

    // Pickup
    if (pickup) {
      if (!layers.pickup) {
        layers.pickup = L.marker([pickup.lat, pickup.lng], {
          icon: createPinIcon('#059669', 'الانطلاق'),
          draggable: Boolean(onPickupDragRef.current),
        }).addTo(map);
        layers.pickup.on('dragend', () => {
          const pos = layers.pickup!.getLatLng();
          onPickupDragRef.current?.(pos.lat, pos.lng);
        });
      } else {
        layers.pickup.setLatLng([pickup.lat, pickup.lng]);
      }
    } else if (layers.pickup) {
      layers.pickup.remove();
      layers.pickup = undefined;
    }

    // Dropoff
    if (dropoff) {
      if (!layers.dropoff) {
        layers.dropoff = L.marker([dropoff.lat, dropoff.lng], {
          icon: createPinIcon('#DC2626', 'الوجهة'),
          draggable: Boolean(onDropoffDragRef.current),
        }).addTo(map);
        layers.dropoff.on('dragend', () => {
          const pos = layers.dropoff!.getLatLng();
          onDropoffDragRef.current?.(pos.lat, pos.lng);
        });
      } else {
        layers.dropoff.setLatLng([dropoff.lat, dropoff.lng]);
      }
    } else if (layers.dropoff) {
      layers.dropoff.remove();
      layers.dropoff = undefined;
    }

    // Driver live marker
    if (driverLocation) {
      if (!layers.driver) {
        layers.driver = L.marker([driverLocation.lat, driverLocation.lng], {
          icon: createCarIcon(driverLocation.heading, true),
        }).addTo(map);
      } else {
        layers.driver.setLatLng([driverLocation.lat, driverLocation.lng]);
        layers.driver.setIcon(createCarIcon(driverLocation.heading, true));
      }
    } else if (layers.driver) {
      layers.driver.remove();
      layers.driver = undefined;
    }

    // Route polyline (Pickup -> Dropoff)
    if (layers.route) {
      layers.route.remove();
      layers.route = undefined;
    }
    if (routeGeometry && routeGeometry.length >= 2) {
      layers.route = L.polyline(routeGeometry, {
        color: '#1D4ED8',
        weight: 5,
        opacity: 0.9,
      }).addTo(map);
    }

    // Approach polyline (Driver -> Pickup)
    if (layers.approach) {
      layers.approach.remove();
      layers.approach = undefined;
    }
    if (driverToPickupGeometry && driverToPickupGeometry.length >= 2) {
      layers.approach = L.polyline(driverToPickupGeometry, {
        color: '#2563EB',
        weight: 4,
        dashArray: '8, 8',
        opacity: 0.85,
      }).addTo(map);
    }

    // Fleet markers (Admin live view)
    for (const m of layers.fleet) m.remove();
    layers.fleet = [];
    if (fleetMarkers && fleetMarkers.length > 0) {
      for (const fm of fleetMarkers) {
        const marker = L.marker([fm.lat, fm.lng], {
          icon: createCarIcon(0, fm.isOnline),
        })
          .bindPopup(
            `<div style="font-size:12px;">
              <strong>${fm.name}</strong><br/>
              الفئة: ${fm.category}<br/>
              الحالة: ${fm.isOnline ? 'مشوار يعمل' : 'متوقف'}<br/>
              السرعة: ${fm.speedKmh != null ? `${fm.speedKmh} كم/س` : 'غير متاح'}
            </div>`,
          )
          .addTo(map);
        layers.fleet.push(marker);
      }
    }

    // Fit bounds nicely when key points exist
    const pts: [number, number][] = [];
    if (pickup) pts.push([pickup.lat, pickup.lng]);
    if (dropoff) pts.push([dropoff.lat, dropoff.lng]);
    if (driverLocation) pts.push([driverLocation.lat, driverLocation.lng]);
    if (pts.length >= 2) {
      map.fitBounds(pts, { padding: [48, 48], maxZoom: 15 });
    } else if (pts.length === 1) {
      map.panTo(pts[0], { animate: true });
    }
  }, [
    pickup?.lat,
    pickup?.lng,
    dropoff?.lat,
    dropoff?.lng,
    driverLocation?.lat,
    driverLocation?.lng,
    driverLocation?.heading,
    routeGeometry,
    driverToPickupGeometry,
    fleetMarkers,
  ]);

  return <div ref={containerRef} className={className} />;
};
