import React, { useEffect, useState } from 'react';
import { fetchProtectedImageBlobUrl, resolveApiUrl } from '../lib/api';

interface ProtectedImageProps {
  src: string | null | undefined;
  token: string | null;
  alt: string;
  className?: string;
  fallback?: React.ReactNode;
}

export const ProtectedImage: React.FC<ProtectedImageProps> = ({
  src,
  token,
  alt,
  className = '',
  fallback = null,
}) => {
  const [blobUrl, setBlobUrl] = useState<string | null>(null);
  const [failed, setFailed] = useState(false);

  useEffect(() => {
    let active = true;
    let createdUrl: string | null = null;
    setFailed(false);

    if (!src) {
      setBlobUrl(null);
      return;
    }

    if (!src.startsWith('/api/uploads/') || !token) {
      setBlobUrl(resolveApiUrl(src));
      return;
    }

    fetchProtectedImageBlobUrl(src, token)
      .then((url) => {
        if (!active) {
          URL.revokeObjectURL(url);
          return;
        }
        createdUrl = url;
        setBlobUrl(url);
      })
      .catch(() => {
        if (active) {
          setBlobUrl(null);
          setFailed(true);
        }
      });

    return () => {
      active = false;
      if (createdUrl) {
        URL.revokeObjectURL(createdUrl);
      }
    };
  }, [src, token]);

  if (!src || failed || !blobUrl) {
    return <>{fallback}</>;
  }

  return <img src={blobUrl} alt={alt} className={className} />;
};
