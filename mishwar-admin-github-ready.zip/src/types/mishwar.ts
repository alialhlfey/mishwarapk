export type UserRole = 'customer' | 'driver' | 'admin';

export type VehicleCategory = 'Economy' | 'Super' | 'Plus' | 'Family';

export type RideStatus =
  | 'searching'
  | 'found'
  | 'on_the_way'
  | 'arrived'
  | 'in_progress'
  | 'completed'
  | 'cancelled';

export type DriverApprovalStatus = 'pending' | 'approved' | 'rejected';

export interface User {
  id: string;
  account_number: string;
  role: UserRole;
  name: string;
  phone: string;
  avatar_url: string | null;
  status: 'active' | 'suspended';
  rating_avg?: number;
  rating_count?: number;
  terms_accepted_version?: string | null;
  terms_accepted_at?: string | null;
  created_at: string;
}

export interface DriverProfile {
  user_id: string;
  approval_status: DriverApprovalStatus;
  rejection_reason: string | null;
  photo_status: DriverApprovalStatus;
  photo_rejection_reason: string | null;
  pending_avatar_url: string | null;
  car_make: string;
  car_model: string;
  car_year: number;
  car_color: string;
  plate_number: string;
  category: VehicleCategory;
  license_doc_url: string | null;
  registration_doc_url: string | null;
  national_id_doc_url: string | null;
  is_online: number;
  current_lat: number | null;
  current_lng: number | null;
  current_speed_kmh: number | null;
  heading: number | null;
  last_location_at: string | null;
  rating_avg: number;
  rating_count: number;
  agreed_commission_percent?: number | null;
  commission_agreed_at?: string | null;
}

export interface PricingRules {
  id: number;
  base_fare_iqd: number;
  per_km_iqd: number;
  min_fare_iqd: number;
  waiting_fee_per_min_iqd: number;
  cancellation_fee_iqd: number;
  economy_multiplier: number;
  super_multiplier: number;
  plus_multiplier: number;
  family_multiplier: number;
  commission_percent: number;
  updated_at: string;
}

export type PaymentMethod = 'cash' | 'superqi' | 'zaincash';

export type PaymentGatewayStatus = 'pending_approval' | 'sandbox' | 'production';

export interface PaymentGatewayConfig {
  provider: PaymentMethod;
  display_name_ar: string;
  is_enabled: number;
  merchant_approved: number;
  environment: PaymentGatewayStatus;
  merchant_id: string | null;
  api_base_url: string | null;
  min_topup_iqd: number;
  credentials_configured?: boolean;
  available?: boolean;
  unavailable_reason_ar?: string | null;
  updated_at: string;
}

export interface PaymentTransaction {
  id: string;
  reference_id: string;
  purpose: 'ride_payment' | 'driver_wallet_topup';
  ride_id: string | null;
  ride_number?: string | null;
  user_id: string;
  user_name?: string;
  user_account_number?: string;
  driver_id: string | null;
  driver_name?: string;
  driver_account_number?: string | null;
  provider: PaymentMethod;
  amount_iqd: number;
  commission_percent: number;
  commission_iqd: number;
  driver_net_iqd: number;
  status: 'pending' | 'awaiting_gateway' | 'confirmed' | 'failed' | 'cancelled';
  gateway_transaction_id: string | null;
  checkout_url: string | null;
  verified_source: string | null;
  failure_reason: string | null;
  confirmed_at: string | null;
  created_at: string;
  updated_at: string;
}

export interface DriverWallet {
  driver_id: string;
  driver_account_number?: string;
  driver_name?: string;
  driver_phone?: string;
  is_online?: number;
  approval_status?: DriverApprovalStatus;
  opening_bonus_iqd: number;
  opening_bonus_granted_at: string | null;
  bonus_balance_iqd: number;
  real_balance_iqd: number;
  total_available_iqd?: number;
  total_topped_up_iqd: number;
  total_electronic_earnings_iqd: number;
  total_commission_iqd: number;
  total_commission_from_bonus_iqd: number;
  total_commission_from_real_iqd: number;
  uncollected_commission_iqd: number;
  auto_paused_zero_balance: number;
  updated_at: string;
}

export interface WalletTransaction {
  id: string;
  driver_id: string;
  driver_account_number?: string;
  driver_name?: string;
  ride_id: string | null;
  ride_number?: string | null;
  payment_id: string | null;
  entry_type:
    | 'opening_bonus'
    | 'commission_deduction'
    | 'wallet_topup'
    | 'electronic_ride_credit'
    | 'admin_adjustment_real'
    | 'admin_adjustment_bonus';
  bonus_delta_iqd: number;
  real_delta_iqd: number;
  bonus_after_iqd: number;
  real_after_iqd: number;
  gross_amount_iqd: number;
  commission_iqd: number;
  is_real_money: number;
  note: string;
  created_by_user_id: string | null;
  created_at: string;
}

export interface FinancialAccountingReport {
  virtual_opening_bonuses_granted_iqd: number;
  virtual_opening_bonus_remaining_iqd: number;
  real_topups_confirmed_iqd: number;
  real_wallet_balances_total_iqd: number;
  total_commissions_charged_iqd: number;
  commissions_covered_by_virtual_bonus_iqd: number;
  commissions_collected_real_cash_iqd: number;
  electronic_gross_volume_iqd: number;
  electronic_driver_net_payable_iqd: number;
  cash_rides_gross_volume_iqd: number;
  uncollected_commissions_iqd: number;
}

export interface PlusSettings {
  id: number;
  monthly_price_iqd: number;
  discount_percent: number;
  waive_cancellation_fee: number;
  priority_matching_enabled: number;
  is_enabled: number;
  updated_at: string;
}

export interface PlusSubscription {
  id: string;
  user_id: string;
  user_name?: string;
  user_phone?: string;
  status: 'active' | 'inactive' | 'expired';
  price_iqd: number;
  starts_at: string;
  ends_at: string;
  created_at: string;
}

export interface AppSettings {
  id: number;
  dispatch_timeout_sec: number;
  search_radius_km: number;
  allow_driver_registration: number;
  emergency_phone: string;
  updated_at: string;
}

export interface PromoCode {
  id: string;
  code: string;
  discount_percent: number;
  max_discount_iqd: number;
  is_active: number;
  expires_at: string | null;
  created_at: string;
}

export interface Ride {
  id: string;
  ride_number: string;
  customer_id: string;
  customer_account_number?: string;
  driver_id: string | null;
  driver_account_number?: string | null;
  category: VehicleCategory;
  status: RideStatus;
  pickup_lat: number;
  pickup_lng: number;
  pickup_address: string;
  dropoff_lat: number;
  dropoff_lng: number;
  dropoff_address: string;
  distance_km: number;
  duration_min: number;
  base_fare_iqd: number;
  distance_fare_iqd: number;
  waiting_minutes: number;
  waiting_fee_iqd: number;
  discount_iqd: number;
  cancellation_fee_iqd: number;
  final_fare_iqd: number;
  promo_code: string | null;
  payment_method: PaymentMethod | 'electronic_pending';
  payment_status?: 'pending' | 'paid' | 'failed';
  payment_id?: string | null;
  commission_percent?: number;
  commission_iqd?: number;
  driver_net_iqd?: number;
  cancelled_by: string | null;
  cancel_reason: string | null;
  driver_rating: number | null;
  driver_review: string | null;
  customer_rating: number | null;
  customer_review: string | null;
  rating_moderated?: number;
  created_at: string;
  accepted_at: string | null;
  arrived_at: string | null;
  started_at: string | null;
  completed_at: string | null;
  cancelled_at: string | null;
  customer_name?: string;
  customer_phone?: string;
  customer_phone_masked?: string;
  customer_avatar?: string | null;
  driver_name?: string;
  driver_phone?: string;
  driver_phone_masked?: string;
  driver_avatar?: string | null;
  driver_rating_avg?: number;
  car_make?: string;
  car_model?: string;
  car_year?: number;
  car_color?: string;
  plate_number?: string;
  driver_lat?: number | null;
  driver_lng?: number | null;
  driver_speed_kmh?: number | null;
  driver_heading?: number | null;
}

export interface RideMessage {
  id: string;
  ride_id: string;
  sender_id: string;
  sender_role: 'customer' | 'driver';
  sender_name?: string;
  body: string;
  is_reported: number;
  created_at: string;
}

export interface MessageReport {
  id: string;
  ride_id: string;
  message_id: string;
  reporter_id: string;
  reporter_name?: string;
  reported_user_id: string;
  reported_user_name?: string;
  message_body: string;
  reason: string;
  status: 'open' | 'reviewed' | 'action_taken';
  admin_note: string | null;
  created_at: string;
}

export interface RideNotification {
  id: string;
  user_id: string;
  title: string;
  body: string;
  type: string;
  ride_id: string | null;
  is_read: number;
  created_at: string;
}

export interface Complaint {
  id: string;
  user_id: string;
  user_account_number?: string;
  user_name?: string;
  user_phone?: string;
  user_role?: UserRole;
  ride_id: string | null;
  ride_number?: string | null;
  category: string;
  subject: string;
  message: string;
  attachment_url?: string | null;
  appeal_context?: string | null;
  status: 'open' | 'in_review' | 'resolved';
  admin_reply: string | null;
  created_at: string;
  resolved_at: string | null;
}

export interface SosAlert {
  id: string;
  ride_id: string | null;
  ride_number?: string | null;
  user_id: string;
  user_account_number?: string;
  user_name?: string;
  user_phone?: string;
  user_role: 'customer' | 'driver';
  lat: number | null;
  lng: number | null;
  incident_type: string;
  notes: string | null;
  status: 'active' | 'acknowledged' | 'resolved' | 'cancelled_false_alarm';
  admin_note: string | null;
  created_at: string;
  resolved_at: string | null;
  pickup_address?: string;
  dropoff_address?: string;
  ride_status?: RideStatus;
  driver_name?: string;
  customer_name?: string;
}

export interface RideShareRecord {
  id: string;
  ride_id: string;
  ride_number?: string | null;
  created_by_user_id: string;
  creator_name?: string;
  pickup_address?: string;
  dropoff_address?: string;
  ride_status?: RideStatus;
  is_active: number;
  expires_at: string;
  created_at: string;
  revoked_at: string | null;
}

export const COMPLAINT_CATEGORIES = [
  'تظلّم / اعتراض إداري (إيقاف حساب / عمولة / محفظة)',
  'سوء التعامل',
  'مشكلة في الأجرة',
  'تأخر السائق',
  'مشكلة في الموقع',
  'سلوك غير مناسب',
  'مشكلة أثناء الرحلة',
  'أسباب أخرى',
] as const;

export interface AuditLog {
  id: string;
  actor_user_id: string | null;
  actor_role: string;
  action: string;
  target_type: string;
  target_id: string | null;
  details: string | null;
  created_at: string;
}

export interface SecurityEvent {
  id: string;
  severity: 'low' | 'medium' | 'high' | 'critical';
  event_type: string;
  actor_user_id: string | null;
  ip_address: string | null;
  summary: string;
  details: string | null;
  is_resolved: number;
  created_at: string;
}

export interface BackupRecord {
  id: string;
  filename: string;
  size_bytes: number;
  sha256: string;
  encrypted: number;
  trigger_type: string;
  created_at: string;
}

export interface FareEstimate {
  category: VehicleCategory;
  distance_km: number;
  duration_min: number;
  base_fare_iqd: number;
  distance_fare_iqd: number;
  subtotal_iqd: number;
  discount_iqd: number;
  final_fare_iqd: number;
  plus_applied: boolean;
  promo_applied: string | null;
}

export const CATEGORY_LABELS: Record<VehicleCategory, { ar: string; desc: string }> = {
  Economy: { ar: 'اقتصادية', desc: 'خيار عملي وموفر للتنقل اليومي' },
  Super: { ar: 'مميزة', desc: 'سيارات حديثة ومكيفة لراحة إضافية' },
  Plus: { ar: 'بلس', desc: 'سيارات فئة رجال الأعمال والخدمة الراقية' },
  Family: { ar: 'عائلية', desc: 'سيارات واسعة تتسع للعائلة والأمتعة' },
};

export const RIDE_STATUS_LABELS: Record<RideStatus, string> = {
  searching: 'جاري البحث عن سائق',
  found: 'تم العثور على سائق',
  on_the_way: 'السائق في الطريق',
  arrived: 'وصل السائق',
  in_progress: 'بدأت الرحلة',
  completed: 'انتهت الرحلة',
  cancelled: 'الرحلة ملغاة',
};

export const PAYMENT_METHOD_LABELS: Record<PaymentMethod, string> = {
  cash: 'نقداً',
  superqi: 'سوبر كي (كي كارد)',
  zaincash: 'زين كاش',
};

