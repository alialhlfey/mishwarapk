import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

// Isolate test database cleanly before importing server modules
const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'mishwar-sec-test-'));
process.env.MISHWAR_TEST_MODE = '1';
process.env.MISHWAR_DB_PATH = path.join(tmpDir, 'test-mishwar.db');
process.env.DATA_ENCRYPTION_KEY = 'mishwar-test-aes-256-gcm-key-32bytes!';

// Generate ephemeral RSA-2048 keypair & ZainCash HS256 secret ONLY inside test memory
const { publicKey: sqPublicPem, privateKey: sqPrivatePem } = crypto.generateKeyPairSync('rsa', {
  modulusLength: 2048,
  publicKeyEncoding: { type: 'spki', format: 'pem' },
  privateKeyEncoding: { type: 'pkcs8', format: 'pem' },
});
process.env.SUPERQI_MERCHANT_ID = 'TEST-MERCHANT-SQ';
process.env.SUPERQI_API_KEY = 'TEST-API-KEY-SQ';
process.env.SUPERQI_PUBLIC_KEY_PEM = sqPublicPem;

process.env.ZAINCASH_CLIENT_ID = 'TEST-ZC-CLIENT';
process.env.ZAINCASH_CLIENT_SECRET = 'TEST-ZC-SECRET';
process.env.ZAINCASH_MERCHANT_SECRET = 'TEST-ZC-HMAC-SECRET-32-BYTES-MIN!';

// Intercept ONLY outbound HTTPS requests to external payment gateway hosts in test runtime
const originalFetch = globalThis.fetch;
globalThis.fetch = (async (input: RequestInfo | URL, init?: RequestInit) => {
  const urlStr = typeof input === 'string' ? input : input instanceof URL ? input.toString() : input.url;
  if (urlStr.startsWith('https://') && urlStr.includes('qi.iq')) {
    return new Response(
      JSON.stringify({ formUrl: 'https://payment.qi.iq/checkout/test-session', paymentId: 'SQ-GW-1001' }),
      { status: 200, headers: { 'Content-Type': 'application/json' } },
    );
  }
  if (urlStr.startsWith('https://') && urlStr.includes('zaincash.iq')) {
    if (urlStr.includes('/oauth2/token')) {
      return new Response(JSON.stringify({ access_token: 'zc-test-oauth-token' }), {
        status: 200,
        headers: { 'Content-Type': 'application/json' },
      });
    }
    return new Response(
      JSON.stringify({ redirectUrl: 'https://pg-api.zaincash.iq/pay/test-session', transactionId: 'ZC-GW-2002' }),
      { status: 200, headers: { 'Content-Type': 'application/json' } },
    );
  }
  return originalFetch(input, init);
}) as typeof fetch;

const { createMishwarServer } = await import('../server.ts');
const { resetSecurityRateLimitsForTests } = await import('../server/security.ts');
const { db } = await import('../server/db.ts');

const { server } = createMishwarServer();
await new Promise<void>((resolve) => server.listen(0, '127.0.0.1', resolve));
const addr = server.address() as { port: number };
const BASE = `http://127.0.0.1:${addr.port}`;

async function req(
  p: string,
  opts: { method?: string; token?: string; body?: unknown; headers?: Record<string, string> } = {},
) {
  const headers: Record<string, string> = { ...(opts.headers ?? {}) };
  if (opts.body !== undefined) headers['Content-Type'] = 'application/json';
  if (opts.token) headers['Authorization'] = `Bearer ${opts.token}`;
  const res = await fetch(`${BASE}${p}`, {
    method: opts.method ?? 'GET',
    headers,
    body: opts.body !== undefined ? JSON.stringify(opts.body) : undefined,
  });
  const json = await res.json().catch(() => ({}));
  return { status: res.status, headers: res.headers, json: json as Record<string, unknown> };
}

function signZainCashJwt(payload: Record<string, unknown>, secret: string): string {
  const h = Buffer.from(JSON.stringify({ alg: 'HS256', typ: 'JWT' })).toString('base64url');
  const p = Buffer.from(JSON.stringify(payload)).toString('base64url');
  const sig = crypto.createHmac('sha256', secret).update(`${h}.${p}`).digest('base64url');
  return `${h}.${p}.${sig}`;
}

// Minimal valid 1x1 PNG base64 for legitimate image upload tests
const VALID_PNG_DATA_URL =
  'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNk+A8AAQUBAScY42YAAAAASUVORK5CYII=';

const results: Array<{ name: string; status: 'PASS'; detail: string }> = [];

try {
  // 1. Security Headers Verification
  {
    const res = await req('/api/health');
    assert.equal(res.status, 200);
    assert.equal(res.headers.get('x-content-type-options'), 'nosniff');
    assert.ok(res.headers.get('cache-control')?.includes('no-store'));
    results.push({ name: 'Security Headers & Cache-Control', status: 'PASS', detail: 'nosniff + no-store verified' });
  }

  // 2. Unauthenticated Access Rejection (401)
  {
    const r1 = await req('/api/admin/overview');
    const r2 = await req('/api/rides/active');
    const r3 = await req('/api/driver/earnings');
    assert.equal(r1.status, 401);
    assert.equal(r2.status, 401);
    assert.equal(r3.status, 401);
    results.push({ name: 'Unauthenticated Route Guard', status: 'PASS', detail: 'All protected routes returned 401' });
  }

  // 3. Admin First-Run Claim + Account Number MSH-A-000001 + Lockout Against Re-Claim
  let adminToken = '';
  {
    const claim1 = await req('/api/admin/claim', {
      method: 'POST',
      body: { name: 'مدير الاختبار', password: 'StrongAdminPass!2026' },
    });
    assert.equal(claim1.status, 201);
    adminToken = String(claim1.json.token);
    const admUser = claim1.json.user as { account_number: string };
    assert.equal(admUser.account_number, 'MSH-A-000001');

    const claim2 = await req('/api/admin/claim', {
      method: 'POST',
      body: { name: 'Attacker', password: 'AttackerPassword123' },
    });
    assert.equal(claim2.status, 409);
    results.push({
      name: 'Admin Claim Lock & MSH-A Number',
      status: 'PASS',
      detail: 'MSH-A-000001 generated, second claim blocked (409)',
    });
  }

  // 4. Customer Terms Enforcement, MSH-C-000001 & RBAC Cross-Role Block (403)
  let customerToken = '';
  let customerAccountNumber = '';
  {
    const noTerms = await req('/api/auth/customer/register', {
      method: 'POST',
      body: { name: 'بدون موافقة', phone: '07709998877', password: 'CustomerPass123' },
    });
    assert.equal(noTerms.status, 400);

    const reg = await req('/api/auth/customer/register', {
      method: 'POST',
      body: { name: 'زبون اختبار', phone: '07701112233', password: 'CustomerPass123', acceptTerms: true },
    });
    assert.equal(reg.status, 201);
    customerToken = String(reg.json.token);
    const custUser = reg.json.user as { account_number: string };
    customerAccountNumber = custUser.account_number;
    assert.equal(customerAccountNumber, 'MSH-C-000001');

    // Attempt to tamper with immutable account_number
    const tamperRes = await req('/api/auth/profile', {
      method: 'PATCH',
      token: customerToken,
      body: { account_number: 'MSH-C-999999', name: 'اسم جديد' },
    });
    assert.equal(tamperRes.status, 403);

    // Legal terms endpoint verification
    const termsRes = await req('/api/legal/terms');
    assert.equal(termsRes.status, 200);
    const custTerms = termsRes.json.customer as { clauses: unknown[] };
    const drvTerms = termsRes.json.driver as { clauses: unknown[] };
    assert.equal(custTerms.clauses.length, 14);
    assert.equal(drvTerms.clauses.length, 20);

    const admTry1 = await req('/api/admin/overview', { token: customerToken });
    const admTry2 = await req('/api/admin/pricing', {
      method: 'PUT',
      token: customerToken,
      body: { base_fare_iqd: 1 },
    });
    const drvTry = await req('/api/driver/earnings', { token: customerToken });
    assert.equal(admTry1.status, 403);
    assert.equal(admTry2.status, 403);
    assert.equal(drvTry.status, 403);
    results.push({
      name: 'Terms Enforcement, Account Immutability & RBAC',
      status: 'PASS',
      detail: '14/20 clauses served, MSH-C-000001 immutable, cross-role blocked (403)',
    });
  }

  // 5. Concurrent Registration Sequence Uniqueness (No Duplicate MSH-C Numbers)
  {
    const concurrentRegs = await Promise.all(
      ['07710000001', '07710000002', '07710000003', '07710000004'].map((ph, idx) =>
        req('/api/auth/customer/register', {
          method: 'POST',
          body: { name: `زبون متزامن ${idx + 1}`, phone: ph, password: 'CustomerPass123', acceptTerms: true },
        }),
      ),
    );
    const nums = concurrentRegs.map((r) => {
      assert.equal(r.status, 201);
      return (r.json.user as { account_number: string }).account_number;
    });
    assert.equal(new Set(nums).size, 4);
    assert.deepEqual(nums.sort(), ['MSH-C-000002', 'MSH-C-000003', 'MSH-C-000004', 'MSH-C-000005']);

    // Search by MSH-C-000003 in Admin
    const searchRes = await req('/api/admin/customers?q=MSH-C-000003', { token: adminToken });
    assert.equal(searchRes.status, 200);
    const found = searchRes.json.customers as Array<{ account_number: string }>;
    assert.equal(found.length, 1);
    assert.equal(found[0].account_number, 'MSH-C-000003');
    results.push({
      name: 'Concurrent Sequence Safety & Admin Search',
      status: 'PASS',
      detail: '4 concurrent customers received unique sequential MSH-C IDs + ?q= verified',
    });
  }

  // 6. Malicious File Upload & Path Traversal Protection
  {
    const fakeHtmlPng = 'data:image/png;base64,' + Buffer.from('<script>alert(1)</script>').toString('base64');
    const badUp = await req('/api/uploads', {
      method: 'POST',
      body: { dataUrl: fakeHtmlPng, purpose: 'avatar' },
    });
    assert.equal(badUp.status, 400);

    const trav = await req('/api/uploads/..%2F..%2Fetc%2Fpasswd', { token: adminToken });
    assert.ok(trav.status === 400 || trav.status === 404);
    results.push({
      name: 'Upload Magic-Bytes & Path Traversal',
      status: 'PASS',
      detail: 'Disguised script rejected (400) & traversal blocked (404)',
    });
  }

  // 7. Driver Registration, 10,000 IQD Opening Bonus on Approval, Document Privacy & Rejected Driver Zero Bonus
  let driver1Token = '';
  let driver1Id = '';
  let driver2Token = '';
  let driver2Id = '';
  let driverDocPath = '';
  {
    const docRes = await req('/api/uploads', {
      method: 'POST',
      body: { dataUrl: VALID_PNG_DATA_URL, purpose: 'driver_doc' },
    });
    assert.equal(docRes.status, 200);
    driverDocPath = String(docRes.json.url);

    const avatarRes = await req('/api/uploads', {
      method: 'POST',
      body: { dataUrl: VALID_PNG_DATA_URL, purpose: 'driver_avatar' },
    });
    assert.equal(avatarRes.status, 200);

    const noTermsDrv = await req('/api/auth/driver/register', {
      method: 'POST',
      body: {
        name: 'سائق بدون موافقة',
        phone: '07809998877',
        password: 'DriverPass123',
        avatarUrl: avatarRes.json.url,
        carMake: 'Toyota',
        carModel: 'Corolla',
        carYear: 2022,
        carColor: 'أبيض',
        plateNumber: 'بغداد 99999 أ',
        category: 'Economy',
        licenseDocUrl: driverDocPath,
        registrationDocUrl: driverDocPath,
        nationalIdDocUrl: driverDocPath,
      },
    });
    assert.equal(noTermsDrv.status, 400);

    const reg1 = await req('/api/auth/driver/register', {
      method: 'POST',
      body: {
        name: 'سائق أول',
        phone: '07801112233',
        password: 'DriverPass123',
        avatarUrl: avatarRes.json.url,
        carMake: 'Toyota',
        carModel: 'Corolla',
        carYear: 2022,
        carColor: 'أبيض',
        plateNumber: 'بغداد 10001 أ',
        category: 'Economy',
        licenseDocUrl: driverDocPath,
        registrationDocUrl: driverDocPath,
        nationalIdDocUrl: driverDocPath,
        acceptTerms: true,
      },
    });
    assert.equal(reg1.status, 201);
    driver1Token = String(reg1.json.token);
    driver1Id = String((reg1.json.user as { id: string }).id);
    assert.equal((reg1.json.user as { account_number: string }).account_number, 'MSH-D-000001');

    const reg2 = await req('/api/auth/driver/register', {
      method: 'POST',
      body: {
        name: 'سائق ثاني',
        phone: '07501112233',
        password: 'DriverPass123',
        avatarUrl: avatarRes.json.url,
        carMake: 'Hyundai',
        carModel: 'Elantra',
        carYear: 2023,
        carColor: 'فضي',
        plateNumber: 'بغداد 20002 ب',
        category: 'Economy',
        licenseDocUrl: driverDocPath,
        registrationDocUrl: driverDocPath,
        nationalIdDocUrl: driverDocPath,
        acceptTerms: true,
      },
    });
    assert.equal(reg2.status, 201);
    driver2Token = String(reg2.json.token);
    driver2Id = String((reg2.json.user as { id: string }).id);
    assert.equal((reg2.json.user as { account_number: string }).account_number, 'MSH-D-000002');

    // Rejected driver must NOT receive opening bonus
    const reg3 = await req('/api/auth/driver/register', {
      method: 'POST',
      body: {
        name: 'سائق مرفوض',
        phone: '07901112233',
        password: 'DriverPass123',
        avatarUrl: avatarRes.json.url,
        carMake: 'Kia',
        carModel: 'Cerato',
        carYear: 2021,
        carColor: 'أسود',
        plateNumber: 'بغداد 30003 ج',
        category: 'Economy',
        licenseDocUrl: driverDocPath,
        registrationDocUrl: driverDocPath,
        nationalIdDocUrl: driverDocPath,
        acceptTerms: true,
      },
    });
    assert.equal(reg3.status, 201);
    const driver3Id = String((reg3.json.user as { id: string }).id);
    const driver3Token = String(reg3.json.token);
    await req(`/api/admin/drivers/${driver3Id}/reject`, {
      method: 'POST',
      token: adminToken,
      body: { reason: 'المستمسكات غير واضحة' },
    });
    const w3 = await req('/api/driver/wallet', { token: driver3Token });
    assert.equal((w3.json.wallet as { bonus_balance_iqd: number }).bonus_balance_iqd, 0);

    // Rejected driver submits grievance/appeal (Clauses 15 & 19) with snapshot
    const appealRes = await req('/api/complaints', {
      method: 'POST',
      token: driver3Token,
      body: {
        category: 'تظلّم / اعتراض إداري (إيقاف حساب / عمولة / محفظة)',
        subject: 'اعتراض على رفض المستمسكات',
        message: 'أرجو إعادة مراجعة البطاقة الوطنية',
      },
    });
    assert.equal(appealRes.status, 201);
    const compObj = appealRes.json.complaint as { appeal_context: string };
    const ctx = JSON.parse(compObj.appeal_context) as { approval_status: string; account_number: string };
    assert.equal(ctx.approval_status, 'rejected');
    assert.equal(ctx.account_number, 'MSH-D-000003');

    // Unapproved driver must NOT be able to turn on Mishwar
    const unapprovedToggle = await req('/api/driver/mishwar-toggle', {
      method: 'POST',
      token: driver1Token,
      body: { isOnline: true },
    });
    assert.equal(unapprovedToggle.status, 403);

    // Customer must NOT be able to view driver's confidential national ID doc!
    const docLeakTry = await req(driverDocPath, { token: customerToken });
    assert.equal(docLeakTry.status, 403);

    // Admin approves both drivers -> automatic 10,000 IQD virtual opening bonus granted once
    const docAdminView = await fetch(`${BASE}${driverDocPath}`, {
      headers: { Authorization: `Bearer ${adminToken}` },
    });
    assert.equal(docAdminView.status, 200);

    const ap1 = await req(`/api/admin/drivers/${driver1Id}/approve`, { method: 'POST', token: adminToken });
    const ap2 = await req(`/api/admin/drivers/${driver2Id}/approve`, { method: 'POST', token: adminToken });
    assert.equal(ap1.status, 200);
    assert.equal(ap2.status, 200);

    // Verify 10,000 IQD bonus is granted and approving twice does NOT double grant
    await req(`/api/admin/drivers/${driver1Id}/approve`, { method: 'POST', token: adminToken });
    const w1 = await req('/api/driver/wallet', { token: driver1Token });
    assert.equal((w1.json.wallet as { bonus_balance_iqd: number }).bonus_balance_iqd, 10000);
    assert.equal((w1.json.wallet as { real_balance_iqd: number }).real_balance_iqd, 0);

    results.push({
      name: 'Driver Opening Bonus (10,000 IQD), Appeals & Doc Privacy',
      status: 'PASS',
      detail: 'Approved drivers get 10,000 IQD virtual bonus once; rejected driver gets 0 & appeal snapshot saved',
    });
  }

  // 8. GPS Spoofing / Teleportation Jump Detection
  {
    await req('/api/driver/mishwar-toggle', {
      method: 'POST',
      token: driver1Token,
      body: { isOnline: true, lat: 33.3152, lng: 44.3661 }, // Baghdad
    });
    await req('/api/driver/mishwar-toggle', {
      method: 'POST',
      token: driver2Token,
      body: { isOnline: true, lat: 33.3200, lng: 44.3700 },
    });

    const spoofRes = await req('/api/driver/location', {
      method: 'POST',
      token: driver1Token,
      body: { lat: 30.5156, lng: 47.8294, speedMs: 250, gpsAvailable: true },
    });
    assert.equal(spoofRes.status, 422);
    results.push({
      name: 'Anti-GPS-Spoofing Jump Detection',
      status: 'PASS',
      detail: 'Impossible Baghdad->Basra teleport rejected (422) & alerted',
    });
  }

  // 9. Server-Authoritative Pricing, Sequential MSH-TR-000001, Atomic Lock & Cash Ride Commission Deduction
  let activeDriverToken = '';
  let activeDriverId = '';
  {
    const rideRes = await req('/api/rides', {
      method: 'POST',
      token: customerToken,
      body: {
        category: 'Economy',
        pickupLat: 33.3152,
        pickupLng: 44.3661,
        pickupAddress: 'المنصور',
        dropoffLat: 33.3474,
        dropoffLng: 44.4567,
        dropoffAddress: 'زيونة',
        paymentMethod: 'cash',
        final_fare_iqd: 1,
        discount_iqd: 999999,
      },
    });
    assert.equal(rideRes.status, 201);
    const createdRide = rideRes.json.ride as { id: string; ride_number: string; final_fare_iqd: number };
    assert.equal(createdRide.ride_number, 'MSH-TR-000001');
    assert.ok(createdRide.final_fare_iqd >= 3000, 'Server must compute real fare >= minimum fare');

    // Concurrent ride accept race between Driver 1 and Driver 2
    const [acc1, acc2] = await Promise.all([
      req(`/api/driver/rides/${createdRide.id}/accept`, { method: 'POST', token: driver1Token }),
      req(`/api/driver/rides/${createdRide.id}/accept`, { method: 'POST', token: driver2Token }),
    ]);
    const statuses = [acc1.status, acc2.status].sort();
    assert.deepEqual(statuses, [200, 409]);

    activeDriverToken = acc1.status === 200 ? driver1Token : driver2Token;
    activeDriverId = acc1.status === 200 ? driver1Id : driver2Id;

    // Lock زر مشوار during active ride
    const lockToggle = await req('/api/driver/mishwar-toggle', {
      method: 'POST',
      token: activeDriverToken,
      body: { isOnline: false },
    });
    assert.equal(lockToggle.status, 409);

    // Complete ride lifecycle & verify 10% commission deduction (idempotent)
    await req(`/api/driver/rides/${createdRide.id}/status`, {
      method: 'POST',
      token: activeDriverToken,
      body: { status: 'arrived' },
    });
    await req(`/api/driver/rides/${createdRide.id}/status`, {
      method: 'POST',
      token: activeDriverToken,
      body: { status: 'in_progress' },
    });
    const compRes = await req(`/api/driver/rides/${createdRide.id}/status`, {
      method: 'POST',
      token: activeDriverToken,
      body: { status: 'completed' },
    });
    assert.equal(compRes.status, 200);
    const expectedComm = Math.round((createdRide.final_fare_iqd * 10) / 100);
    const wAfter = await req('/api/driver/wallet', { token: activeDriverToken });
    assert.equal(
      (wAfter.json.wallet as { bonus_balance_iqd: number }).bonus_balance_iqd,
      10000 - expectedComm,
    );

    // Cancelled ride must NOT deduct any commission
    const cancelRideRes = await req('/api/rides', {
      method: 'POST',
      token: customerToken,
      body: {
        category: 'Economy',
        pickupLat: 33.3152,
        pickupLng: 44.3661,
        pickupAddress: 'الكرادة',
        dropoffLat: 33.3300,
        dropoffLng: 44.4100,
        dropoffAddress: 'الجادرية',
        paymentMethod: 'cash',
      },
    });
    assert.equal(cancelRideRes.status, 201);
    const r2 = cancelRideRes.json.ride as { id: string; ride_number: string };
    assert.equal(r2.ride_number, 'MSH-TR-000002');
    await req(`/api/rides/${r2.id}/cancel`, {
      method: 'POST',
      token: customerToken,
      body: { reason: 'تغيير الموعد' },
    });
    const wAfterCancel = await req('/api/driver/wallet', { token: activeDriverToken });
    assert.equal(
      (wAfterCancel.json.wallet as { bonus_balance_iqd: number }).bonus_balance_iqd,
      10000 - expectedComm,
    );

    results.push({
      name: 'Fare Integrity, MSH-TR Sequence, Atomic Lock & 10% Commission',
      status: 'PASS',
      detail: `MSH-TR-000001 deducted ${expectedComm} IQD once; cancelled ride MSH-TR-000002 charged 0 IQD`,
    });
  }

  // 10. Zero-Balance Auto-Pause & Official Gateway Top-Up Auto-Reactivation (SuperQi RSA + ZainCash JWT)
  {
    // Bring driver1 wallet to 0 IQD via Admin adjustment and verify auto-pause
    const wCurrent = await req('/api/driver/wallet', { token: activeDriverToken });
    const curBonus = (wCurrent.json.wallet as { bonus_balance_iqd: number }).bonus_balance_iqd;
    const adjZero = await req(`/api/admin/wallets/${activeDriverId}/adjust`, {
      method: 'POST',
      token: adminToken,
      body: { walletPool: 'bonus', deltaIqd: -curBonus, reason: 'اختبار الوصول إلى رصيد صفر' },
    });
    assert.equal(adjZero.status, 200);
    assert.equal((adjZero.json.wallet as { bonus_balance_iqd: number }).bonus_balance_iqd, 0);

    // Ensure negative balance is never allowed
    const negTry = await req(`/api/admin/wallets/${activeDriverId}/adjust`, {
      method: 'POST',
      token: adminToken,
      body: { walletPool: 'real', deltaIqd: -500, reason: 'اختبار منع السالب' },
    });
    assert.equal(negTry.status, 400);

    // Paused driver cannot turn ON زر مشوار while balance = 0
    const zeroToggle = await req('/api/driver/mishwar-toggle', {
      method: 'POST',
      token: activeDriverToken,
      body: { isOnline: true },
    });
    assert.equal(zeroToggle.status, 403);

    // Electronic gateways must remain LOCKED until Admin merchant approval
    const lockedTopup = await req('/api/driver/wallet/topup/initiate', {
      method: 'POST',
      token: activeDriverToken,
      body: { provider: 'superqi', amountIqd: 10000 },
    });
    assert.equal(lockedTopup.status, 403);

    // Admin approves & enables SuperQi and ZainCash official gateways
    const enableSq = await req('/api/admin/payments/gateways/superqi', {
      method: 'PUT',
      token: adminToken,
      body: {
        is_enabled: 1,
        merchant_approved: 1,
        environment: 'sandbox',
        merchant_id: 'TEST-MERCHANT-SQ',
        api_base_url: 'https://payment.qi.iq',
        min_topup_iqd: 5000,
      },
    });
    assert.equal(enableSq.status, 200);

    const enableZc = await req('/api/admin/payments/gateways/zaincash', {
      method: 'PUT',
      token: adminToken,
      body: {
        is_enabled: 1,
        merchant_approved: 1,
        environment: 'sandbox',
        merchant_id: 'TEST-ZC-CLIENT',
        api_base_url: 'https://pg-api.zaincash.iq',
        min_topup_iqd: 5000,
      },
    });
    assert.equal(enableZc.status, 200);

    // Driver initiates SuperQi top-up of 15,000 IQD
    const topupRes = await req('/api/driver/wallet/topup/initiate', {
      method: 'POST',
      token: activeDriverToken,
      body: { provider: 'superqi', amountIqd: 15000 },
    });
    assert.equal(topupRes.status, 201);
    const refId = (topupRes.json.payment as { reference_id: string }).reference_id;

    // Forged RSA signature webhook must be REJECTED (403)
    const forgedPayload = JSON.stringify({
      requestId: refId,
      paymentId: 'SQ-FORGED',
      status: 'SUCCESS',
      amount: 15000,
      currency: 'IQD',
    });
    const badWebhook = await req('/api/payments/superqi/webhook', {
      method: 'POST',
      headers: { 'X-Signature': Buffer.from('forged-sig').toString('base64') },
      body: JSON.parse(forgedPayload),
    });
    assert.equal(badWebhook.status, 403);

    // Tampered amount with valid RSA signature must be REJECTED (400)
    const tamperedBody = JSON.stringify({
      requestId: refId,
      paymentId: 'SQ-TAMPER',
      status: 'SUCCESS',
      amount: 999000,
      currency: 'IQD',
    });
    const tamperedSig = crypto.sign('RSA-SHA256', Buffer.from(tamperedBody), sqPrivatePem).toString('base64');
    const tamperedWebhook = await req('/api/payments/superqi/webhook', {
      method: 'POST',
      headers: { 'X-Signature': tamperedSig },
      body: JSON.parse(tamperedBody),
    });
    assert.equal(tamperedWebhook.status, 400);

    // Genuine RSA-signed SuperQi webhook confirms 15,000 IQD & auto-reactivates paused driver
    const validBodyObj = {
      requestId: refId,
      paymentId: 'SQ-GW-1001',
      status: 'SUCCESS',
      amount: 15000,
      currency: 'IQD',
    };
    const validRaw = JSON.stringify(validBodyObj);
    const validSig = crypto.sign('RSA-SHA256', Buffer.from(validRaw), sqPrivatePem).toString('base64');
    const goodWebhook = await req('/api/payments/superqi/webhook', {
      method: 'POST',
      headers: { 'X-Signature': validSig },
      body: validBodyObj,
    });
    assert.equal(goodWebhook.status, 200);

    // Duplicate webhook replay must NOT double-credit (idempotent)
    const replayWebhook = await req('/api/payments/superqi/webhook', {
      method: 'POST',
      headers: { 'X-Signature': validSig },
      body: validBodyObj,
    });
    assert.equal(replayWebhook.status, 200);

    const wReactivated = await req('/api/driver/wallet', { token: activeDriverToken });
    assert.equal((wReactivated.json.wallet as { real_balance_iqd: number }).real_balance_iqd, 15000);
    const meReactivated = await req('/api/auth/me', { token: activeDriverToken });
    assert.equal((meReactivated.json.driverProfile as { is_online: number }).is_online, 1);

    results.push({
      name: 'Zero-Balance Auto-Pause & SuperQi RSA Top-Up Reactivation',
      status: 'PASS',
      detail: '0 IQD paused driver; forged/tampered webhooks rejected; valid RSA top-up credited 15,000 IQD once & reactivated',
    });
  }

  // 11. Clause 7 Commission Change Consent + ZainCash HS256 JWT Electronic Ride Payment
  {
    const curPrc = await req('/api/admin/pricing', { token: adminToken });
    assert.equal(curPrc.status, 200);
    const updPrc = await req('/api/admin/pricing', {
      method: 'PUT',
      token: adminToken,
      body: { ...(curPrc.json.pricing as Record<string, unknown>), commission_percent: 15 },
    });
    assert.equal(updPrc.status, 200);

    // Driver must be blocked from toggling ON until consenting to new 15% commission
    await req('/api/driver/mishwar-toggle', {
      method: 'POST',
      token: activeDriverToken,
      body: { isOnline: false },
    });
    const blockedBeforeConsent = await req('/api/driver/mishwar-toggle', {
      method: 'POST',
      token: activeDriverToken,
      body: { isOnline: true },
    });
    assert.equal(blockedBeforeConsent.status, 403);

    // Driver accepts Clause 7 commission change -> unblocked
    const consentRes = await req('/api/driver/commission/accept', {
      method: 'POST',
      token: activeDriverToken,
    });
    assert.equal(consentRes.status, 200);
    const unblockedToggle = await req('/api/driver/mishwar-toggle', {
      method: 'POST',
      token: activeDriverToken,
      body: { isOnline: true, lat: 33.3152, lng: 44.3661 },
    });
    assert.equal(unblockedToggle.status, 200);

    // Customer creates ZainCash ride and pays via verified ZainCash HS256 JWT webhook
    const zcRideRes = await req('/api/rides', {
      method: 'POST',
      token: customerToken,
      body: {
        category: 'Economy',
        pickupLat: 33.3152,
        pickupLng: 44.3661,
        pickupAddress: 'الجادرية',
        dropoffLat: 33.3474,
        dropoffLng: 44.4567,
        dropoffAddress: 'الكرادة',
        paymentMethod: 'zaincash',
      },
    });
    assert.equal(zcRideRes.status, 201);
    const zcRide = zcRideRes.json.ride as { id: string; final_fare_iqd: number };
    await req(`/api/driver/rides/${zcRide.id}/accept`, { method: 'POST', token: activeDriverToken });

    const payInit = await req(`/api/rides/${zcRide.id}/pay`, {
      method: 'POST',
      token: customerToken,
      body: { provider: 'zaincash' },
    });
    assert.equal(payInit.status, 200);
    const payRef = (payInit.json.payment as { reference_id: string }).reference_id;

    // Invalid ZainCash JWT rejected (403)
    const badZc = await req('/api/payments/zaincash/webhook', {
      method: 'POST',
      body: { token: signZainCashJwt({ externalReferenceId: payRef, status: 'success', amount: zcRide.final_fare_iqd }, 'WRONG-SECRET') },
    });
    assert.equal(badZc.status, 403);

    // Valid ZainCash HS256 JWT confirms ride payment & applies 15% commission split
    const validZcToken = signZainCashJwt(
      {
        externalReferenceId: payRef,
        transactionId: 'ZC-GW-2002',
        status: 'success',
        amount: zcRide.final_fare_iqd,
        currency: 'IQD',
      },
      process.env.ZAINCASH_MERCHANT_SECRET!,
    );
    const goodZc = await req('/api/payments/zaincash/webhook', {
      method: 'POST',
      body: { token: validZcToken },
    });
    assert.equal(goodZc.status, 200);
    const confirmedPay = goodZc.json.payment as { commission_percent: number; commission_iqd: number; driver_net_iqd: number };
    assert.equal(confirmedPay.commission_percent, 15);
    assert.equal(confirmedPay.commission_iqd + confirmedPay.driver_net_iqd, zcRide.final_fare_iqd);

    const finRes = await req('/api/admin/finance', { token: adminToken });
    assert.equal(finRes.status, 200);
    const rep = finRes.json.report as { electronic_gross_volume_iqd: number; real_topups_confirmed_iqd: number };
    assert.equal(rep.electronic_gross_volume_iqd, zcRide.final_fare_iqd);
    assert.equal(rep.real_topups_confirmed_iqd, 15000);

    results.push({
      name: 'Clause 7 Consent & ZainCash JWT Ride Payment',
      status: 'PASS',
      detail: '15% commission consent enforced; ZainCash HS256 JWT verified & recorded in Admin accounting',
    });
  }

  // 12. Session Revocation on Logout
  {
    const logoutRes = await req('/api/auth/logout', { method: 'POST', token: customerToken });
    assert.equal(logoutRes.status, 200);
    const replayRes = await req('/api/rides/active', { token: customerToken });
    assert.equal(replayRes.status, 401);
    results.push({ name: 'Session Revocation (Anti-Hijack)', status: 'PASS', detail: 'Logged-out token rejected immediately with 401' });
  }

  // 13. Brute-Force Login Rate Limiting & Lockout (429)
  {
    resetSecurityRateLimitsForTests();
    for (let i = 0; i < 5; i++) {
      const fail = await req('/api/auth/customer/login', {
        method: 'POST',
        body: { phone: '07701112233', password: 'WrongPassword!' },
      });
      assert.equal(fail.status, 401);
    }
    const locked = await req('/api/auth/customer/login', {
      method: 'POST',
      body: { phone: '07701112233', password: 'CustomerPass123' },
    });
    assert.equal(locked.status, 429);
    results.push({ name: 'Login Brute-Force Lockout', status: 'PASS', detail: 'Locked after 5 failed attempts (429)' });
  }

  // 14. Encrypted Backup & Security Event Verification
  {
    const backupRes = await req('/api/admin/backups', { method: 'POST', token: adminToken });
    assert.equal(backupRes.status, 201);
    const bkp = backupRes.json.backup as { filename: string; sha256: string; encrypted: number };
    assert.equal(bkp.encrypted, 1);
    assert.ok(bkp.sha256.length === 64);

    const secRes = await req('/api/admin/security', { token: adminToken });
    assert.equal(secRes.status, 200);
    const events = secRes.json.events as Array<{ event_type: string }>;
    const types = new Set(events.map((e) => e.event_type));
    assert.ok(types.has('forbidden_role_access'));
    assert.ok(types.has('gps_spoof_suspected'));
    assert.ok(types.has('tampered_input_blocked'));
    assert.ok(types.has('brute_force_lockout'));
    assert.ok(types.has('invalid_payment_webhook_signature'));
    assert.ok(types.has('payment_tampering_detected'));
    results.push({
      name: 'AES-256-GCM Backup & Security Alerts',
      status: 'PASS',
      detail: 'Encrypted backup verified & all intrusion + payment tampering alerts logged',
    });
  }

  console.log('\n=== MISHWAR SECURITY & BUSINESS LOGIC VERIFICATION RESULTS ===');
  for (const r of results) {
    console.log(`[${r.status}] ${r.name}: ${r.detail}`);
  }
  console.log(`Total Passed: ${results.length}/${results.length}\n`);
} finally {
  globalThis.fetch = originalFetch;
  server.close();
  db.close();
  fs.rmSync(tmpDir, { recursive: true, force: true });
}
